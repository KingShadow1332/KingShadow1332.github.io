# A.R.I Command Center – Anleitung

Diese Anleitung erklärt in der richtigen Reihenfolge: installieren, starten, dann **wo man welchen Schlüssel (API-Key) erstellt** und wo man ihn in A.R.I einträgt.

> **Wichtig:** Alle Schlüssel und Passwörter sind **privat**. Nie weitergeben, nie in Chats oder Screenshots zeigen. Wurde einer versehentlich gezeigt: beim Anbieter löschen und einen neuen erstellen.

---

## 1. Installation (einmalig)

1. Den ganzen A.R.I-Ordner auf den PC kopieren (Windows 10/11).
2. **`ARI-Setup.exe` doppelklicken.** Es öffnet sich ein Fenster mit drei Wahlmöglichkeiten:
   - **Installieren** – richtet Python (falls es fehlt, per `winget`) und alle benötigten Pakete ein und legt auf Wunsch eine Desktop-Verknüpfung an.
   - **Neu installieren (neueste Version)** – setzt alle Pakete neu auf und holt die aktuellsten Versionen. Deine Daten, Schlüssel und das Gehirn bleiben erhalten.
   - **Deinstallieren** – entfernt A.R.I und alles, was dafür eingerichtet wurde. Du wählst vorher selbst, was gelöscht wird (Prozessdatei und Verknüpfung, Python-Pakete, deine Daten, den ganzen Programmordner).
   Beim allerersten Start fragt das Setup, ob du eine **kurze Einführung** möchtest, die alle Möglichkeiten Schritt für Schritt erklärt. Du findest sie später unter „Einführung ansehen“.
3. Fertig, wenn „Fertig!“ erscheint. Mit **„A.R.I jetzt starten“** geht es direkt los.

Windows fragt beim ersten Start von `ARI-Setup.exe` evtl. „Der Computer wurde durch Windows geschützt“ (SmartScreen, weil die Datei nicht signiert ist): **„Weitere Informationen“ → „Trotzdem ausführen“**.

Beim Deinstallieren bleiben zwei Dinge übrig, die das Setup nicht löschen kann: Python selbst und die im Browser gespeicherten Einstellungen/Schlüssel. Für Letztere vorher in A.R.I **Einstellungen → ALLES LÖSCHEN** klicken.

Ohne `winget`: Python 3.10 oder neuer von https://www.python.org/downloads/ installieren und beim Installieren **„Add python.exe to PATH“ ankreuzen**, danach das Setup erneut starten.

Als Browser wird **Chrome oder Edge** empfohlen (Spracherkennung).

## 2. Starten

1. **`START-ARI.bat` doppelklicken.** A.R.I läuft dann unsichtbar im Hintergrund, es gibt kein schwarzes Fenster.
2. Die Oberfläche öffnet sich im Browser (Adresse `http://localhost:5000`). Falls nicht, die Adresse selbst eintippen.
3. **Beenden:** im HUD **Einstellungen → A.R.I BEENDEN** klicken (ganz unten). Oder einfach das HUD-Fenster schließen: **nach 20 Sekunden ohne offenes Fenster beendet sich A.R.I von selbst.** Nach Änderungen an Dateien: beenden, `START-ARI.bat` neu starten und die Seite mit **Strg+F5** neu laden.
4. Beim ersten Start fragt der Browser nach dem **Mikrofon** → „Zulassen“.

Die Einstellungen öffnest du über das **Zahnrad** oben rechts.

---

### Konsole und Fehlersuche
- Die Konsole (das Live-Log des Hubs) ist normalerweise **aus**. Sie öffnet sich automatisch, wenn du dich im HUD in den **Dev-Modus** einloggst (5× auf die Versionsnummer klicken, Passwort eingeben), und geht beim **Ausloggen** wieder zu. Das „Befehls Protokoll“ im HUD ist immer sichtbar.
- Alles, was der Hub schreibt, steht auch in der Datei `data\hub.log`.
- Startet A.R.I nicht (kein Fenster im Browser, keine Fehlermeldung), im Ordner ein Terminal öffnen und `python hub.py` eingeben. Dann siehst du den Fehler direkt.

## 3. KI-Anbieter (mindestens einen einrichten!)

Ohne einen Schlüssel kann A.R.I nicht antworten. Der Schlüssel kommt in **Einstellungen → KI-ANBIETER**. Dort auch den Anbieter auswählen, der benutzt werden soll.

### Groq – kostenlos, schnell (Einstieg empfohlen)
1. https://console.groq.com aufrufen und anmelden.
2. Links **API Keys** → **Create API Key**, Namen vergeben, Schlüssel kopieren (beginnt mit `gsk_`). Er wird nur **einmal** angezeigt.
3. In A.R.I bei **Groq** einfügen. Es gibt **5 Felder**: Trägst du mehrere Schlüssel ein (z. B. von mehreren Konten), wechselt A.R.I bei einem Limit automatisch zum nächsten.
4. Ist das Limit erreicht, zeigt die Kopfzeile „GROQ LIMITIERT – verfügbar in …“ mit Countdown.

### Anthropic (Claude) – kostenpflichtig
1. https://console.anthropic.com → **API Keys** → **Create Key**.
2. Guthaben aufladen (Billing), sonst kommt ein Fehler.
3. In A.R.I bei **Anthropic** einfügen.

### OpenAI (ChatGPT) – kostenpflichtig
1. https://platform.openai.com/api-keys → **Create new secret key**.
2. Guthaben aufladen (Billing).
3. In A.R.I bei **OpenAI** einfügen.

### Google Gemini – hat ein kostenloses Kontingent
1. https://aistudio.google.com/apikey → **Create API key**.
2. In A.R.I bei **Gemini** einfügen.

> Modelle stehen im Hub-Code voreingestellt. Ändern kann man sie über Umgebungsvariablen (`GROQ_MODEL`, `ANTHROPIC_MODEL`, `OPENAI_MODEL`, `GEMINI_MODEL`).

---

## 4. Google Kalender (optional)

Ergibt die Termine im Kalender-Panel und im Gehirn (Bereich „Termine“).

**Einmal in der Google Cloud Console einrichten:**
1. https://console.cloud.google.com → oben **Projekt auswählen → Neues Projekt** (Name egal, z. B. „ARI“).
2. **APIs & Dienste → Bibliothek** → nach **„Google Calendar API“** suchen → **Aktivieren**.
3. **APIs & Dienste → OAuth-Zustimmungsbildschirm** (bzw. „Google Auth Platform“):
   - Nutzertyp **Extern**, App-Name „ARI“, deine E-Mail als Support- und Kontaktadresse.
   - Bei **Testnutzer** deine eigene Google-Adresse **hinzufügen**.
4. **APIs & Dienste → Anmeldedaten → Anmeldedaten erstellen → OAuth-Client-ID** → Anwendungstyp **„Desktop-App“** → Erstellen.
5. **Client-ID** und **Clientschlüssel** kopieren.

**In A.R.I:**
1. **Einstellungen → GOOGLE KALENDER**: Client-ID und Client-Secret einfügen, speichern.
2. Auf **KALENDER VERBINDEN** klicken. Es öffnet sich ein Google-Login.
3. Kommt die Warnung „Google hat diese App nicht überprüft“: **Erweitert → Weiter zu ARI** (das ist deine eigene App, das ist normal).
4. Haken für den Kalenderzugriff setzen, fertig.

> Bleibt die App im Status „Testing“, läuft die Anmeldung nach ca. **7 Tagen** ab. Dann einfach nochmal **KALENDER VERBINDEN** klicken.

## 5. Gmail (optional)

Nutzt **denselben Google-Client** wie der Kalender – keine neue Client-ID.
1. In der Google Cloud Console (dasselbe Projekt) bei **APIs & Dienste → Bibliothek** die **„Gmail API“ aktivieren**.
2. In A.R.I zuerst den **Kalender verbinden** (Abschnitt 4), falls noch nicht geschehen.
3. **Einstellungen → GMAIL → GMAIL VERBINDEN** und im Google-Login den Zugriff erlauben (Lesen und Senden).

## 6. Yahoo Mail (optional)

Yahoo erlaubt kein normales Passwort, sondern ein **App-Passwort**:
1. Bei Yahoo einloggen → **Kontoinfo → Kontosicherheit**.
2. **App-Passwort generieren** (Name z. B. „ARI“) und das Passwort kopieren.
3. **Einstellungen → YAHOO MAIL**: Yahoo-Adresse und App-Passwort eintragen, speichern.
4. **YAHOO VERBINDEN** klicken – das testet den Login sofort.

## 7. Spotify (optional)

Zum Steuern der Wiedergabe braucht man **Spotify Premium**.
1. https://developer.spotify.com/dashboard → anmelden → **Create app**.
2. App-Name und Beschreibung frei wählen.
3. **Redirect URI** genau so eintragen (kopieren!):
   `http://127.0.0.1:5000/spotify/callback`
4. Bei „Welche APIs/SDKs planst du zu verwenden?“ nur **Web API** ankreuzen, speichern.
5. In der App unter **Settings** die **Client ID** und das **Client Secret** kopieren.
6. **Einstellungen → SPOTIFY**: beides einfügen, speichern, dann **SPOTIFY VERBINDEN** und im Spotify-Fenster zustimmen.
7. Spotify muss auf dem PC laufen (App geöffnet), sonst gibt es kein aktives Gerät.

---

## 8. Weitere Einstellungen

- **Sprache / Stimme** (Einstellungen → ALLGEMEIN): Stimme „Thorsten“ läuft offline über den mitgelieferten Ordner `piper`. Fehlt er, eine Browser-Stimme wählen.
- **Weckwort**: Mikrofon-Symbol in der Kopfzeile schaltet es an/aus.
- **Spiele** (Einstellungen → SPIELE): Pro Spiel Tasten und Mausklicks festlegen, z. B. „Fahrwerk“ = `N`. Bei „Prozessname“ die `.exe` des Spiels eintragen (im Task-Manager unter „Details“ zu sehen), damit der **Spielmodus** automatisch erkennt, wann das Spiel läuft.
- **Spielmodus**: Controller-Symbol in der Kopfzeile. Nur bei laufendem Spiel werden die Spielbefehle ausgeführt.
- **Farben** (Einstellungen → FARBEN): Haupt- und Akzentfarbe ändern.
- **Gehirn/Speicher**: Symbol mit den Punkten in der Kopfzeile. Zeigt, was A.R.I über dich gelernt hat. Ziehen = drehen, Mausrad = zoomen, Klick = Inhalt lesen. Eigenes Wissen kannst du unten eintragen.
- **Sicherung / Umzug**: Den Ordner `data` sichern (dort liegen Gehirn, Spielprofile, Kontoverbindungen). Im Browser gibt es unter Einstellungen **EXPORTIEREN / IMPORTIEREN**.

---

## 8b. Handy-Anbindung

1. A.R.I am PC: **Einstellungen → HANDY** → „Handy-Zugriff erlauben“ anhaken.
2. „Koppelcode erzeugen“ drücken. Am Handy (gleiches WLAN) die angezeigte Adresse öffnen (`http://<PC-IP>:5000/phone`) und den 6-stelligen Code eingeben (5 Minuten gültig).
3. Im Browser „Zum Startbildschirm hinzufügen“ – dann startet sie wie eine App.
4. Das Handy kann: chatten/sprechen wie am PC, Lautstärke/Musik/PC sperren, Routen (Google Maps), Restaurants suchen + Reservierungsseite vorausfüllen, und den PC-Bildschirm live sehen und **antippen** (Klick, Doppelklick, Rechtsklick, Scrollen, Text tippen, Tasten).
5. „Dauerhaft im Hintergrund“ hält den Hub an, solange ein Handy gekoppelt ist; „beim Windows-Start starten“ startet ihn unsichtbar mit dem PC.
6. Von unterwegs (mobile Daten): Einstellungen → HANDY → „Von unterwegs erreichbar“. A.R.I lädt dabei einmalig das kostenlose `cloudflared` von Cloudflare (Signatur wird geprüft) und öffnet einen Tunnel – am Router wird nichts freigegeben, am Handy ist keine App nötig. Die Adresse ändert sich bei jedem Start; A.R.I schickt dir den Link (mit Kopplungs-Code) per Mail, oder „Link kopieren“. Der PC muss laufen.
7. Eigenständige Handy-App (läuft auch ohne PC): Ordner `app` (`index.html`, `app.js`, `sw.js`, …) auf einen https-Webspace legen, z. B. GitHub Pages, und die Adresse am Handy öffnen → „Zum Startbildschirm“. Chat, Gehirn, Routen und Restaurants laufen dann direkt auf dem Handy; der Reiter „PC“ öffnet deinen PC per Link.

Sicherheit: Von außen wird alles außer der Handy-Seite abgelehnt; die API geht nur mit einem Geräte-Token aus der Kopplung. Geräte lassen sich in den Einstellungen einzeln trennen. Die KI-Schlüssel bleiben auf dem PC.

## 9. Mehrere Personen / mehrere PCs

- **Jede Person eigener Ordner, eigene Schlüssel, eigene Konten.** Es wird nichts geteilt.
- Beim Kopieren auf einen anderen PC den Ordner **`data` löschen**, sonst startet man mit den Daten und Konten des anderen.
- Den Ordner nie über ein Netzlaufwerk oder eine Cloud-Freigabe gleichzeitig benutzen.
- Der Hub ist nur auf dem eigenen PC erreichbar (`localhost`), niemand im Netz kommt drauf.

## 10. Wenn etwas nicht geht

| Problem | Lösung |
|---|---|
| Meldung „A.R.I läuft bereits“ / „Port 5000 belegt“ | Es läuft schon ein A.R.I. Sein HUD-Fenster öffnen (`http://localhost:5000`) und unter Einstellungen **A.R.I BEENDEN** klicken, oder 20 Sekunden warten. |
| Änderung sichtbar nicht da | Seite mit **Strg+F5** neu laden. |
| Neue Funktion fehlt / Fehler | A.R.I beenden, dann `START-ARI.bat`. Fehlertext steht in `data\hub.log`. |
| „Sprachkanal … nicht verbunden“ | Kein Schlüssel eingetragen (Abschnitt 3) oder falscher Anbieter gewählt. |
| „GROQ LIMITIERT“ | Warten, bis der Countdown abläuft, oder weiteren Groq-Schlüssel eintragen. |
| Kalender/Gmail „widerrufen“ | Erneut **KALENDER/GMAIL VERBINDEN** klicken (Abschnitt 4 und 5). |
| Kein Ton / keine Stimme | `piper`-Ordner prüfen oder Browser-Stimme wählen; Lautstärke prüfen. |
| Mikrofon reagiert nicht | Im Browser Mikrofon erlauben (Schloss-Symbol neben der Adresse) und Chrome/Edge nutzen. |
| Gehirn zeigt „nicht erreichbar“ | Hub neu starten. |
| Spotify: „kein aktives Gerät“ | Spotify-App am PC öffnen und einmal etwas abspielen. |

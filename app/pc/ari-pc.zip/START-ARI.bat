@echo off
cd /d "%~dp0"
REM Startet A.R.I ohne Konsolenfenster (Log: data\hub.log).
REM Der Prozess heisst im Task-Manager "Ari Assistent" (Kopie von pythonw.exe).
set "PYHOME="
for /f "delims=" %%i in ('py -c "import sys;print(sys.base_prefix)" 2^>nul') do set "PYHOME=%%i"
if not defined PYHOME for /f "delims=" %%i in ('python -c "import sys;print(sys.base_prefix)" 2^>nul') do set "PYHOME=%%i"
if defined PYHOME (
    python hub.py --prepare-exe >nul 2>nul || py hub.py --prepare-exe >nul 2>nul
    if exist "%PYHOME%\Ari Assistent.exe" (
        start "" "%PYHOME%\Ari Assistent.exe" hub.py
        goto :started
    )
)
where pyw >nul 2>nul && (start "" pyw hub.py & goto :started)
where pythonw >nul 2>nul && (start "" pythonw hub.py & goto :started)
echo Python wurde nicht gefunden - bitte zuerst ARI-Setup.exe starten.
pause
exit /b 1
:started
echo A.R.I startet ... Das HUD oeffnet sich gleich im Browser.
echo Beenden: im HUD unter Einstellungen "A.R.I BEENDEN" - oder einfach das HUD-Fenster schliessen (nach 20 Sekunden beendet sich A.R.I selbst).
timeout /t 4 >nul

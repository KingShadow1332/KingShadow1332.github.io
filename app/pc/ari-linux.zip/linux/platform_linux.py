"""Linux-Backend fuer A.R.I (X11: Ubuntu/Debian und Abkoemmlinge).

Unter Windows erledigt hub.py Tasten, Maus, Fenster, Lautstaerke, Programmstart und
Bildschirmaufnahme ueber ctypes/PowerShell. Dieses Modul liefert dieselben Faehigkeiten
mit Linux-Werkzeugen (alle kommen in jeder gaengigen Distribution vor und werden vom
install.sh mitinstalliert):

  xdotool  - Tasten, Maus, Fenster suchen/fokussieren/minimieren
  wmctrl   - Fenster maximieren/schliessen, Desktop anzeigen
  playerctl- Medientasten (Play/Pause/Weiter/Zurueck)
  wpctl / pactl / amixer - Lautstaerke (PipeWire, PulseAudio, ALSA - was da ist)
  mss / Pillow - Bildschirmaufnahme (X11)
  python-xlib (optional) - Mauszeiger/Klick abfragen ohne Unterprozess

Unter Wayland duerfen Programme weder Tasten/Klicks an andere Fenster schicken noch den
Bildschirm mitschneiden - dort laufen nur Chat, Termine, Mails, Spotify, Handy-Anbindung
usw. Am einfachsten beim Anmelden "Ubuntu on Xorg" / "X11" waehlen. Siehe session_type().
"""
import configparser
import glob
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time

# ---------------------------------------------------------------------------
# Hilfen
# ---------------------------------------------------------------------------


def _have(cmd):
    return shutil.which(cmd) is not None


def _run(args, timeout=10, check=False):
    """Kleiner Wrapper: gibt (returncode, stdout) zurueck, nie eine Exception."""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "").strip()
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def _spawn(args):
    """Programm losgeloest starten (ueberlebt das Beenden von A.R.I nicht zwingend, stoert aber nie)."""
    subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)


def session_type():
    """'x11', 'wayland' oder 'unknown'."""
    t = (os.environ.get("XDG_SESSION_TYPE") or "").lower()
    if t in ("x11", "wayland"):
        return t
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    if os.environ.get("DISPLAY"):
        return "x11"
    return "unknown"


def missing_tools():
    """Liste fehlender Hilfsprogramme (fuer die Diagnose im Log)."""
    need = ["xdotool", "wmctrl", "playerctl"]
    out = [c for c in need if not _have(c)]
    if not any(_have(c) for c in ("wpctl", "pactl", "amixer")):
        out.append("wpctl/pactl/amixer")
    return out


def startup_report():
    """Text fuers Log beim Start."""
    st = session_type()
    lines = [f"[linux] Sitzung: {st}"]
    if st == "wayland":
        lines.append("[linux] WARNUNG: Wayland erlaubt keine Tasten-/Klick-Steuerung und keinen Bildschirm-Stream. "
                     "Fuer die volle PC-Steuerung beim Anmelden 'Xorg'/'X11' waehlen.")
    m = missing_tools()
    if m:
        lines.append("[linux] Fehlende Programme (Teilfunktionen eingeschraenkt): " + ", ".join(m) +
                     " - Installation: sudo apt install xdotool wmctrl playerctl pulseaudio-utils")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tasten
# ---------------------------------------------------------------------------

# Namen wie in hub.py (_VK_NAMED_KEYS / Scan-Code-Tabelle, inkl. deutscher Aliase) -> X11-Keysyms
_KEYSYM = {
    "space": "space", "leertaste": "space",
    "enter": "Return", "return": "Return", "eingabe": "Return",
    "tab": "Tab",
    "escape": "Escape", "esc": "Escape",
    "backspace": "BackSpace", "ruecktaste": "BackSpace",
    "shift": "shift", "umschalt": "shift",
    "ctrl": "ctrl", "strg": "ctrl", "control": "ctrl",
    "alt": "alt",
    "ralt": "Alt_R", "rechtsalt": "Alt_R", "alt rechts": "Alt_R", "raltgr": "ISO_Level3_Shift", "altgr": "ISO_Level3_Shift",
    "rctrl": "Control_R", "rechtsstrg": "Control_R", "strg rechts": "Control_R",
    "rshift": "Shift_R", "rechteumschalt": "Shift_R", "umschalt rechts": "Shift_R",
    "up": "Up", "hoch": "Up", "down": "Down", "runter": "Down",
    "left": "Left", "links": "Left", "right": "Right", "rechts": "Right",
    "pageup": "Prior", "bildhoch": "Prior", "pagedown": "Next", "bildrunter": "Next",
    "printscreen": "Print", "druck": "Print",
    ",": "comma", ".": "period", "`": "grave", "[": "bracketleft", "]": "bracketright",
    "-": "minus", "=": "equal", "/": "slash", "\\": "backslash", ";": "semicolon", "'": "apostrophe",
}
for _i in range(1, 13):
    _KEYSYM[f"f{_i}"] = f"F{_i}"
for _i in range(10):
    _KEYSYM[f"num{_i}"] = f"KP_{_i}"

_MEDIA_KEYSYM = {
    "mute": "XF86AudioMute", "down": "XF86AudioLowerVolume", "up": "XF86AudioRaiseVolume",
    "play_pause": "XF86AudioPlay", "next": "XF86AudioNext", "previous": "XF86AudioPrev",
}


def resolve_keysym(name):
    k = name.strip().lower()
    if not k:
        return None
    if k in _KEYSYM:
        return _KEYSYM[k]
    if len(k) == 1 and (k.isalpha() or k.isdigit()):
        return k
    return None


def build_combo_command(key_string):
    """'Strg+G' -> xdotool-Argumentliste (oder None bei unbekannter Taste). Modifikatoren werden
    gehalten, die Haupttaste getippt, dann alles in umgekehrter Reihenfolge losgelassen - wie unter Windows."""
    parts = [p.strip() for p in key_string.split("+") if p.strip()]
    if not parts:
        return None
    syms = [resolve_keysym(p) for p in parts]
    if any(s is None for s in syms):
        return None
    *mods, main = syms
    args = ["xdotool"]
    for m in mods:
        args += ["keydown", m]
    if mods:
        args += ["sleep", "0.03"]
    args += ["keydown", main, "sleep", "0.08" if mods else "0.04", "keyup", main]
    for m in reversed(mods):
        args += ["keyup", m]
    return args


def press_combo(key_string):
    args = build_combo_command(key_string)
    if args is None or not _have("xdotool"):
        return False
    return _run(args)[0] == 0


def press_media_key(name):
    """name: mute/down/up/play_pause/next/previous (dieselben Namen wie beim Handy)."""
    if name in ("play_pause", "next", "previous") and _have("playerctl"):
        cmd = {"play_pause": "play-pause", "next": "next", "previous": "previous"}[name]
        if _run(["playerctl", cmd])[0] == 0:
            return True
    sym = _MEDIA_KEYSYM.get(name)
    if sym and _have("xdotool"):
        return _run(["xdotool", "key", sym])[0] == 0
    return False


def type_text(text):
    if not text or not _have("xdotool"):
        return
    _run(["xdotool", "type", "--delay", "12", "--clearmodifiers", "--", text], timeout=60)


# ---------------------------------------------------------------------------
# Lautstaerke
# ---------------------------------------------------------------------------


def _volume_backend():
    if _have("wpctl"):
        return "wpctl"
    if _have("pactl"):
        return "pactl"
    if _have("amixer"):
        return "amixer"
    return None


def volume_command(action, value=0):
    """Baut das Kommando fuer 'mute' | 'up' | 'down' | 'set' (value in Prozent)."""
    b = _volume_backend()
    if b == "wpctl":
        sink = "@DEFAULT_AUDIO_SINK@"
        return {
            "mute": ["wpctl", "set-mute", sink, "toggle"],
            "up": ["wpctl", "set-volume", "-l", "1.5", sink, f"{value}%+"],
            "down": ["wpctl", "set-volume", sink, f"{value}%-"],
            "set": ["wpctl", "set-volume", "-l", "1.5", sink, f"{value}%"],
        }.get(action)
    if b == "pactl":
        sink = "@DEFAULT_SINK@"
        return {
            "mute": ["pactl", "set-sink-mute", sink, "toggle"],
            "up": ["pactl", "set-sink-volume", sink, f"+{value}%"],
            "down": ["pactl", "set-sink-volume", sink, f"-{value}%"],
            "set": ["pactl", "set-sink-volume", sink, f"{value}%"],
        }.get(action)
    if b == "amixer":
        return {
            "mute": ["amixer", "-q", "sset", "Master", "toggle"],
            "up": ["amixer", "-q", "sset", "Master", f"{value}%+"],
            "down": ["amixer", "-q", "sset", "Master", f"{value}%-"],
            "set": ["amixer", "-q", "sset", "Master", f"{value}%"],
        }.get(action)
    return None


def control_volume(action, steps=2, percent=None, step_percent=2):
    """Gibt den Text zurueck, den hub.py als Tool-Ergebnis meldet."""
    if _volume_backend() is None:
        return "Keine Lautstaerke-Steuerung gefunden (wpctl/pactl/amixer installieren)."
    if action == "mute":
        _run(volume_command("mute"))
        return "Stummschaltung umgeschaltet."
    if action == "set":
        pct = max(0, min(100, int(percent or 0)))
        _run(volume_command("set", pct))
        return f"Lautstaerke auf {pct}% gesetzt."
    if action in ("up", "down"):
        n = max(1, min(int(steps or 2), 10)) * step_percent
        _run(volume_command(action, n))
        return f"Lautstaerke {'erhoeht' if action == 'up' else 'verringert'} ({steps} Schritte)."
    return f"Unbekannte Aktion '{action}'."


# ---------------------------------------------------------------------------
# Maus / Bildschirm
# ---------------------------------------------------------------------------

_tl = threading.local()


def _xdisplay():
    """Xlib-Verbindung pro Thread (Xlib ist nicht thread-sicher) oder None."""
    d = getattr(_tl, "xdisp", None)
    if d is not None:
        return d
    try:
        from Xlib import display
        d = display.Display()
    except Exception:
        d = False
    _tl.xdisp = d
    return d or None


def screen_size():
    d = _xdisplay()
    if d:
        try:
            s = d.screen()
            return int(s.width_in_pixels), int(s.height_in_pixels)
        except Exception:
            pass
    rc, out = _run(["xdotool", "getdisplaygeometry"])
    m = re.match(r"(\d+)\s+(\d+)", out or "")
    if m:
        return int(m.group(1)), int(m.group(2))
    return 1920, 1080


def cursor_pos():
    d = _xdisplay()
    if d:
        try:
            p = d.screen().root.query_pointer()
            return int(p.root_x), int(p.root_y)
        except Exception:
            pass
    rc, out = _run(["xdotool", "getmouselocation", "--shell"])
    x = re.search(r"X=(\d+)", out or "")
    y = re.search(r"Y=(\d+)", out or "")
    if x and y:
        return int(x.group(1)), int(y.group(1))
    return 0, 0


def mouse_action(fx, fy, kind="left", amount=3):
    """Maus an Bildschirmanteil (fx, fy) bewegen und klicken/scrollen. kind: left|right|double|scroll|move."""
    if not _have("xdotool"):
        return False
    w, h = screen_size()
    x, y = int(fx * (w - 1)), int(fy * (h - 1))
    args = ["xdotool", "mousemove", str(x), str(y)]
    if kind == "scroll":
        n = max(-10, min(10, int(amount)))
        if n:
            args += ["click", "--repeat", str(abs(n)), "5" if n > 0 else "4"]
    elif kind == "move":
        pass
    elif kind == "right":
        args += ["click", "3"]
    elif kind == "double":
        args += ["click", "--repeat", "2", "--delay", "60", "1"]
    else:
        args += ["click", "1"]
    return _run(args)[0] == 0


def click_at_fraction(fx, fy):
    return mouse_action(fx, fy, "left")


def capture_next_click(timeout=15):
    """Wartet auf den naechsten Linksklick irgendwo und gibt (fx, fy) in 0..1 zurueck (oder None)."""
    d = _xdisplay()
    if not d:
        return None
    try:
        root = d.screen().root
        w, h = screen_size()
        was = bool(root.query_pointer().mask & 0x100)   # Button1Mask
        start = time.time()
        while time.time() - start < timeout:
            p = root.query_pointer()
            down = bool(p.mask & 0x100)
            if down and not was:
                return p.root_x / float(w), p.root_y / float(h)
            was = down
            time.sleep(0.02)
    except Exception:
        return None
    return None


def grab_screen(target_w, smooth=True):
    """Bildschirm -> (PIL-Bild verkleinert auf target_w, Bildschirmbreite, Bildschirmhoehe)."""
    from PIL import Image
    img = None
    try:
        import mss
        sct = getattr(_tl, "mss", None)
        if sct is None:
            sct = _tl.mss = mss.mss()
        mon = sct.monitors[1]
        shot = sct.grab(mon)
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    except Exception:
        _tl.mss = None
        from PIL import ImageGrab
        img = ImageGrab.grab().convert("RGB")
    sw, sh = img.size
    tw = min(int(target_w), sw)
    if tw < sw:
        th = max(1, round(sh * tw / sw))
        img = img.resize((tw, th), Image.BILINEAR if smooth else Image.NEAREST)
    return img, sw, sh


# ---------------------------------------------------------------------------
# Fenster
# ---------------------------------------------------------------------------


def find_window(needle):
    """Erstes sichtbares Fenster, dessen Titel den Suchbegriff enthaelt -> (id, titel) oder None."""
    needle = (needle or "").strip()
    if not needle or not _have("xdotool"):
        return None
    rc, out = _run(["xdotool", "search", "--onlyvisible", "--name", re.escape(needle)])
    for wid in out.split():
        rc2, title = _run(["xdotool", "getwindowname", wid])
        if title and needle.lower() in title.lower():
            return wid, title
    return None


def window_action(wid, action):
    if action == "focus":
        return _run(["xdotool", "windowactivate", "--sync", wid])[0] == 0
    if action == "minimize":
        return _run(["xdotool", "windowminimize", wid])[0] == 0
    if action == "maximize" and _have("wmctrl"):
        return _run(["wmctrl", "-i", "-r", hex(int(wid)), "-b", "add,maximized_vert,maximized_horz"])[0] == 0
    if action == "close":
        if _have("wmctrl"):
            return _run(["wmctrl", "-i", "-c", hex(int(wid))])[0] == 0
        return _run(["xdotool", "windowclose", wid])[0] == 0
    return False


def minimize_active():
    rc, wid = _run(["xdotool", "getactivewindow"])
    return rc == 0 and bool(wid) and _run(["xdotool", "windowminimize", wid])[0] == 0


def show_desktop():
    if _have("wmctrl"):
        return _run(["wmctrl", "-k", "on"])[0] == 0
    return press_combo("super+d")


def lock_screen():
    for cmd in (["loginctl", "lock-session"], ["xdg-screensaver", "lock"], ["gnome-screensaver-command", "-l"],
                ["dm-tool", "lock"]):
        if _have(cmd[0]) and _run(cmd)[0] == 0:
            return True
    return False


# ---------------------------------------------------------------------------
# Programme (.desktop-Eintraege statt Windows-Startmenue)
# ---------------------------------------------------------------------------

# Die Kurznamen, die es unter Windows gab (APP_REGISTRY) -> passende Linux-Programme (erstes vorhandene gewinnt)
APP_ALIASES = {
    "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
    "firefox": ["firefox"],
    "edge": ["microsoft-edge", "microsoft-edge-stable"],
    "notepad": ["gnome-text-editor", "gedit", "kate", "mousepad", "xed", "pluma"],
    "taskmanager": ["gnome-system-monitor", "ksysguard", "plasma-systemmonitor", "xfce4-taskmanager", "mate-system-monitor"],
    "explorer": ["nautilus", "dolphin", "thunar", "nemo", "caja", "pcmanfm"],
    "calculator": ["gnome-calculator", "kcalc", "galculator", "mate-calc", "xfce4-calculator"],
    "paint": ["gimp", "krita", "kolourpaint", "pinta"],
}

_desktop_cache = {"t": 0.0, "v": None}


def _desktop_dirs():
    home = os.path.expanduser("~")
    dirs = [
        os.path.join(home, ".local/share/applications"),
        "/usr/share/applications", "/usr/local/share/applications",
        "/var/lib/flatpak/exports/share/applications",
        os.path.join(home, ".local/share/flatpak/exports/share/applications"),
        "/var/lib/snapd/desktop/applications",
    ]
    for d in os.environ.get("XDG_DATA_DIRS", "").split(":"):
        if d:
            dirs.append(os.path.join(d, "applications"))
    desk = os.path.join(home, "Desktop")
    rc, out = _run(["xdg-user-dir", "DESKTOP"], timeout=3)
    if rc == 0 and out:
        desk = out
    dirs.append(desk)
    seen, res = set(), []
    for d in dirs:
        if d not in seen and os.path.isdir(d):
            seen.add(d)
            res.append(d)
    return res


def parse_desktop_file(path):
    """Liest [Desktop Entry] -> dict(name, names, exec, id, path) oder None (versteckt/kein Programm)."""
    cp = configparser.RawConfigParser(strict=False, interpolation=None)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8")
    except (configparser.Error, OSError, UnicodeDecodeError):
        return None
    if not cp.has_section("Desktop Entry"):
        return None
    e = dict(cp.items("Desktop Entry"))
    if e.get("Type", "Application") != "Application" or e.get("NoDisplay", "").lower() == "true" or e.get("Hidden", "").lower() == "true":
        return None
    exec_line = e.get("Exec", "")
    name = e.get("Name[de]") or e.get("Name")
    if not name or not exec_line:
        return None
    names = {name, e.get("Name", ""), e.get("GenericName[de]", ""), e.get("GenericName", "")}
    return {"name": name, "names": [n for n in names if n], "exec": exec_line,
            "id": os.path.splitext(os.path.basename(path))[0], "path": path}


def list_apps():
    """Alle sichtbaren Programme (5 Min. gecacht)."""
    if _desktop_cache["v"] is not None and time.time() - _desktop_cache["t"] < 300:
        return _desktop_cache["v"]
    apps, seen = [], set()
    for d in _desktop_dirs():
        for path in glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True):
            a = parse_desktop_file(path)
            if a and a["id"] not in seen:
                seen.add(a["id"])
                apps.append(a)
    _desktop_cache.update(t=time.time(), v=apps)
    return apps


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def find_app(name):
    """Sucht ein Programm nach Name: exakt (normalisiert) > exakt (roh) > Teilstring > Datei-ID."""
    needle = (name or "").strip().lower()
    if not needle:
        return None
    nn = _norm(needle)
    apps = list_apps()
    for a in apps:
        if any(_norm(n) == nn for n in a["names"]):
            return a
    for a in apps:
        if any(n.lower() == needle for n in a["names"]):
            return a
    for a in apps:
        if any(needle in n.lower() for n in a["names"]):
            return a
    for a in apps:
        if needle in a["id"].lower():
            return a
    return None


_FIELD_CODES = re.compile(r"%[fFuUdDnNickvm]")


def exec_to_args(exec_line):
    """Exec=-Zeile eines .desktop-Eintrags -> Argumentliste (Feldcodes wie %U entfernt)."""
    try:
        parts = shlex.split(exec_line)
    except ValueError:
        return None
    out = []
    for p in parts:
        p = _FIELD_CODES.sub("", p).replace("%%", "%")
        if p:
            out.append(p)
    return out or None


def launch_app_entry(app):
    if _have("gtk-launch") and app["path"].endswith(".desktop"):
        rc, _ = _run(["gtk-launch", app["id"]], timeout=5)
        if rc == 0:
            return True
    args = exec_to_args(app["exec"])
    if not args:
        return False
    _spawn(args)
    return True


def open_app(name):
    """Kompletter open_app-Ablauf. Gibt die Antwort fuer den Nutzer zurueck."""
    key = (name or "").strip().lower()
    for cand in APP_ALIASES.get(key, []):
        if _have(cand):
            try:
                _spawn([cand])
                return f"'{name}' wird gestartet."
            except OSError as e:
                return f"Konnte '{name}' nicht starten: {e}"
    app = find_app(name)
    if app:
        try:
            if launch_app_entry(app):
                return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
        return f"Konnte '{name}' nicht starten."
    return f"Keine installierte Anwendung fuer '{name}' gefunden."


def close_app_names(name):
    """Prozessnamen-Kandidaten zum Beenden (fuer die Kurznamen aus APP_ALIASES)."""
    key = (name or "").strip().lower()
    return APP_ALIASES.get(key, [])


def open_uri(uri):
    if _have("xdg-open"):
        _spawn(["xdg-open", uri])
        return True
    return False


# ---------------------------------------------------------------------------
# Autostart, Neustart, Browser, Meldungen
# ---------------------------------------------------------------------------

AUTOSTART_FILE = os.path.join(os.path.expanduser("~"), ".config", "autostart", "ari-assistant.desktop")


def set_autostart(enable, start_script):
    if not enable:
        try:
            os.remove(AUTOSTART_FILE)
        except OSError:
            pass
        return True
    try:
        os.makedirs(os.path.dirname(AUTOSTART_FILE), exist_ok=True)
        with open(AUTOSTART_FILE, "w", encoding="utf-8") as f:
            f.write("[Desktop Entry]\nType=Application\nName=A.R.I Hub\nComment=A.R.I im Hintergrund starten\n"
                    f"Exec=sh \"{start_script}\" --background\nTerminal=false\nX-GNOME-Autostart-enabled=true\n")
        return os.path.exists(AUTOSTART_FILE)
    except OSError:
        return False


def restart_command(python_exe, hub_path, workdir):
    return ["sh", "-c", f'sleep 3; cd {shlex.quote(workdir)} && exec {shlex.quote(python_exe)} {shlex.quote(hub_path)}']


def schedule_restart(python_exe, hub_path, workdir):
    _spawn(restart_command(python_exe, hub_path, workdir))


_CHROMIUM_LIKE = ("google-chrome", "chromium", "brave", "vivaldi", "opera", "microsoft-edge")


def default_browser_command():
    """Standardbrowser als Programmname (z.B. 'google-chrome') oder None."""
    rc, out = _run(["xdg-settings", "get", "default-web-browser"], timeout=3)
    if rc != 0 or not out:
        return None
    ident = out.strip()
    if ident.endswith(".desktop"):
        ident = ident[:-8]
    app = find_app(ident)
    if app:
        args = exec_to_args(app["exec"])
        if args:
            return args[0]
    return ident if _have(ident) else None


def open_in_new_window(url):
    """Neues Browserfenster (Chromium-Familie und Firefox kennen --new-window). True bei Erfolg."""
    cmd = default_browser_command()
    if cmd:
        base = os.path.basename(cmd).lower()
        if base.startswith(_CHROMIUM_LIKE) or base.startswith("firefox"):
            try:
                _spawn([cmd, "--new-window", url])
                return True
            except OSError:
                pass
    return open_uri(url)


def show_message(text, title="A.R.I"):
    if _have("notify-send"):
        _run(["notify-send", "-u", "critical", title, text], timeout=5)
    elif _have("zenity"):
        _run(["zenity", "--error", "--title", title, "--text", text], timeout=30)


def open_log_terminal(log_path):
    """Live-Log in einem Terminalfenster (Dev-Konsole). Gibt den Prozess zurueck oder None."""
    tail = ["tail", "-n", "80", "-f", log_path]
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xfce4-terminal", "-e"], ["xterm", "-e"]):
        if _have(term[0]):
            return subprocess.Popen(term + tail, start_new_session=True)
    return None


# ---------------------------------------------------------------------------
# Piper / cloudflared
# ---------------------------------------------------------------------------


def tunnel_download_url():
    import platform
    m = platform.machine().lower()
    arch = "arm64" if m in ("aarch64", "arm64") else "arm" if m.startswith("arm") else "386" if m in ("i386", "i686") else "amd64"
    return f"https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-{arch}"


def verify_cloudflared(path):
    """Es gibt unter Linux keine Authenticode-Signatur: hier nur Plausibilitaet (Groesse, ausfuehrbar, meldet sich als cloudflared).
    Der Download kommt per HTTPS direkt von GitHub (Cloudflare-Repository)."""
    try:
        if os.path.getsize(path) < 5_000_000:
            return False
        os.chmod(path, 0o755)
        rc, out = _run([path, "--version"], timeout=20)
        return rc == 0 and "cloudflared" in out.lower()
    except OSError:
        return False

#!/usr/bin/env bash
# A.R.I Assistant - Installer fuer Linux (Ubuntu/Debian mit X11; andere Distributionen: siehe Hinweis unten)
#
#   bash linux/install.sh                 interaktiv (fragt nach dem Installationsordner)
#   bash linux/install.sh --yes           ohne Rueckfragen, Standardwerte
#   bash linux/install.sh --dir ~/ari     eigener Installationsordner
#   bash linux/install.sh --with-piper    zusaetzlich die lokale Piper-Stimme (Thorsten) herunterladen (~100 MB)
#   bash linux/install.sh --autostart     A.R.I beim Anmelden im Hintergrund starten
#   bash linux/install.sh --uninstall     Starter/Autostart entfernen (Ordner nur nach Rueckfrage)
#
# Deine Daten (Schluessel, Gehirn, Einstellungen) liegen in <Installationsordner>/data und werden bei
# einer Neuinstallation/einem Update nie ueberschrieben.
set -u

SRC="$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)"   # Programmordner (install.sh liegt in linux/)
YES=0; WITH_PIPER=0; AUTOSTART=0; UNINSTALL=0; DIR=""
while [ $# -gt 0 ]; do
    case "$1" in
        --yes|-y) YES=1 ;;
        --with-piper) WITH_PIPER=1 ;;
        --autostart) AUTOSTART=1 ;;
        --uninstall) UNINSTALL=1 ;;
        --dir) shift; DIR="${1:-}" ;;
        -h|--help) sed -n "2,13p" "$0"; exit 0 ;;
        *) echo "Unbekannte Option: $1"; exit 1 ;;
    esac
    shift
done

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m  %s\n' "$*"; }
ask()  { # ask "Frage" default(j/n)
    [ "$YES" = 1 ] && { [ "$2" = "j" ]; return; }
    local a; read -r -p "$1 [$2] " a; a="${a:-$2}"; [[ "$a" =~ ^[jJyY] ]]
}

DOCS="$(xdg-user-dir DOCUMENTS 2>/dev/null || true)"; [ -z "$DOCS" ] && DOCS="$HOME/Documents"
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"; [ -z "$DESKTOP_DIR" ] && DESKTOP_DIR="$HOME/Desktop"
APPS_DIR="$HOME/.local/share/applications"
LAUNCHER="$APPS_DIR/ari-assistant.desktop"
AUTOSTART_FILE="$HOME/.config/autostart/ari-assistant.desktop"
DEFAULT_DIR="$DOCS/A.R.I Assistant"

if [ "$(id -u)" = 0 ]; then
    warn "Bitte NICHT als root ausfuehren (A.R.I gehoert in dein Benutzerkonto). sudo wird nur bei Bedarf selbst aufgerufen."
    exit 1
fi

# ---------------------------------------------------------------- Deinstallation
if [ "$UNINSTALL" = 1 ]; then
    [ -z "$DIR" ] && DIR="$DEFAULT_DIR"
    rm -f "$LAUNCHER" "$AUTOSTART_FILE" "$DESKTOP_DIR/A.R.I Assistant.desktop"
    say "Starter und Autostart entfernt."
    if [ -d "$DIR" ] && ask "Programmordner '$DIR' ganz loeschen (INKLUSIVE deiner Daten)?" n; then
        pkill -f "$DIR/hub.py" 2>/dev/null || true
        rm -rf "$DIR"; say "Ordner geloescht."
    else
        say "Ordner bleibt bestehen: $DIR"
    fi
    exit 0
fi

# ---------------------------------------------------------------- Installationsordner
if [ -z "$DIR" ]; then
    if [ "$YES" = 1 ]; then
        DIR="$DEFAULT_DIR"
    else
        read -r -p "Installationsordner [$DEFAULT_DIR]: " DIR
        DIR="${DIR:-$DEFAULT_DIR}"
    fi
fi
DIR="${DIR/#\~/$HOME}"
say "Installiere nach: $DIR"

# ---------------------------------------------------------------- System-Pakete
PKGS="python3 python3-venv python3-pip python3-tk xdotool wmctrl playerctl pulseaudio-utils x11-utils xdg-utils libnotify-bin"
if command -v apt-get >/dev/null 2>&1; then
    MISSING=""
    for p in $PKGS; do dpkg -s "$p" >/dev/null 2>&1 || MISSING="$MISSING $p"; done
    if [ -n "$MISSING" ]; then
        say "Es fehlen System-Pakete:$MISSING"
        if ask "Jetzt mit 'sudo apt install' nachinstallieren?" j; then
            sudo apt-get update && sudo apt-get install -y $MISSING || warn "apt-Installation nicht vollstaendig - Teilfunktionen koennen fehlen."
        else
            warn "Ohne diese Pakete sind PC-Steuerung/Bildschirm/Lautstaerke teilweise nicht verfuegbar."
        fi
    fi
else
    warn "Kein apt gefunden. Bitte diese Programme mit deinem Paketmanager installieren:"
    warn "  python3 (mit venv/pip/tkinter), xdotool, wmctrl, playerctl, pactl (pulseaudio-utils/pipewire-pulse), xdg-utils, notify-send"
fi
command -v python3 >/dev/null 2>&1 || { echo "python3 fehlt - Abbruch."; exit 1; }

# ---------------------------------------------------------------- Dateien kopieren
mkdir -p "$DIR"
if [ "$(readlink -f "$SRC")" != "$(readlink -f "$DIR")" ]; then
    say "Kopiere Programmdateien ..."
    for f in hub.py "A.R.I HUD.html" phone.html qrcode.min.js ANLEITUNG.md; do
        [ -f "$SRC/$f" ] && cp -f "$SRC/$f" "$DIR/$f"
    done
    for d in app sounds linux; do
        [ -d "$SRC/$d" ] && { mkdir -p "$DIR/$d"; cp -rf "$SRC/$d/." "$DIR/$d/"; }
    done
    [ -d "$SRC/piper" ] && [ ! -d "$DIR/piper" ] && cp -r "$SRC/piper" "$DIR/piper"
fi
mkdir -p "$DIR/data" "$DIR/screenshots"
chmod +x "$DIR/linux/start-ari.sh" "$DIR/linux/install.sh" 2>/dev/null || true

# ---------------------------------------------------------------- Python-Umgebung
say "Richte die Python-Umgebung ein (dauert 1-3 Minuten) ..."
if [ ! -x "$DIR/.venv/bin/python" ]; then
    python3 -m venv "$DIR/.venv" || { echo "venv konnte nicht angelegt werden (python3-venv installiert?)"; exit 1; }
fi
"$DIR/.venv/bin/python" -m pip install --quiet --upgrade pip
"$DIR/.venv/bin/python" -m pip install --quiet --upgrade \
    flask psutil anthropic openai groq pillow \
    google-auth google-auth-oauthlib google-api-python-client \
    edge-tts mss python-xlib setproctitle \
    || warn "Einige Python-Pakete konnten nicht installiert werden (Internet?). Erneut ausfuehren: bash install.sh"

# ---------------------------------------------------------------- Piper (optional)
if [ "$WITH_PIPER" = 1 ] && [ ! -x "$DIR/piper/piper" ]; then
    say "Lade Piper (lokale Stimme) herunter ..."
    ARCH="$(uname -m)"; case "$ARCH" in aarch64|arm64) PA="aarch64" ;; *) PA="x86_64" ;; esac
    TMP="$(mktemp -d)"
    if curl -fL --progress-bar -o "$TMP/piper.tgz" "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_$PA.tar.gz" \
       && tar -xzf "$TMP/piper.tgz" -C "$DIR"; then
        mkdir -p "$DIR/piper/voices"
        V="https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/high"
        curl -fL --progress-bar -o "$DIR/piper/voices/de_DE-thorsten-high.onnx" "$V/de_DE-thorsten-high.onnx" \
          && curl -fL --progress-bar -o "$DIR/piper/voices/de_DE-thorsten-high.onnx.json" "$V/de_DE-thorsten-high.onnx.json" \
          && say "Piper installiert." || warn "Stimmenmodell konnte nicht geladen werden."
    else
        warn "Piper konnte nicht geladen werden - in den Einstellungen dann eine Edge-/Browser-Stimme waehlen."
    fi
    rm -rf "$TMP"
fi

# ---------------------------------------------------------------- Starter mit Icon
ICON="$DIR/app/icon-512.png"; [ -f "$ICON" ] || ICON="utilities-terminal"
mkdir -p "$APPS_DIR"
cat > "$LAUNCHER" <<EOF
[Desktop Entry]
Type=Application
Name=A.R.I Assistant
GenericName=Persoenlicher Assistent
Comment=A.R.I starten
Exec=bash "$DIR/linux/start-ari.sh"
Path=$DIR
Icon=$ICON
Terminal=false
Categories=Utility;
StartupNotify=false
EOF
chmod +x "$LAUNCHER"
if [ -d "$DESKTOP_DIR" ] && ask "Verknuepfung 'A.R.I Assistant' auf dem Desktop anlegen?" j; then
    cp -f "$LAUNCHER" "$DESKTOP_DIR/A.R.I Assistant.desktop"
    chmod +x "$DESKTOP_DIR/A.R.I Assistant.desktop"
    gio set "$DESKTOP_DIR/A.R.I Assistant.desktop" metadata::trusted true 2>/dev/null || true
fi
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_DIR" 2>/dev/null || true

# ---------------------------------------------------------------- Autostart (optional)
if [ "$AUTOSTART" = 1 ] || ask "A.R.I beim Anmelden automatisch (unsichtbar) starten?" n; then
    mkdir -p "$(dirname "$AUTOSTART_FILE")"
    cat > "$AUTOSTART_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=A.R.I Hub
Comment=A.R.I im Hintergrund starten
Exec=sh "$DIR/linux/start-ari.sh" --background
Terminal=false
X-GNOME-Autostart-enabled=true
EOF
    say "Autostart eingerichtet."
fi

say "Fertig! Starten: Programmmenue -> 'A.R.I Assistant'  oder  bash \"$DIR/linux/start-ari.sh\""
if [ "${XDG_SESSION_TYPE:-}" = "wayland" ]; then
    warn "Du nutzt Wayland: Tasten-/Klick-Steuerung und Bildschirm-Stream funktionieren dort nicht."
    warn "Beim Anmelden (Zahnrad am Login-Bildschirm) 'Ubuntu on Xorg' bzw. 'X11' waehlen, dann geht alles."
fi
if ask "A.R.I jetzt starten?" j; then bash "$DIR/linux/start-ari.sh"; fi

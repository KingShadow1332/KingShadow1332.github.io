"""
A.R.I Hub — lokaler Backend-Server fuer das A.R.I Command Center.

Liefert das Dashboard aus und bedient den in "A.R.I HUD.html" dokumentierten
Vertrag:
    GET  /status -> echte Systemdaten via psutil (siehe unten, welche
                    Felder echt / geschaetzt / demo sind)
    POST /chat   -> body: { messages: [{role, content}, ...] }
                    resp: { reply, tools_used?: [...], error? }

/chat ruft die echte Anthropic-API mit Tool-Use auf, damit A.R.I den PC
tatsaechlich steuern kann (Lautstaerke/Medien, Apps oeffnen/schliessen,
Screenshot, Fenster) — siehe TOOLS/run_tool() unten. Ohne gesetzten
ANTHROPIC_API_KEY antwortet /chat mit einer klaren Hinweismeldung statt
einem Fehler, damit das Frontend trotzdem testbar bleibt.

Sprachausgabe laeuft komplett ueber die Browser-Stimmen des Frontends,
nicht ueber diesen Hub.

Start:
    pip install -r requirements.txt
    setx ANTHROPIC_API_KEY "dein-key"   (neues Terminal danach oeffnen)
    python hub.py
Dann im Browser http://127.0.0.1:5000 oeffnen (nicht die HTML-Datei direkt
per Doppelklick — nur ueber den Server sind /status und /chat erreichbar).
"""
import base64
import collections
import concurrent.futures
import datetime
import hashlib
import hmac
import imaplib
import json
import logging
import difflib
import os
import shlex
import shutil
import socket
import re
import smtplib
import subprocess
import sys
import threading
import time

# Wenn stdout nicht an eine echte Konsole angehaengt ist (z.B. gestartet aus
# einer Verknuepfung, per Start-Process ohne Konsolenfenster, oder umgeleitet),
# puffert Python print()-Ausgaben blockweise statt pro Zeile — die [timing]-/
# [chat]-Logs erscheinen dann stark verzoegert oder scheinbar gar nicht,
# obwohl der Request laengst verarbeitet wurde. Erzwingt sofortiges Anzeigen
# unabhaengig davon, wie hub.py gestartet wurde.
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass
import urllib.error

import tempfile
import uuid

import psutil
from flask import Flask, Response, jsonify, request, send_from_directory

# Plattform: Windows nutzt ctypes/PowerShell direkt in dieser Datei, Linux (X11) das Modul platform_linux.py.
IS_WIN = sys.platform == "win32"
_NOWIN = 0x08000000 if IS_WIN else 0   # CREATE_NO_WINDOW - unter Linux gibt es das Argument nicht
if IS_WIN:
    import winreg
else:
    winreg = None
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "linux"))
    import platform_linux as _lx

# Der Hub laeuft unsichtbar (ohne Konsole). Jedes Hilfsprogramm, das er startet (PowerShell, taskkill,
# piper.exe ...), wuerde sonst kurz ein CMD-/PowerShell-Fenster aufblitzen lassen. Deshalb starten ALLE
# Unterprozesse standardmaessig ohne eigenes Fenster. (Nur die Dev-Konsole setzt bewusst eigene Flags.)
if sys.platform == "win32":
    _orig_popen_init = subprocess.Popen.__init__

    def _popen_init_quiet(self, *args, **kwargs):
        if not kwargs.get("creationflags"):
            kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        _orig_popen_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _popen_init_quiet

try:
    import anthropic
except ImportError:
    anthropic = None
try:
    from openai import OpenAI as _OpenAIClient
except ImportError:
    _OpenAIClient = None
try:
    from groq import Groq as _GroqClient
except ImportError:
    _GroqClient = None
try:
    from google.auth.transport.requests import Request as _GoogleAuthRequest
    from google.oauth2.credentials import Credentials as _GoogleCredentials
    from google_auth_oauthlib.flow import InstalledAppFlow as _GoogleInstalledAppFlow
    from googleapiclient.discovery import build as _google_api_build
except ImportError:
    _GoogleAuthRequest = _GoogleCredentials = _GoogleInstalledAppFlow = _google_api_build = None

app = Flask(__name__)

# Das Frontend fragt /status alle 1-2s ab — das flutet das Terminal sonst mit
# einer Zeile pro Poll und begraebt die eigentlich interessanten Logs (Fehler,
# Tool-Aufrufe). Nur diese eine Route aus dem Werkzeug-Zugriffslog filtern,
# alles andere (POST /chat, /calendar/configure usw.) bleibt sichtbar.
class _HideStatusPolling(logging.Filter):
    def filter(self, record):
        msg = record.getMessage()
        return "GET /status " not in msg and "/groq-status" not in msg and "GET /brain " not in msg and "POST /heartbeat " not in msg and "GET /media " not in msg and "/phone/api/state" not in msg and "/phone/api/data" not in msg and "/phone/api/stream" not in msg


logging.getLogger("werkzeug").addFilter(_HideStatusPolling())

DASHBOARD_DIR = os.path.dirname(os.path.abspath(__file__))
DASHBOARD_FILE = "A.R.I HUD.html"
_HUB_START_TIME = time.time()

# Alle Speicher-/Zustandsdateien (Zugangsdaten, Spiele-Profile, gesehene
# E-Mails, ...) leben zusammen in diesem einen Unterordner statt lose neben
# hub.py verstreut — einfacher zu finden, zu sichern oder komplett zu
# loeschen. Bereits vorhandene Dateien aus der alten, flachen Struktur
# werden beim Start automatisch hierher verschoben (siehe _migrate_data_dir).
DATA_DIR = os.path.join(DASHBOARD_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Ohne Konsolenfenster (Start ueber pythonw/START-ARI.bat) gibt es kein
# stdout/stderr: alles Geschriebene geht in data/hub.log. Im Dev-Modus des HUD
# oeffnet sich ein Fenster, das diese Datei live mitliest (siehe /dev/console).
HUB_LOG_FILE = os.path.join(DATA_DIR, "hub.log")
_HEADLESS = sys.stdout is None or os.path.basename(sys.executable).lower().startswith("pythonw")
if _HEADLESS:
    try:
        _hub_log_handle = open(HUB_LOG_FILE, "w", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = _hub_log_handle
    except OSError:
        pass


def _migrate_data_dir():
    """Einmalige Migration: JSON-Speicherdateien, die noch direkt neben
    hub.py liegen (alte, flache Struktur), in DATA_DIR verschieben."""
    for name in ("secrets.json", "game_profiles.json", "seen_emails.json"):
        old_path = os.path.join(DASHBOARD_DIR, name)
        new_path = os.path.join(DATA_DIR, name)
        if os.path.exists(old_path) and not os.path.exists(new_path):
            try:
                shutil.move(old_path, new_path)
                print(f"[data] {name} nach data/ verschoben.")
            except OSError as e:
                print(f"[data] Konnte {name} nicht nach data/ verschieben: {e}")


_migrate_data_dir()

# ---------------------------------------------------------------------------
# Versteckter Dev-Bereich im Frontend (Einstellungen -> mehrfach auf die
# Versionsnummer klicken) — nur fuer den Entwickler selbst, nicht Teil der
# normalen Bedienung. Das Passwort steht bewusst NICHT im Klartext im Code,
# nur sein SHA-256-Hash; der Vergleich passiert zeitkonstant (hmac.compare_
# digest) statt mit == , damit die Antwortzeit nicht verraet, wie viele
# Zeichen schon stimmen. Kein Session-Token: das Frontend haelt das Passwort
# nur im Arbeitsspeicher des Tabs (nicht localStorage) und schickt es bei
# jeder Dev-Aktion erneut mit — nach einem Reload ist man wieder ausgeloggt.
DEV_PASSWORD_HASH = "15200a1b9681095bdf23698fe79043c210be5040d945a1df527ce834eecf8e5d"


def _check_dev_password(password):
    if not isinstance(password, str) or not password:
        return False
    return hmac.compare_digest(hashlib.sha256(password.encode("utf-8")).hexdigest(), DEV_PASSWORD_HASH)

# ---------------------------------------------------------------------------
# Piper TTS: laeuft komplett lokal auf der CPU (kein Internet, kein Kontingent)
# — piper.exe + die beiden Stimmmodelle liegen im Projektordner, siehe piper/
# und piper/voices/. Alternative zur bisherigen Browser-Sprachausgabe
# (window.speechSynthesis), die weiterhin als Rueckfalloption existiert.
# ---------------------------------------------------------------------------
PIPER_DIR = os.path.join(DASHBOARD_DIR, "piper")
PIPER_EXE = os.path.join(PIPER_DIR, "piper.exe" if IS_WIN else "piper")
PIPER_VOICES_DIR = os.path.join(PIPER_DIR, "voices")
PIPER_VOICE_MODELS = {
    "thorsten": "de_DE-thorsten-high.onnx",
}

# ---------------------------------------------------------------------------
# Microsoft Edge Online-Stimmen ("edge-tts"): dieselben natuerlich klingenden
# Neural-Stimmen wie beim "Vorlesen" in Microsoft Edge, kostenlos und ohne
# eigenen API-Schluessel nutzbar (das Paket spricht denselben oeffentlichen
# Dienst an, den Edge selbst nutzt) — braucht aber Internet, anders als Piper.
# ---------------------------------------------------------------------------
EDGE_VOICES = {
    "de-DE": [("katja", "de-DE-KatjaNeural", "Katja"), ("conrad", "de-DE-ConradNeural", "Conrad"), ("amala", "de-DE-AmalaNeural", "Amala")],
    "en-US": [("aria", "en-US-AriaNeural", "Aria"), ("guy", "en-US-GuyNeural", "Guy")],
    "fr-FR": [("denise", "fr-FR-DeniseNeural", "Denise")],
    "es-ES": [("elvira", "es-ES-ElviraNeural", "Elvira")],
    "it-IT": [("elsa", "it-IT-ElsaNeural", "Elsa")],
}
_EDGE_VOICE_IDS = {f"edge:{key}": vid for voices in EDGE_VOICES.values() for key, vid, _ in voices}


def _edge_tts_synthesize(text, voice_id):
    import asyncio
    import edge_tts

    async def _run():
        chunks = bytearray()
        async for chunk in edge_tts.Communicate(text, voice_id).stream():
            if chunk.get("type") == "audio":
                chunks.extend(chunk["data"])
        return bytes(chunks)

    return asyncio.run(_run())
# Piper/espeak versucht sonst, Emojis phonetisch zu "buchstabieren" — reine
# Kauderwelsch-Aussprache. Frontend entfernt sie schon vor dem Request, das
# hier ist nur die zweite Absicherung direkt vor der eigentlichen Synthese.
EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF☀-➿←-⇿⬀-⯿️‍]"
)

# ---------------------------------------------------------------------------
# Mehrere KI-Anbieter: /chat bekommt vom Frontend mit, welcher Anbieter fuer
# diese Anfrage genutzt werden soll ("anthropic" | "openai" | "groq") — so
# kann man in den Einstellungen zwischen Claude, ChatGPT und Groq wechseln,
# ohne den Hub neu zu starten. Jeder Anbieter braucht seinen eigenen API-Key
# als Umgebungsvariable; fehlt einer, bleibt nur dieser Anbieter deaktiviert
# (klare Hinweismeldung statt Absturz), die anderen funktionieren weiter.
# Modellnamen sind per Umgebungsvariable ueberschreibbar, falls sich die
# Anbieter-Modellpalette aendert.
# ---------------------------------------------------------------------------
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-opus-5")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b")
# Google bietet fuer Gemini einen OpenAI-kompatiblen Endpunkt an — daher
# reicht der bestehende _run_openai_compatible()-Pfad (wie bei OpenAI/Groq),
# es braucht kein eigenes google-generativeai-Paket.
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

# Kurzes Timeout statt der SDK-Standardwerte (teils 10 Minuten) — schlaegt ein
# API-Aufruf fehl (kein Netz, falscher Key, Firewall/Proxy blockiert), soll
# das Frontend zuegig eine Fehlermeldung zeigen statt endlos "DENKT..." zu
# haengen.
_API_TIMEOUT_SECONDS = 45

# Zusaetzlich zum SDK-eigenen Timeout oben: eine ERZWUNGENE harte Zeitgrenze
# fuer den kompletten /chat-Ablauf. Beobachtet wurden Faelle, in denen ein
# einzelner Groq-Aufruf trotz timeout=45 mehrere Minuten haengen blieb (der
# SDK-Timeout greift offenbar nicht zuverlaessig bei jeder Art von Haenger,
# z.B. bei einer Verbindung, die minimal Daten trickelt aber nie fertig wird).
# Ohne diese harte Grenze bleibt "state" im Frontend auf DENKEN stehen und
# JEDE weitere Eingabe wird bis dahin stillschweigend ignoriert. Ein Thread
# mit .result(timeout=...) erzwingt einen Abbruch unabhaengig davon, was die
# Bibliothek/Verbindung darunter gerade macht.
CHAT_HARD_TIMEOUT_SECONDS = 20
# Eigener, kleinerer Pool nur fuer /status — get_top_processes()/psutil kann
# gelegentlich an einem einzelnen Systemaufruf haengen bleiben (beobachtet:
# viele parallele "status"-Anfragen blieben im Browser fuer immer "pending",
# haben dabei alle 6 gleichzeitigen Verbindungen des Browsers blockiert und
# so JEDE andere Anfrage inkl. /chat in die Warteschlange gezwungen). Eigener
# Pool statt _chat_executor mitzunutzen, damit sich beide Warteschlangen
# nicht gegenseitig verstopfen koennen.
STATUS_HARD_TIMEOUT_SECONDS = 3
_chat_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
_status_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)


def _run_with_hard_timeout(fn, *args, timeout=CHAT_HARD_TIMEOUT_SECONDS, executor=None, **kwargs):
    future = (executor or _chat_executor).submit(fn, *args, **kwargs)
    try:
        return future.result(timeout=timeout)
    except concurrent.futures.TimeoutError:
        raise TimeoutError(
            f"Anfrage hat laenger als {timeout}s gedauert und wurde erzwungen abgebrochen "
            "(haengender Aufruf, evtl. Anbieter-/System-Stoerung)."
        )


def _groq_clients_for(keys):
    """Baut fuer jeden vom Frontend mitgeschickten, nicht-leeren Groq-
    Schluessel (bis zu 5, siehe Einstellungen) einen eigenen Client — so
    kann bei einem Rate-Limit auf den naechsten Schluessel gewechselt
    werden. Gibt (key, client)-Paare zurueck statt nur Clients: der Key-
    String selbst ist der Schluessel fuer das Cooldown-Tracking (siehe
    _groq_key_cooldowns) — Client-Objekte werden pro Anfrage neu gebaut,
    der Key bleibt aber ueber Anfragen hinweg gleich. Ohne mitgeschickte
    Schluessel wird auf den Env-Var-Client zurueckgefallen (bisheriges
    Verhalten); der hat keinen eigenen Key-String, also auch kein Cooldown-
    Tracking (nur ein einzelner Key ohnehin, Rotation ergibt da keinen Sinn)."""
    pairs = []
    for key in keys or []:
        key = (key or "").strip()
        if key and _GroqClient:
            pairs.append((key, _GroqClient(api_key=key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)))
    if not pairs and _groq_client:
        pairs.append((None, _groq_client))
    return pairs


def _is_rate_limit_error(e):
    text = str(e).lower()
    return "rate_limit" in text or "429" in text or "resource_exhausted" in text


def _parse_retry_after_seconds(e):
    """Extrahiert die vom Anbieter genannte Wartezeit aus einer Rate-Limit-
    Fehlermeldung. Kennt zusammengesetzte Angaben wie Groqs 'try again in
    7m12.5s' oder '2h3m1s' (Tages-/Minutenlimits!), '850ms', sowie Geminis
    'retryDelay: "5s"'. None, wenn nichts gefunden wird."""
    text = str(e)
    match = re.search(r"try again in\s+((?:\d+(?:\.\d+)?(?:ms|h|m|s))+)", text, re.IGNORECASE)
    if not match:
        match = re.search(r"retry(?:Delay)?['\"]?\s*[:=]?\s*['\"]?((?:\d+(?:\.\d+)?(?:ms|h|m|s))+)", text, re.IGNORECASE)
    if not match:
        return None
    total = 0.0
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)(ms|h|m|s)", match.group(1).lower()):
        total += float(num) * {"h": 3600, "m": 60, "s": 1, "ms": 0.001}[unit]
    return total or None


# Merkt sich pro Groq-API-Key (Key-String, nicht Client-Objekt — Clients
# werden pro Anfrage neu gebaut), bis wann er laut letztem Rate-Limit-Fehler
# gesperrt ist (Unix-Zeitstempel). Ueberlebt ueber mehrere /chat-Anfragen
# hinweg (Modul-globaler Zustand), damit ein bereits als limitiert bekannter
# Key beim naechsten Versuch gar nicht erst angefragt wird, statt jedes Mal
# erneut auf den Fehler zu warten.
_groq_key_cooldowns = {}
_groq_cooldown_lock = threading.Lock()
_GROQ_DEFAULT_COOLDOWN_SECONDS = 5.0


def _mark_groq_key_limited(key, wait_seconds):
    if key is None:
        return
    with _groq_cooldown_lock:
        _groq_key_cooldowns[key] = time.time() + max(0.1, wait_seconds or _GROQ_DEFAULT_COOLDOWN_SECONDS)


def _groq_key_locked_seconds_left(key):
    if key is None:
        return 0.0
    with _groq_cooldown_lock:
        until = _groq_key_cooldowns.get(key, 0.0)
    return max(0.0, until - time.time())


class GroqAllKeysLimitedError(Exception):
    """Alle konfigurierten Groq-Schluessel sind laut Cooldown-Tracking
    gerade gesperrt — kein API-Aufruf wurde versucht, retry_after_seconds
    sagt, wann der erste wieder frei wird."""

    def __init__(self, retry_after_seconds):
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"Alle Groq-Schluessel sind gerade limitiert (frei in {retry_after_seconds:.1f}s).")


def groq_status_snapshot(keys):
    """Fuer /groq-status und den Chat-Vorab-Check: sind ALLE uebergebenen
    Groq-Schluessel (Key-Strings) laut Cooldown-Tracking gerade gesperrt?
    Meldet dann die Wartezeit bis zum fruehesten freien Key. Ohne Keys (z.B.
    nur der Env-Var-Fallback) gibt es kein Tracking -> nie limitiert."""
    waits = [_groq_key_locked_seconds_left(k) for k in (keys or []) if k]
    if not waits or any(w <= 0 for w in waits):
        return {"rate_limited": False, "retry_after_seconds": 0}
    return {"rate_limited": True, "retry_after_seconds": round(min(waits), 1)}


def _call_with_key_rotation(keys_and_clients, call_fn):
    """Fuehrt EINEN einzelnen API-Aufruf aus (call_fn(client)), mit Rotation
    ueber mehrere Groq-Schluessel bei Rate-Limits — anders als die frühere
    _run_groq_with_fallback wird hier NUR dieser eine Aufruf wiederholt,
    nicht ein kompletter Tool-Use-Ablauf (der Aufrufer haelt den Gespraechs-
    zustand selbst und ruft diese Funktion pro einzelner API-Anfrage auf).
    Bereits gesperrte Keys werden anhand von _groq_key_cooldowns komplett
    uebersprungen, statt sie erneut anzufragen und auf denselben Fehler zu
    warten. Sind ALLE Keys gesperrt, wird kein einziger API-Aufruf gemacht —
    stattdessen sofort GroqAllKeysLimitedError."""
    if not keys_and_clients:
        raise Exception("Kein Client konfiguriert.")
    last_error = None
    soonest_wait = None
    attempted = False
    for key, client in keys_and_clients:
        locked_left = _groq_key_locked_seconds_left(key)
        if locked_left > 0:
            soonest_wait = locked_left if soonest_wait is None else min(soonest_wait, locked_left)
            continue
        attempted = True
        try:
            return call_fn(client)
        except Exception as e:
            last_error = e
            if key is not None and _is_rate_limit_error(e):
                wait = _parse_retry_after_seconds(e) or _GROQ_DEFAULT_COOLDOWN_SECONDS
                _mark_groq_key_limited(key, wait)
                soonest_wait = wait if soonest_wait is None else min(soonest_wait, wait)
                continue
            raise
    if not attempted:
        raise GroqAllKeysLimitedError(soonest_wait or _GROQ_DEFAULT_COOLDOWN_SECONDS)
    raise last_error


_anthropic_client = anthropic.Anthropic(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (anthropic and os.environ.get("ANTHROPIC_API_KEY")) else None
_openai_client = _OpenAIClient(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (_OpenAIClient and os.environ.get("OPENAI_API_KEY")) else None
_groq_client = _GroqClient(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (_GroqClient and os.environ.get("GROQ_API_KEY")) else None
_gemini_client = (
    _OpenAIClient(api_key=os.environ.get("GEMINI_API_KEY"), base_url=GEMINI_BASE_URL, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
    if (_OpenAIClient and os.environ.get("GEMINI_API_KEY")) else None
)

# Persoenlichkeit fuer die API-Anbindung in /chat (anbieteruebergreifend).
SYSTEM_PROMPT = (
    "Du bist A.R.I, ein KI-System mit warmer, lockerer, hochkompetenter Art - "
    "weniger steif als ein britischer Butler, eher zugewandt und direkt, mit "
    "trockenem Witz. Du sprichst den Nutzer abwechselnd mit wechselnden Anreden "
    "an - z.B. 'Sir', 'Master', 'Boss', 'Chief', 'Captain', 'Commander' oder "
    "'Champ' -, je nach Tonfall der Situation passend gewaehlt, nie zweimal "
    "hintereinander dieselbe, damit es lebendig bleibt. Du passt deinen Sprachstil im Gespraechsverlauf "
    "an den des Nutzers an - Wortwahl, Tonfall, Foermlichkeit, typische "
    "Ausdruecke -, ohne deine eigene Persoenlichkeit zu verlieren. Antworte "
    "auf Deutsch (die Anreden bleiben bewusst englisch), in 1-3 kurzen, "
    "druckreifen Saetzen, geeignet zum Vorlesen. Bleib auch bei Fehlern oder "
    "Rueckfragen gelassen und locker. Erfinde niemals Fakten, IDs, Zahlen, "
    "Links oder Codes, die du nicht sicher weisst oder aus einem Tool-Ergebnis "
    "hast - klingt das plausibel, ist aber trotzdem geraten, ist es schlimmer "
    "als ehrlich zu sagen, dass du es nicht weisst. Ist eine Anfrage "
    "mehrdeutig, frag im Zweifel kurz nach, statt zu raten - ausser bei "
    "'guid'/'guide' im Zusammenhang mit einem Spiel: das ist immer als "
    "'Anleitung/Guide' gemeint (nicht als technische ID), dazu direkt "
    "antworten statt nachzufragen. Fuer aktuelle/live Infos, die sich staendig "
    "aendern (Krypto-/Aktienkurse, Wechselkurse, Wetter, News, Sportergebnisse "
    "o.ae.), hast du ein Such-Tool - nutze es aktiv, um eine echte Antwort zu "
    "liefern, statt zu sagen, du haettest keine Live-Daten oder der Nutzer "
    "solle selbst nachschauen. Wichtig: Hast du das Such-Tool bereits benutzt "
    "und stehen Ergebnisse (Zahlen, Preise, Fakten) im Tool-Ergebnis, MUSST du "
    "diese in deiner finalen Antwort auch tatsaechlich nennen/zitieren - sag "
    "in diesem Fall niemals, du haettest keine aktuellen/Live-Daten, das waere "
    "widerspruechlich, wenn das Suchergebnis welche enthaelt. Nur wenn die "
    "Suche wirklich nichts Brauchbares liefert, ehrlich sagen, dass du nichts "
    "gefunden hast. Bei E-Mails: sende oder beantworte niemals eine E-Mail von "
    "dir aus, ohne dass der Nutzer das verlangt hat. Aber wenn der Nutzer in "
    "seiner Nachricht klar sagt 'schreibe/sende/beantworte eine E-Mail an X "
    "mit Inhalt Y' (oder aehnlich eindeutig), ist das bereits die direkte "
    "Aufforderung - dann sofort das Tool aufrufen und verschicken, OHNE vorher "
    "nochmal nachzufragen ob du wirklich senden sollst. Nachfragen nur, wenn "
    "Empfaenger oder Inhalt der E-Mail wirklich fehlen/unklar sind. read_emails "
    "filtert standardmaessig Newsletter/Werbung/automatische Mails raus - das "
    "ist Absicht, erwaehne diese ungefragt nicht extra. Nur wenn der Nutzer "
    "ausdruecklich ALLE E-Mails sehen will, important_only=false setzen. Genauso "
    "bei Kalender-Terminen: loesche/bearbeite niemals von dir aus einen Termin, "
    "aber wenn der Nutzer klar sagt einen bestimmten Termin zu loeschen oder zu "
    "aendern, direkt mit list_calendar_events die id suchen und dann sofort "
    "delete_calendar_event bzw. update_calendar_event aufrufen, ohne nochmal "
    "nachzufragen. Bei allem, was mit Lautstaerke oder Musik zu tun hat "
    "(lauter/leiser, Titel wechseln, Play/Pause): standardmaessig set_spotify_volume "
    "bzw. control_media nutzen (wirkt auf Spotify), NICHT control_volume (Windows-"
    "Systemlautstaerke) - nur wenn der Nutzer ausdruecklich 'Windows' oder "
    "'Systemlautstaerke' sagt, control_volume nehmen. control_media bei 'naechster "
    "Titel'/'skip'/'zurueck' GENAU EINMAL aufrufen, niemals zweimal hintereinander "
    "im selben Zug - ein einzelner Tastendruck reicht, ein zweiter Aufruf wuerde "
    "einen Titel zu viel ueberspringen. Fragt der Nutzer, welcher Titel gerade "
    "laeuft/kommt, get_current_spotify_track nutzen statt zu raten. Du darfst "
    "passende Emojis "
    "einstreuen, um Antworten lebendiger wirken zu lassen - sparsam, hoechstens "
    "ein bis zwei pro Antwort, nicht in jedem Satz. Sie werden vor der "
    "Sprachausgabe automatisch entfernt, du musst also nicht auf sie eingehen "
    "oder sie im Text erklaeren. Nach take_screenshot antworte NUR mit "
    "'Screenshot gespeichert.' - keine Anrede, kein Kommentar, kein Dateiname, "
    "nichts weiter."
)

# ---------------------------------------------------------------------------
# Netzwerk-Durchsatz: psutil liefert nur kumulative Byte-Zaehler, daher wird
# die Differenz seit dem letzten /status-Aufruf in MB/s umgerechnet.
# ---------------------------------------------------------------------------
_last_net = psutil.net_io_counters()
_last_net_time = time.time()


def get_network_rates():
    global _last_net, _last_net_time
    now = time.time()
    current = psutil.net_io_counters()
    elapsed = max(now - _last_net_time, 0.001)
    down_mbps = (current.bytes_recv - _last_net.bytes_recv) / elapsed / 1024 / 1024
    up_mbps = (current.bytes_sent - _last_net.bytes_sent) / elapsed / 1024 / 1024
    _last_net, _last_net_time = current, now
    return round(max(down_mbps, 0), 2), round(max(up_mbps, 0), 2)


def format_uptime():
    seconds = int(time.time() - psutil.boot_time())
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    return f"{hours}h {minutes}m"


# ---------------------------------------------------------------------------
# Prozessliste: psutil.Process.cpu_percent() braucht zwei Messpunkte, um eine
# sinnvolle Prozentzahl zu liefern (der erste Aufruf pro Prozess ist immer
# 0.0). Deshalb werden die Process-Objekte ueber Aufrufe hinweg zwischen-
# gespeichert; ein Prozess taucht also erst ab dem zweiten /status-Poll
# (~1.2s nach dem ersten Sehen) mit echtem CPU-Wert in der Liste auf.
# ---------------------------------------------------------------------------
_proc_cache = {}
_cpu_count = psutil.cpu_count() or 1


# PIDs/Namen, die psutil unter Windows fuer Kernel-Sammelprozesse liefert
# ("System Idle Process" summiert Leerlaufzeit ueber alle Kerne und meldet
# dabei absurd hohe/verzerrte cpu_percent-Werte) — fuer eine Nutzer-Taskliste
# nicht relevant, daher ausgefiltert.
_IGNORED_PROCESS_NAMES = {"system idle process"}


def get_top_processes(limit=6):
    """
    Wie der Task-Manager gruppiert nach App (z.B. "Chrome" statt 16 einzelne
    chrome.exe-Eintraege) — sonst dominieren Mehrprozess-Apps (Chrome, Claude,
    Discord, ...) die Liste mit lauter Eintraegen desselben Programms.
    """
    grouped = {}
    seen_pids = set()
    for p in psutil.process_iter(["pid", "name", "memory_info"]):
        try:
            pid = p.info["pid"]
            seen_pids.add(pid)
            raw_name = p.info["name"] or "unbekannt"
            if pid == 0 or raw_name.lower() in _IGNORED_PROCESS_NAMES:
                continue
            if pid not in _proc_cache:
                _proc_cache[pid] = p
                p.cpu_percent(None)  # Baseline setzen, dieser Poll zaehlt noch nicht
                continue
            cached = _proc_cache[pid]
            # psutil normiert Prozess-CPU% auf einen einzelnen Kern (kann bei
            # Mehrkern-Prozessen z.B. 278% ergeben) — durch die Kernanzahl
            # geteilt, damit es zur systemweiten 0-100%-Anzeige oben passt.
            cpu = cached.cpu_percent(None) / _cpu_count
            mem = p.info["memory_info"]
            ram_mb = mem.rss / 1024 / 1024 if mem else 0.0

            group_name = raw_name[:-4] if raw_name.lower().endswith(".exe") else raw_name
            group_name = group_name[:1].upper() + group_name[1:] if group_name else group_name
            entry = grouped.setdefault(group_name, {"name": group_name, "status": "LÄUFT", "cpu_percent": 0.0, "ram_mb": 0.0})
            entry["cpu_percent"] += cpu
            entry["ram_mb"] += ram_mb
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    for pid in list(_proc_cache.keys()):
        if pid not in seen_pids:
            del _proc_cache[pid]

    procs = list(grouped.values())
    for entry in procs:
        entry["cpu_percent"] = round(entry["cpu_percent"], 1)
        entry["ram_mb"] = round(entry["ram_mb"], 1)
    # Nach RAM statt CPU sortieren — sonst zeigt die Liste z.B. einen
    # Leerlauf-Prozess mit 2% CPU statt eines RAM-Fressers mit 0% CPU, und
    # die angezeigten Werte passen nicht zur RAM-Gesamtanzeige daneben.
    procs.sort(key=lambda x: (x["ram_mb"], x["cpu_percent"]), reverse=True)
    return procs[:limit]


# get_top_processes() ist auf diesem Rechner zu teuer, um sie bei jedem
# /status-Poll live zu berechnen (viele laufende Prozesse -> psutil braucht
# mehrere Sekunden) — das fuehrte dazu, dass sich Anfragen aufstauten und
# alle Browser-Verbindungsplaetze blockierten (siehe Netzwerk-Tab-Befund).
# Ein eigener Hintergrund-Thread aktualisiert die Liste alle paar Sekunden;
# /status liest nur noch den letzten fertigen Stand und ist dadurch fast
# augenblicklich, egal wie lange die eigentliche Berechnung dauert.
_latest_processes = []
_processes_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Spielmodus: erkennt automatisch anhand der laufenden Windows-Prozesse,
# welches konfigurierte Spiel (falls ueberhaupt eins) gerade laeuft, statt
# einen manuellen Schalter zu brauchen. Aktiv/inaktiv folgt rein dem
# tatsaechlichen Prozess — startet der Nutzer das Spiel, wird der Modus
# automatisch aktiv, beendet er es, automatisch wieder inaktiv. game_action
# nutzt das als Sicherheitsgurt: Tastendruecke gehen nur raus, wenn das
# passende Spiel laut Prozessliste gerade wirklich laeuft (verhindert, dass
# Tasten versehentlich an ein falsches/kein Fenster gehen, wenn das Spiel gar
# nicht offen ist).
# ---------------------------------------------------------------------------
_active_game_key = None
_active_game_lock = threading.Lock()


def _update_active_game_mode():
    global _active_game_key
    if not _load_game_mode_enabled():
        with _active_game_lock:
            _active_game_key = None
        return
    try:
        profiles = _load_game_profiles()
    except Exception:
        return
    configured = {
        (p.get("process_name") or "").strip().lower(): key
        for key, p in profiles.items()
        if (p.get("process_name") or "").strip()
    }
    if not configured:
        with _active_game_lock:
            _active_game_key = None
        return
    found_key = None
    for p in psutil.process_iter(["name"]):
        try:
            name = (p.info["name"] or "").lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        if name in configured:
            found_key = configured[name]
            break
    with _active_game_lock:
        if found_key != _active_game_key:
            old_name = profiles.get(_active_game_key, {}).get("display_name", _active_game_key)
            new_name = profiles.get(found_key, {}).get("display_name", found_key)
            print(f"[game-mode] {old_name or 'kein Spiel'} -> {new_name or 'kein Spiel'}")
        _active_game_key = found_key


def get_active_game_mode():
    """Gibt (game_key, display_name) des gerade per Prozess erkannten aktiven
    Spiels zurueck, oder (None, None) wenn keins laeuft."""
    with _active_game_lock:
        key = _active_game_key
    if key is None:
        return None, None
    try:
        profiles = _load_game_profiles()
        return key, profiles.get(key, {}).get("display_name", key)
    except Exception:
        return None, None


def _process_updater_loop():
    global _latest_processes
    while True:
        try:
            result = get_top_processes()
            with _processes_lock:
                _latest_processes = result
        except Exception as e:
            print(f"[status] Prozessliste konnte nicht aktualisiert werden: {e}")
        try:
            _update_active_game_mode()
        except Exception as e:
            print(f"[game-mode] Erkennung fehlgeschlagen: {e}")
        time.sleep(3)


threading.Thread(target=_process_updater_loop, daemon=True).start()


def get_cached_processes():
    with _processes_lock:
        return _latest_processes


def estimate_memory_breakdown():
    """
    psutil liefert unter Windows keine System/Anwendungen/Cache-Aufteilung,
    nur used/available/total — daher grobe Schaetzung (klar als estimated
    markiert, siehe Vertrag oben).
    """
    vm = psutil.virtual_memory()
    total_gb = vm.total / 1024 ** 3
    used_gb = vm.used / 1024 ** 3
    free_gb = vm.available / 1024 ** 3
    cache_gb = getattr(vm, "cached", 0) / 1024 ** 3  # nur auf Linux vorhanden
    system_gb = used_gb * 0.28
    apps_gb = max(used_gb - system_gb - cache_gb, 0)
    return {
        "system_gb": round(system_gb, 1),
        "apps_gb": round(apps_gb, 1),
        "cache_gb": round(cache_gb, 1),
        "free_gb": round(free_gb, 1),
        "total_gb": round(total_gb, 1),
        "estimated": True,
    }


def get_system_status_label(cpu_percent, ram_percent):
    if cpu_percent > 90 or ram_percent > 92:
        return "critical"
    if cpu_percent > 75 or ram_percent > 80:
        return "warning"
    return "optimal"


# ---------------------------------------------------------------------------
# PC-Steuerung: bewusst nur ctypes (user32-Tastatursimulation) + Pillow +
# subprocess/os.startfile — keine COM/WMI-Abhaengigkeit, siehe die
# Instabilitaet, die dazu fuehrte, die GPU-Ueberwachung wieder zu entfernen
# (unten dokumentiert). Apps werden per Namenssuche aufgeloest: zuerst
# APP_REGISTRY (schnelle, exakte Treffer fuer die haeufigsten Programme),
# sonst eine Suche unter den echten Desktop-/Startmenue-Verknuepfungen des
# Nutzers (_find_app_shortcut) — das Modell bekommt also nie einen rohen
# Pfad/Befehl zum Ausfuehren, sondern kann immer nur etwas oeffnen, das
# tatsaechlich schon als installierte Verknuepfung existiert.
# ---------------------------------------------------------------------------
import ctypes

_VK_VOLUME_MUTE = 0xAD
_VK_VOLUME_DOWN = 0xAE
_VK_VOLUME_UP = 0xAF
_VK_MEDIA_NEXT_TRACK = 0xB0
_VK_MEDIA_PREV_TRACK = 0xB1
_VK_MEDIA_PLAY_PAUSE = 0xB3
_VK_LWIN = 0x5B
_VK_D = 0x44
_KEYEVENTF_EXTENDEDKEY = 0x1
_KEYEVENTF_KEYUP = 0x2
_KEYEVENTF_SCANCODE = 0x8


_VK_TO_MEDIA_NAME = {0xAD: "mute", 0xAE: "down", 0xAF: "up", 0xB0: "next", 0xB1: "previous", 0xB3: "play_pause"}


def _press_key(vk, extended=True):
    if not IS_WIN:
        name = _VK_TO_MEDIA_NAME.get(vk)
        if name:
            _lx.press_media_key(name)
        elif vk == _VK_LWIN:
            _lx.press_combo("super")
        return
    flags = _KEYEVENTF_EXTENDEDKEY if extended else 0
    ctypes.windll.user32.keybd_event(vk, 0, flags, 0)
    ctypes.windll.user32.keybd_event(vk, 0, flags | _KEYEVENTF_KEYUP, 0)


# ---------------------------------------------------------------------------
# Spiel-Aktionen (game_action-Tool weiter unten): beliebige Einzeltasten +
# Modifikator-Kombos (z.B. "Strg+G") fuer konfigurierbare In-Game-Befehle wie
# "Fahrwerk ausfahren". Baut bewusst nur auf dem bereits vorhandenen ctypes/
# keybd_event-Mechanismus auf, keine neue Abhaengigkeit.
# ---------------------------------------------------------------------------
_VK_NAMED_KEYS = {
    "space": 0x20, "leertaste": 0x20,
    "enter": 0x0D, "return": 0x0D, "eingabe": 0x0D,
    "tab": 0x09,
    "escape": 0x1B, "esc": 0x1B,
    "backspace": 0x08, "ruecktaste": 0x08,
    "shift": 0x10, "umschalt": 0x10,
    "ctrl": 0x11, "strg": 0x11, "control": 0x11,
    "alt": 0x12,
    "up": 0x26, "hoch": 0x26, "down": 0x28, "runter": 0x28,
    "left": 0x25, "links": 0x25, "right": 0x27, "rechts": 0x27,
    "pageup": 0x21, "bildhoch": 0x21, "pagedown": 0x22, "bildrunter": 0x22,
    "printscreen": 0x2C, "druck": 0x2C,
    **{f"f{i}": 0x6F + i for i in range(1, 13)},  # F1-F12 = 0x70-0x7B
    **{f"num{i}": 0x60 + i for i in range(10)},  # Numpad 0-9 = 0x60-0x69 (eigene VK-Codes, NICHT identisch mit den normalen Zifferntasten)
}

# Fester Scan-Code (PC/AT Set 1), UNABHAENGIG vom aktiven Tastatur-Layout.
# Spiele mit DirectInput/RawInput-Tastaturabfrage (z.B. Star Citizen) binden
# ueblicherweise an die PHYSISCHE Tastenposition (Scan-Code), nicht an einen
# layoutabhaengigen VK-Code — deshalb war z.B. "Y" auf einer deutschen
# QWERTZ-Tastatur vorher falsch: die VK-Code->Scancode-Umrechnung (auch mit
# korrektem Layout) bildet VK_Y auf die physische "Z"-Taste ab, waehrend das
# Spiel selbst scancode-basiert genau die andere Taste erwartet. Deckt die
# in den Spiel-Profilen tatsaechlich vorkommenden einfachen Tasten ab; alles
# andere (Pfeiltasten, Numpad, Bild hoch/runter, Druck) faellt weiter auf die
# layoutbewusste VK->Scancode-Route zurueck (siehe _press_key_combo).
_SCANCODE_TABLE = {
    "a": 0x1E, "b": 0x30, "c": 0x2E, "d": 0x20, "e": 0x12, "f": 0x21,
    "g": 0x22, "h": 0x23, "i": 0x17, "j": 0x24, "k": 0x25, "l": 0x26,
    "m": 0x32, "n": 0x31, "o": 0x18, "p": 0x19, "q": 0x10, "r": 0x13,
    "s": 0x1F, "t": 0x14, "u": 0x16, "v": 0x2F, "w": 0x11, "x": 0x2D,
    "y": 0x15, "z": 0x2C,
    "1": 0x02, "2": 0x03, "3": 0x04, "4": 0x05, "5": 0x06,
    "6": 0x07, "7": 0x08, "8": 0x09, "9": 0x0A, "0": 0x0B,
    "space": 0x39, "leertaste": 0x39,
    "enter": 0x1C, "return": 0x1C, "eingabe": 0x1C,
    "tab": 0x0F,
    "escape": 0x01, "esc": 0x01,
    "backspace": 0x0E, "ruecktaste": 0x0E,
    "shift": 0x2A, "umschalt": 0x2A,
    "ctrl": 0x1D, "strg": 0x1D, "control": 0x1D,
    "alt": 0x38,
    "f1": 0x3B, "f2": 0x3C, "f3": 0x3D, "f4": 0x3E, "f5": 0x3F,
    "f6": 0x40, "f7": 0x41, "f8": 0x42, "f9": 0x43, "f10": 0x44,
    "f11": 0x57, "f12": 0x58,
    ",": 0x33, ".": 0x34, "`": 0x29, "[": 0x1A, "]": 0x1B,
}

# Rechte Alt-/Strg-/Umschalt-Taste: physisch dieselbe Scan-Code-Nummer wie die
# linke Variante, aber mit gesetztem KEYEVENTF_EXTENDEDKEY-Flag unterschieden
# (E0-Praefix) — Star Citizen bindet manche Aktionen (z.B. "Flugbereit")
# bewusst auf RAlt statt Alt, um Windows-Alt-Kombos nicht zu blockieren.
_EXTENDED_SCANCODE_TABLE = {
    "ralt": 0x38, "rechtsalt": 0x38, "alt rechts": 0x38, "raltgr": 0x38, "altgr": 0x38,
    "rctrl": 0x1D, "rechtsstrg": 0x1D, "strg rechts": 0x1D,
}

# Rechte Umschalttaste hat einen EIGENEN (nicht-erweiterten) Scan-Code, anders
# als RAlt/RStrg, die den Code der linken Taste per Extended-Flag teilen.
_SCANCODE_TABLE["rshift"] = 0x36
_SCANCODE_TABLE["rechteumschalt"] = 0x36
_SCANCODE_TABLE["umschalt rechts"] = 0x36


def _resolve_vk(key_name):
    """Name einer EINZELNEN Taste -> virtueller Tastencode. Buchstaben/Zahlen
    werden programmatisch abgeleitet (VK-Code == ASCII-Code fuer A-Z/0-9),
    alles andere ueber die Namenstabelle inkl. deutscher Aliase."""
    k = key_name.strip().lower()
    if len(k) == 1 and k.isalpha():
        return ord(k.upper())  # A-Z: 0x41-0x5A
    if len(k) == 1 and k.isdigit():
        return ord(k)  # 0-9: 0x30-0x39
    return _VK_NAMED_KEYS.get(k)


def _get_foreground_keyboard_layout():
    """Tastaturlayout des GERADE FOKUSSIERTEN Fensters (z.B. das Spiel), NICHT
    das eigene Layout des Hub-Prozesses — sonst landen z.B. auf einer
    deutschen QWERTZ-Tastatur Y und Z vertauscht: VK_Y/VK_Z werden je nach
    aktivem Layout auf unterschiedliche physische Tasten (Scan-Codes)
    abgebildet, und MapVirtualKeyW OHNE Layout-Angabe nimmt automatisch das
    Layout des aufrufenden Threads (also von hub.py selbst, nicht vom Spiel)."""
    hwnd = ctypes.windll.user32.GetForegroundWindow()
    thread_id = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)
    return ctypes.windll.user32.GetKeyboardLayout(thread_id)


def _resolve_scancode(key_name):
    """Name einer EINZELNEN Taste -> (Scan-Code, extended)-Tupel, fest und
    layoutunabhaengig (siehe _SCANCODE_TABLE/_EXTENDED_SCANCODE_TABLE), falls
    bekannt — sonst None (dann faellt _press_key_combo auf die VK-basierte,
    layoutbewusste Route zurueck)."""
    k = key_name.strip().lower()
    if k in _EXTENDED_SCANCODE_TABLE:
        return (_EXTENDED_SCANCODE_TABLE[k], True)
    if k in _SCANCODE_TABLE:
        return (_SCANCODE_TABLE[k], False)
    return None


def _press_key_combo(key_string):
    """Presst eine einzelne Taste ODER eine Modifikator-Kombo, z.B. 'N',
    'F1', 'Strg+G' — Modifikatoren werden der Reihenfolge nach gehalten, die
    Haupttaste getippt, Modifikatoren in umgekehrter Reihenfolge wieder
    losgelassen. Gibt False bei unbekannten Tastennamen zurueck (kein
    Tastendruck, kein Absturz) statt eine falsche Taste zu raten.

    Nutzt SendInput mit KEYEVENTF_SCANCODE statt des aelteren keybd_event
    (VK-Code-basiert): manche Spiele mit DirectInput/RawInput-Tastaturabfrage
    (z.B. Star Citizen) reagieren auf reine VK-Code-Injektion per keybd_event
    gar nicht. Fuer bekannte einfache Tasten wird direkt der feste, layout-
    unabhaengige Scan-Code aus _SCANCODE_TABLE gesendet (das ist es, was
    solche Spiele tatsaechlich auswerten); nur fuer nicht dort gelistete
    Tasten (Pfeiltasten, Numpad, ...) wird auf die VK->Scancode-Umrechnung
    ueber das Layout des fokussierten Fensters zurueckgegriffen."""
    if not IS_WIN:
        return _lx.press_combo(key_string)
    parts = [p.strip() for p in key_string.split("+") if p.strip()]
    if not parts:
        return False
    resolved = []
    for p in parts:
        direct = _resolve_scancode(p)
        if direct is not None:
            resolved.append(("scan", direct))
            continue
        vk = _resolve_vk(p)
        if vk is None:
            return False
        resolved.append(("vk", vk))
    *modifiers, main = resolved
    extra = ctypes.c_ulong(0)
    layout = _get_foreground_keyboard_layout()

    def send_scan(item, key_up):
        kind, value = item
        if kind == "scan":
            scan, extended = value
        else:
            scan, extended = ctypes.windll.user32.MapVirtualKeyExW(value, 0, layout), False  # MAPVK_VK_TO_VSC
        flags = _KEYEVENTF_SCANCODE | (_KEYEVENTF_KEYUP if key_up else 0) | (_KEYEVENTF_EXTENDEDKEY if extended else 0)
        evt = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))

    for vk in modifiers:
        send_scan(vk, False)
    if modifiers:
        # Kurze Pause, bevor die Haupttaste kommt: manche Spiele (Polling
        # statt Event-basiert) verpassen einen Modifikator, der im selben
        # Eingabe-Schub wie die Haupttaste ankommt — Modifikator muss schon
        # "angekommen" sein, wenn die Haupttaste abgefragt wird.
        time.sleep(0.03)
    send_scan(main, False)
    # Laengeres Halten bei Kombos (z.B. RAlt+R): kuerzere Tipps werden bei
    # Mehrtasten-Kombos in der Praxis haeufiger verschluckt als bei Einzel-
    # tasten.
    time.sleep(0.08 if modifiers else 0.04)
    send_scan(main, True)
    for vk in reversed(modifiers):
        send_scan(vk, True)
    return True


# SendInput mit KEYEVENTF_UNICODE statt keybd_event: tippt beliebigen Text
# (Ortsnamen, Umlaute, Ziffern, Leerzeichen) zeichenweise, ohne fuer jedes
# einzelne Zeichen einen eigenen VK-Code zu brauchen — noch immer reines
# ctypes, keine neue Abhaengigkeit.
_INPUT_KEYBOARD = 1
_KEYEVENTF_UNICODE = 0x0004


class _KeyBdInput(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long), ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _InputUnion(ctypes.Union):
    _fields_ = [("ki", _KeyBdInput), ("mi", _MouseInput)]


class _Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", _InputUnion)]


def _type_text(text, delay=0.015):
    if not IS_WIN:
        _lx.type_text(text)
        return
    extra = ctypes.c_ulong(0)
    for ch in text:
        code = ord(ch)
        down = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, code, _KEYEVENTF_UNICODE, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(down), ctypes.sizeof(_Input))
        up = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, code, _KEYEVENTF_UNICODE | _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(up), ctypes.sizeof(_Input))
        time.sleep(delay)  # manche Spiele/Suchfelder verschlucken Zeichen, wenn sie zu schnell hintereinander kommen


# Linksklick per SendInput (MOUSEEVENTF_ABSOLUTE + _MOVE/_LEFTDOWN/_LEFTUP) —
# fx/fy sind Anteile der Bildschirmbreite/-hoehe (0.0-1.0), NICHT Pixel, damit
# eine einmal ermittelte Klickposition unabhaengig von der Aufloesung
# funktioniert. Noetig fuer game_action-Spiele, deren UI (z.B. Star Citizens
# Sternenkarten-Suchergebnis) einen echten Klick statt nur eine Taste
# braucht — ohne Bildschirm-Sichtkontakt kann ich die Position nicht selbst
# herausfinden, die muss der Nutzer einmalig angeben (siehe Einstellungen >
# Spiele > Sternenkarten-Ergebnis-Klick).
_INPUT_MOUSE = 0
_MOUSEEVENTF_MOVE = 0x0001
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004
_MOUSEEVENTF_ABSOLUTE = 0x8000


def _click_at_fraction(fx, fy):
    if not IS_WIN:
        _lx.click_at_fraction(fx, fy)
        return
    abs_x = max(0, min(65535, int(fx * 65535)))
    abs_y = max(0, min(65535, int(fy * 65535)))
    extra = ctypes.c_ulong(0)
    for flags in (
        _MOUSEEVENTF_MOVE | _MOUSEEVENTF_ABSOLUTE,
        _MOUSEEVENTF_LEFTDOWN | _MOUSEEVENTF_ABSOLUTE,
        _MOUSEEVENTF_LEFTUP | _MOUSEEVENTF_ABSOLUTE,
    ):
        evt = _Input(_INPUT_MOUSE, _InputUnion(mi=_MouseInput(abs_x, abs_y, 0, flags, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))
        time.sleep(0.05)


_VK_LBUTTON = 0x01


class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def _capture_next_click(timeout=15):
    """Wartet auf den naechsten echten Linksklick irgendwo auf dem
    Bildschirm (global, unabhaengig vom Fensterfokus — der Klick geht also
    ganz normal im Spiel an, waehrend wir nur zuschauen) und gibt seine
    Position als Bildschirmanteil (0.0-1.0) zurueck. Fuer die Klick-
    Kalibrierung in Einstellungen > Spiele: jeder Nutzer hat eine andere
    Monitor-Aufloesung, ein fester Pixel-Wert waere nicht uebertragbar —
    per Klick erfassen und in Prozent umrechnen loest das direkt. Einfaches
    Polling von GetAsyncKeyState statt eines systemweiten Hooks, reicht fuer
    einen einmaligen Klick voellig aus."""
    if not IS_WIN:
        return _lx.capture_next_click(timeout)
    was_down = bool(ctypes.windll.user32.GetAsyncKeyState(_VK_LBUTTON) & 0x8000)
    start = time.time()
    while time.time() - start < timeout:
        down = bool(ctypes.windll.user32.GetAsyncKeyState(_VK_LBUTTON) & 0x8000)
        if down and not was_down:
            pt = _Point()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            screen_w = ctypes.windll.user32.GetSystemMetrics(0)
            screen_h = ctypes.windll.user32.GetSystemMetrics(1)
            return pt.x / screen_w, pt.y / screen_h
        was_down = down
        time.sleep(0.02)
    return None


APP_REGISTRY = {
    "chrome": "chrome.exe",
    "firefox": "firefox.exe",
    "edge": "msedge.exe",
    "notepad": "notepad.exe",
    "taskmanager": "taskmgr.exe",
    "explorer": "explorer.exe",
    "calculator": "calc.exe",
    "paint": "mspaint.exe",
}

SCREENSHOT_DIR = os.path.join(DASHBOARD_DIR, "screenshots")


WINDOWS_VOLUME_STEP_PERCENT = 2  # Standard-Schrittgroesse pro Medientasten-Druck


def _tool_control_volume(action, steps=2, percent=None):
    if not IS_WIN:
        return _lx.control_volume(action, steps, percent, WINDOWS_VOLUME_STEP_PERCENT)
    if action == "mute":
        _press_key(_VK_VOLUME_MUTE)
        return "Stummschaltung umgeschaltet."
    if action == "set":
        # Windows-Medientasten kennen keinen Absolutwert, nur rauf/runter —
        # daher erst mit Reserve auf 0% runterfahren (fester, bekannter
        # Ausgangspunkt), dann in der Standard-Schrittgroesse (2%/Druck)
        # gezielt wieder hochfahren.
        pct = max(0, min(100, int(percent or 0)))
        for _ in range(60):
            _press_key(_VK_VOLUME_DOWN)
        for _ in range(round(pct / WINDOWS_VOLUME_STEP_PERCENT)):
            _press_key(_VK_VOLUME_UP)
        return f"Lautstaerke auf ca. {pct}% gesetzt."
    vk = _VK_VOLUME_UP if action == "up" else _VK_VOLUME_DOWN if action == "down" else None
    if vk is None:
        return f"Unbekannte Aktion '{action}'."
    for _ in range(max(1, min(int(steps or 2), 10))):
        _press_key(vk)
    return f"Lautstaerke {'erhoeht' if action == 'up' else 'verringert'} ({steps} Schritte)."


def _tool_control_media(action):
    vk = {
        "play_pause": _VK_MEDIA_PLAY_PAUSE,
        "next": _VK_MEDIA_NEXT_TRACK,
        "previous": _VK_MEDIA_PREV_TRACK,
    }.get(action)
    if vk is None:
        return f"Unbekannte Aktion '{action}'."
    _press_key(vk)
    return f"Medienbefehl '{action}' gesendet."


_SHORTCUT_DIRS = [
    os.path.join(os.environ.get("USERPROFILE", ""), "Desktop"),
    os.path.join(os.environ.get("PUBLIC", "C:\\Users\\Public"), "Desktop"),
    os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs"),
    os.path.join(os.environ.get("PROGRAMDATA", "C:\\ProgramData"), "Microsoft", "Windows", "Start Menu", "Programs"),
]


def _normalize_app_name(text):
    """Nur Buchstaben/Zahlen, alles andere raus — 'R.E.P.O.' und 'REPO'
    sollen als derselbe Name gelten."""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _find_app_shortcut(name):
    """Sucht unter den echten Desktop-/Startmenue-Verknuepfungen (.lnk/.url)
    nach einem Namen, der zur Suche passt — Ari kann so jedes installierte
    Programm oeffnen, ohne dass das Modell einen rohen Pfad angeben muss.
    Reihenfolge: exakter Treffer (nach Normalisierung) > exakter Treffer
    (roh) > Teilstring-Treffer. Exakte Treffer haben IMMER Vorrang vor
    Teilstring-Treffern — sonst kann z.B. 'REPO' faelschlich das "AMD Bug
    Report Tool" treffen, weil 'repo' als Teilstring in 'RePOrt' steckt,
    obwohl es fuer 'R.E.P.O.' (das eigentlich gemeinte Spiel) einen exakten
    Treffer gibt."""
    needle = name.strip().lower()
    needle_norm = _normalize_app_name(name)
    if not needle:
        return None
    candidates = []
    for base in _SHORTCUT_DIRS:
        if not base or not os.path.isdir(base):
            continue
        for root, _dirs, files in os.walk(base):
            for fname in files:
                stem, ext = os.path.splitext(fname)
                if ext.lower() not in (".lnk", ".url"):
                    continue
                candidates.append((stem, os.path.join(root, fname)))
    for stem, path in candidates:
        if _normalize_app_name(stem) == needle_norm:
            return path
    for stem, path in candidates:
        if stem.lower() == needle:
            return path
    for stem, path in candidates:
        if needle in stem.lower():
            return path
    return None


_start_apps_cache = {"apps": None, "ts": 0}


def _get_start_apps():
    """Fragt Windows' eigenen Katalog installierter Anwendungen ab (alles, was
    im Startmenue auftaucht — normale .exe-Programme UND Store/UWP-Apps).
    Das ist der generelle, zuverlaessige Weg statt fuer jedes Programm einzeln
    zu raten/hart zu codieren, wo es installiert ist: Windows kennt den Pfad
    bzw. die AppID schon selbst. 5 Min. gecacht, weil PowerShell-Start ~0.3-0.5s
    kostet und sich Installationen waehrend einer laufenden Sitzung kaum aendern."""
    if _start_apps_cache["apps"] is not None and (time.time() - _start_apps_cache["ts"]) < 300:
        return _start_apps_cache["apps"]
    apps = []
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-StartApps | ConvertTo-Json -Compress"],
            capture_output=True, timeout=10,
        )
        # Bytes statt text=True dekodieren: PowerShell schreibt manche
        # App-Namen (Sonderzeichen) sonst in der System-Codepage statt UTF-8,
        # was text=True mit der falschen Kodierung zum Absturz bringen kann.
        stdout = result.stdout.decode("utf-8", errors="replace")
        parsed = json.loads(stdout or "[]")
        if isinstance(parsed, dict):
            parsed = [parsed]
        apps = [{"name": a.get("Name", ""), "app_id": a.get("AppID", "")} for a in parsed if a.get("Name")]
    except Exception:
        apps = []
    _start_apps_cache["apps"] = apps
    _start_apps_cache["ts"] = time.time()
    return apps


def _resolve_app_target(name):
    """Sucht 'name' im Windows-Startmenue-Katalog. Gibt (kind, target) zurueck:
    ('path', <voller Programmpfad>) fuer normale .exe-Apps,
    ('uri', <URI>) fuer Eintraege, deren AppID selbst ein Protokoll-Link ist
    (z.B. Steam-Spiele: 'steam://rungameid/X'), oder
    ('shell', <AppID>) fuer Store/UWP-Apps bzw. Shell-Ordner-Verknuepfungen
    (die haben keinen direkten Dateipfad, sondern muessen ueber
    shell:AppsFolder gestartet werden)."""
    needle = name.strip().lower()
    apps = _get_start_apps()
    exact = [a for a in apps if a["name"].lower() == needle]
    partial = [a for a in apps if needle in a["name"].lower()]
    match = (exact or partial or [None])[0]
    if not match:
        return None
    app_id = match["app_id"]
    if os.path.isfile(app_id):
        return ("path", app_id)
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", app_id):
        return ("uri", app_id)
    return ("shell", app_id)


def _find_steam_exe():
    for candidate in (
        r"C:\Program Files (x86)\Steam\steam.exe",
        r"C:\Program Files\Steam\steam.exe",
    ):
        if os.path.isfile(candidate):
            return candidate
    return "steam.exe"


def _launch_uri(uri):
    """os.startfile() auf einen Steam-Link (steam://rungameid/X) bringt oft
    nur den Steam-Client auf die Spieleseite, statt das Spiel wirklich zu
    starten — vor allem wenn Steam gerade erst hochfaehrt und den Protokoll-
    Aufruf verschluckt. 'steam.exe -applaunch <appid>' ist der von Valve
    empfohlene Weg fuer einen zuverlaessigen Start, deshalb hier bevorzugt."""
    match = re.match(r"steam://rungameid/(\d+)", uri)
    if match:
        subprocess.Popen([_find_steam_exe(), "-applaunch", match.group(1)])
        return
    os.startfile(uri)


def _launch_shortcut(path):
    """Startet eine .lnk/.url-Verknuepfung — bei einer Steam-URL darin ueber
    _launch_uri() fuer einen zuverlaessigen Start statt os.startfile()."""
    if path.lower().endswith(".url"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except OSError:
            content = ""
        match = re.search(r"steam://rungameid/\d+", content)
        if match:
            _launch_uri(match.group(0))
            return
    os.startfile(path)


def _tool_open_app(name):
    if not IS_WIN:
        return _lx.open_app(name)
    key = (name or "").strip().lower()
    exe = APP_REGISTRY.get(key)
    if exe:
        # Nur fuer die Handvoll Windows-Bordmittel (notepad, calc, explorer, ...),
        # die zuverlaessig ueber PATH/System32 aufloesen — kein Rateversuch fuer
        # richtige Programme, dafuer ist die generelle Aufloesung unten da.
        try:
            os.startfile(exe)
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    # Desktop-Verknuepfungen zuerst (das ist, was der Nutzer sich selbst
    # bewusst auf den Desktop gelegt hat — vorhersehbarer als der komplette
    # Windows-Katalog). Der Katalog (Get-StartApps) ist nur der Fallback fuer
    # Programme ohne Desktop-Icon.
    shortcut = _find_app_shortcut(name)
    if shortcut:
        try:
            _launch_shortcut(shortcut)
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    target = _resolve_app_target(name)
    if target:
        kind, value = target
        try:
            if kind == "path":
                os.startfile(value)
            elif kind == "uri":
                _launch_uri(value)
            else:
                subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + value])
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    return f"Keine installierte Anwendung/Verknuepfung fuer '{name}' gefunden."


def _tool_close_app(name):
    key = (name or "").strip().lower()
    exe = APP_REGISTRY.get(key)
    if exe and IS_WIN:
        result = subprocess.run(["taskkill", "/IM", exe, "/F"], capture_output=True, text=True)
        if result.returncode == 0:
            return f"'{name}' wurde beendet."
        return f"'{name}' lief nicht oder konnte nicht beendet werden."
    needle = key
    if not IS_WIN:
        # Linux: Kurznamen (chrome, notepad, ...) auf die echten Prozessnamen abbilden; sonst Suche im Prozessnamen
        alias = _lx.close_app_names(name)
        if alias:
            needle = alias[0]
            names = {a.lower() for a in alias}
            matched = [p for p in psutil.process_iter(["pid", "name"]) if (p.info.get("name") or "").lower() in names or any(a in (p.info.get("name") or "").lower() for a in names)]
            if matched:
                for proc in matched:
                    try:
                        proc.kill()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                return f"'{name}' wurde beendet ({len(matched)} Prozess(e))."
    matched = []
    for proc in psutil.process_iter(["pid", "name"]):
        pname = (proc.info.get("name") or "")
        if needle in pname.lower() or needle in os.path.splitext(pname)[0].lower():
            matched.append(proc)
    if not matched:
        return f"'{name}' laeuft nicht (kein passender Prozess gefunden)."
    for proc in matched:
        try:
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return f"'{name}' wurde beendet ({len(matched)} Prozess(e))."


SCREENSHOT_MAX_FILES = 20


def _tool_take_screenshot():
    from PIL import ImageGrab
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    filename = "screenshot_" + time.strftime("%Y%m%d_%H%M%S") + ".png"
    ImageGrab.grab().save(os.path.join(SCREENSHOT_DIR, filename))
    # Ohne Aufraeumen wuerde der Ordner bei jedem Screenshot-Tool-Aufruf
    # unbegrenzt weiterwachsen — nur die letzten N behalten, aelteste loeschen.
    try:
        existing = sorted(
            (f for f in os.listdir(SCREENSHOT_DIR) if f.startswith("screenshot_") and f.endswith(".png")),
        )
        for old in existing[:-SCREENSHOT_MAX_FILES]:
            os.remove(os.path.join(SCREENSHOT_DIR, old))
    except OSError:
        pass
    return f"Screenshot gespeichert als {filename}."


def _tool_manage_window(action):
    if not IS_WIN:
        if action == "minimize_active":
            return "Aktives Fenster minimiert." if _lx.minimize_active() else "Konnte das aktive Fenster nicht minimieren (xdotool/X11 noetig)."
        if action == "show_desktop":
            return "Desktop angezeigt." if _lx.show_desktop() else "Konnte den Desktop nicht anzeigen (wmctrl/X11 noetig)."
        return f"Unbekannte Aktion '{action}'."
    if action == "minimize_active":
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
        return "Aktives Fenster minimiert."
    if action == "show_desktop":
        _press_key(_VK_LWIN, extended=False)
        _press_key(_VK_D, extended=False)
        return "Desktop angezeigt."
    return f"Unbekannte Aktion '{action}'."


def _find_window_by_title(needle):
    """Sucht per EnumWindows nach dem ersten sichtbaren Fenster, dessen Titel
    die Suche enthaelt (case-insensitive) — Grundlage fuer 'interagiere mit
    Fenster X', ohne dass Ari raten muss, wie das Fenster exakt heisst."""
    if not IS_WIN:
        return _lx.find_window(needle)
    needle = needle.strip().lower()
    matches = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)

    def _callback(hwnd, _lparam):
        if not ctypes.windll.user32.IsWindowVisible(hwnd):
            return True
        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
        if needle in buf.value.lower():
            matches.append((hwnd, buf.value))
        return True

    ctypes.windll.user32.EnumWindows(EnumWindowsProc(_callback), 0)
    return matches[0] if matches else None


def _tool_window_action(title, action):
    found = _find_window_by_title(title or "")
    if not found:
        return f"Kein offenes Fenster mit Titel '{title}' gefunden."
    hwnd, real_title = found
    if not IS_WIN:
        if action not in ("focus", "minimize", "maximize", "close"):
            return f"Unbekannte Aktion '{action}'."
        ok = _lx.window_action(hwnd, action)
        past = {"focus": "fokussiert", "minimize": "minimiert", "maximize": "maximiert", "close": "geschlossen"}[action]
        return f"Fenster '{real_title}' {past}." if ok else f"Aktion '{action}' fuer Fenster '{real_title}' fehlgeschlagen (X11/xdotool/wmctrl noetig)."
    if action == "focus":
        ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        ctypes.windll.user32.SetForegroundWindow(hwnd)
        return f"Fenster '{real_title}' fokussiert."
    if action == "minimize":
        ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
        return f"Fenster '{real_title}' minimiert."
    if action == "maximize":
        ctypes.windll.user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
        return f"Fenster '{real_title}' maximiert."
    if action == "close":
        ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
        return f"Fenster '{real_title}' geschlossen."
    return f"Unbekannte Aktion '{action}'."


def _resolve_game(game, profiles):
    """Gemeinsame Spiel-Aufloesung fuer game_action UND plan_route: Name/
    Alias/Teilstring-Abgleich gegen die konfigurierten Profile, faellt bei
    genau einem konfigurierten Spiel automatisch darauf zurueck. Gibt
    (matched_key, error) zurueck — error ist None bei Erfolg."""
    if not profiles:
        return None, "Es ist noch kein Spiel konfiguriert. Unter Einstellungen > Spiele ein Spiel und eine Aktion mit Taste hinzufuegen."
    game_needle = (game or "").strip().lower()
    if game_needle:
        if game_needle in profiles:
            return game_needle, None
        for key, p in profiles.items():
            aliases = [a.lower() for a in p.get("aliases", [])]
            if game_needle in aliases or game_needle in (p.get("display_name") or "").lower():
                return key, None
        available = ", ".join(p.get("display_name", k) for k, p in profiles.items())
        return None, f"Kein konfiguriertes Spiel gefunden fuer '{game}'. Konfiguriert sind: {available}."
    if len(profiles) == 1:
        return next(iter(profiles)), None
    available = ", ".join(p.get("display_name", k) for k, p in profiles.items())
    return None, f"Es sind mehrere Spiele konfiguriert ({available}) — bitte angeben, welches gemeint ist."



# Reine Richtungs-/Schaltwoerter — beim wortweisen Abgleich in
# _find_action_by_needle ignoriert, weil sie in vorkonfigurierten Labels oft
# nur EINE Richtung nennen (z.B. "Fahrwerk ausfahren" als Label fuer einen
# Umschalter, den man genauso gut per "Fahrwerk einfahren" ansprechen
# koennte) — das eigentliche Substantiv (Energie, Fahrwerk, Scanmodus, ...)
# soll fuer den Treffer reichen.
_TOGGLE_WORDS = {
    "an", "aus", "ein", "um", "auf", "zu",
    "umschalten", "einschalten", "ausschalten", "anschalten", "abschalten",
    "aktivieren", "deaktivieren", "ausfahren", "einfahren", "umlegen",
    "aktiviere", "deaktiviere", "schalte", "starte", "stoppe",
}

# Bekannte Spracherkennungs-Verhoerer fuer technische Begriffe, die die
# Browser-Spracherkennung phonetisch nicht sauber trifft (z.B. Abkuerzungen
# wie "VTOL") — wird VOR dem eigentlichen Abgleich auf den Needle angewandt,
# NICHT ins Aktions-Label geschrieben, damit die Erfolgsmeldung/gesprochene
# Bestaetigung sauber bleibt und nicht die Verhoerer mitvorliest. Bei neuen
# beobachteten Fehlhoerungen hier einfach ergaenzen.
_ASR_CORRECTIONS = {
    "vitos": "vtol", "wiedholz": "vtol", "wietholz": "vtol", "veto": "vtol",
}


def _apply_asr_corrections(needle):
    return " ".join(_ASR_CORRECTIONS.get(w, w) for w in needle.split())


def _find_action_by_needle(actions, needle):
    """Abgleich gegen Aktionsschluessel/-label, ohne dass der Nutzer sie
    exakt so benennen muss. Reihenfolge: (1) klassischer Teilstring-Treffer
    (wie _spotify_find_own_playlist), (2) wortweiser Abgleich — alle Woerter
    der Anfrage muessen im Aktionsnamen vorkommen, aber nicht zusammen-
    haengend (deckt z.B. 'Energie aus' gegen das Label 'Energie an/aus' ab),
    (3) derselbe wortweise Abgleich nochmal, aber mit ignorierten Richtungs-/
    Schaltwoertern (_TOGGLE_WORDS) — deckt z.B. 'Fahrwerk einfahren' gegen
    ein Label ab, das nur 'ausfahren' nennt, obwohl beides dieselbe
    Umschalt-Taste meint."""
    needle = (needle or "").lower().strip()
    if not needle:
        return None
    needle = _apply_asr_corrections(needle)
    if needle in actions:
        return actions[needle]
    for a_key, a in actions.items():
        if needle in a_key or needle in (a.get("label") or "").lower():
            return a
    needle_words = [w for w in re.split(r"[^\wäöüß]+", needle) if w]
    if not needle_words:
        return None
    match = _best_word_match(actions, needle_words)
    if match:
        return match
    core_words = [w for w in needle_words if w not in _TOGGLE_WORDS]
    if core_words and core_words != needle_words:
        return _best_word_match(actions, core_words)
    return None


def _best_word_match(actions, needle_words):
    best, best_score = None, 0
    for a_key, a in actions.items():
        haystack = (a_key + " " + (a.get("label") or "")).lower()
        score = sum(1 for w in needle_words if w in haystack)
        if score == len(needle_words) and score > best_score:
            best, best_score = a, score
    return best


def _find_click_position(actions, needle):
    """Sucht unter den Mausklick-Aktionen (Feld "click") eine, deren Name das
    Suchwort enthaelt, und gibt {"x", "y"} zurueck — None, wenn es keine gibt
    oder sie noch nicht kalibriert ist (leeres click-Feld)."""
    for a_key, a in actions.items():
        click = a.get("click")
        if not isinstance(click, dict):
            continue
        if needle in (a_key + " " + (a.get("label") or "")).lower() and "x" in click and "y" in click:
            return click
    return None


def _tool_game_action(game, action):
    """Loest eine frei formulierte Spielaktion (z.B. 'Fahrwerk ausfahren')
    gegen die in Einstellungen > Spiele konfigurierten Profile auf und
    presst die zugehoerige Taste — rein textbasierter Abgleich (case-
    insensitive Teilstring, wie _spotify_find_own_playlist), erfindet nie
    einen Tastendruck: bei keinem Treffer kommt eine klare Fehlermeldung mit
    dem, was tatsaechlich konfiguriert ist."""
    profiles = _load_game_profiles()
    matched_key, error = _resolve_game(game, profiles)
    if error:
        return error

    matched_profile = profiles[matched_key]
    # Spielmodus-Sicherheitsgurt: standardmaessig AUS (siehe
    # _load_game_mode_enabled) — nur wenn der Nutzer ihn per Klick aktiviert
    # HAT und fuer dieses Spiel ein process_name konfiguriert ist, wird
    # geprueft, ob es laut Prozessliste gerade wirklich laeuft — sonst gehen
    # Tastendruecke ins Leere oder an ein falsches Fenster. Ist der Modus
    # aus oder kein process_name konfiguriert -> Gurt bleibt aus.
    if _load_game_mode_enabled() and (matched_profile.get("process_name") or "").strip():
        active_key, active_name = get_active_game_mode()
        if active_key != matched_key:
            display_name = matched_profile.get("display_name", matched_key)
            return (
                f"{display_name} scheint gerade nicht zu laufen (Spielmodus inaktiv) — "
                f"keine Taste gesendet. Spiel starten und nochmal versuchen."
            )
    actions = matched_profile.get("actions", {})
    matched_action = _find_action_by_needle(actions, (action or "").strip())
    if matched_action is None:
        available_actions = ", ".join(a.get("label", k) for k, a in actions.items()) or "keine"
        return (
            f"Fuer '{matched_profile.get('display_name', matched_key)}' ist keine Aktion '{action}' konfiguriert. "
            f"Vorhandene Aktionen: {available_actions}. Unter Einstellungen > Spiele hinzufuegen."
        )

    click = matched_action.get("click")
    if isinstance(click, dict):
        if "x" not in click or "y" not in click:
            return f"Mausklick '{matched_action.get('label', action)}' ist noch nicht kalibriert (Einstellungen > Spiele > Position erfassen)."
        _click_at_fraction(click["x"], click["y"])
        return f"Mausklick '{matched_action.get('label', action)}' ausgefuehrt."

    key_string = matched_action.get("key", "")
    if not _press_key_combo(key_string):
        return f"Taste '{key_string}' fuer '{matched_action.get('label', action)}' ist ungueltig konfiguriert."
    return f"'{matched_action.get('label', action)}' ausgefuehrt ({key_string})."


# Bekannte Star-Citizen-Standorte (aus einer vom Nutzer bereitgestellten
# Referenzliste, Stand 12.09.2026) — dient NUR dem unscharfen Abgleich in
# _tool_plan_route (Tippfehler/ASR-Verhoerer beim Zielnamen abfangen), kein
# vollstaendiger Reisefuehrer.
_SC_KNOWN_LOCATIONS = [
    "2930-CRU983",
    "ARC-L1 Wide Forest Station",
    "ARC-L2 Lively Pathway Station",
    "ARC-L3 Modern Express Station",
    "ARC-L4 Faint Glen Station",
    "ARC-L5 Yellow Core Station",
    "Aaron Halo",
    "Aberdeen",
    "Adir",
    "Akiro Cluster",
    "ArcCorp",
    "ArcCorp Mining Area 141",
    "Area18",
    "Area18 (ArcCorp)",
    "Arial",
    "Ashland",
    "Attritus OLP",
    "BGR-560",
    "Baijini Point",
    "Bloom",
    "Bueno Ravine",
    "CAJ-445",
    "CRU-L1 Ambitious Dream Station",
    "CRU-L4 Shallow Fields Station",
    "CRU-L5 Beautiful Glen Station",
    "Calliope",
    "Canard View",
    "Caplan Circuit",
    "Cellin",
    "Chawla’s Beach",
    "Checkmate Station",
    "Clio",
    "Comm Array ST1-02",
    "Comm Array ST1-13",
    "Comm Array ST1-48",
    "Comm Array ST1-61",
    "Comm Array ST1-92",
    "Comm Array ST2-28",
    "Comm Array ST2-47",
    "Comm Array ST2-55",
    "Comm Array ST2-76",
    "Comm Array ST3-18",
    "Comm Array ST3-35",
    "Comm Array ST3-90",
    "Comm Array ST4-22",
    "Comm Array ST4-31",
    "Comm Array ST4-59",
    "Comm Array ST4-64",
    "Covalex Hub Gundo",
    "Crusader",
    "Daymar",
    "Deakins Research Outpost",
    "Delamar",
    "Dudley & Daughters",
    "EMM-567",
    "Endgame",
    "Euterpe",
    "Everus Harbor",
    "FSN-704",
    "Fairo",
    "Fallow Field",
    "Fool’s Run",
    "Fuego",
    "GRP-839",
    "Gaslight",
    "Glaciem Ring",
    "GrimHEX",
    "GrimHEX (Yela)",
    "HDMS-Edmond",
    "HDMS-Hadley",
    "HDMS-Oparei",
    "HDMS-Pinewood",
    "HDMS-Stanhope",
    "HDMS-Thedus",
    "HDSF-Adlai",
    "HDSF-Barnabas",
    "HDSF-Breckinridge",
    "HDSF-Colfax",
    "HDSF-Damaris",
    "HDSF-Elbridge",
    "HDSF-Hendricks",
    "HDSF-Hiram",
    "HDSF-Hobart",
    "HDSF-Ishmael",
    "HDSF-Millerand",
    "HDSF-Rufus",
    "HDSF-Sherman",
    "HDSF-Tamar",
    "HDSF-Tompkins",
    "HDSF-Zacharias",
    "HJS-232",
    "HUR-L1 Green Glade Station",
    "HUR-L2 Faithful Dream Station",
    "HUR-L3 Thundering Express Station",
    "HUR-L4 Melodic Fields Station",
    "HUR-L5 High Course Station",
    "Hickes Research Outpost",
    "Hurston",
    "ICC ScanHub",
    "INS Jericho",
    "Ignis",
    "Ita",
    "JWY-925",
    "Jackson’s Swap",
    "KKE-717",
    "Keeger Belt",
    "LHB-976",
    "Lamina OLP",
    "Last Landings",
    "Levski",
    "Levski (Delamar)",
    "Levski / People’s Service Stations",
    "Lorville",
    "Lorville (Hurston)",
    "Lorville Outskirts",
    "Lyria",
    "MIC-L1 Shallow Frontier Station",
    "MIC-L2 Long Forest Station",
    "MIC-L3 Endless Odyssey Station",
    "MIC-L4 Red Crossroads Station",
    "MIC-L5 Modern Icarus Station",
    "MNK-833",
    "Magda",
    "Magnus Gateway",
    "Megumi Refueling",
    "Miner’s Lament",
    "Monox",
    "NDB-102",
    "New Babbage",
    "New Babbage (microTech)",
    "Nyx",
    "Nyx Gateway (Pyro)",
    "Nyx I",
    "Nyx II",
    "Nyx III",
    "Nyx – Bremen",
    "Nyx – Castra",
    "Nyx – Odin",
    "Nyx – Pyro",
    "Nyx – Stanton",
    "Nyx – Tohil",
    "Nyx – Virgil",
    "Orbituary",
    "Orison",
    "Orison (Crusader)",
    "PQE-291",
    "PYAM-EXHANG-0-1",
    "PYR1 L3 – PYAM-FARSTAT-1-3",
    "PYR3 L4 – PYAM-SUPVISR-3-4",
    "PYR3 L5 – PYAM-FARSTAT-3-5",
    "PYR5 L1 – PYAM-FARSTAT-5-1",
    "PYR5 L3 – PYAM-FARSTAT-5-3",
    "PYR6 L2 – PYAM-FARSTAT-6-2",
    "Patch City",
    "People’s Service Station Alpha",
    "People’s Service Station Delta",
    "People’s Service Station Lambda",
    "People’s Service Station Theta",
    "People’s Service Stations",
    "Port Olisar",
    "Port Tressler",
    "Pyro",
    "Pyro Gateway (Nyx)",
    "Pyro Gateway (Stanton)",
    "Pyro I",
    "Pyro IV",
    "Pyro V",
    "Pyro – Cano",
    "Pyro – Castra",
    "Pyro – Hadrian",
    "Pyro – Nyx",
    "Pyro – Oso",
    "Pyro – Stanton",
    "Pyro – Terra",
    "QV Services Stations",
    "RAB-Alpha",
    "RAB-Bravo",
    "RAB-Charlie",
    "RAB-Cook",
    "RAB-Delta",
    "RAB-Echo",
    "RAB-Foxtrot",
    "RAB-Gulf",
    "RAB-Helio",
    "RAB-Ignition",
    "RAB-Ion",
    "RAB-Jak",
    "RAB-Kilo",
    "RAB-Lamda",
    "RAB-Lynx",
    "RAB-Mat",
    "RAB-November",
    "RAB-Over",
    "RAB-Point",
    "RAB-Quagmire",
    "RAB-Roth",
    "RAB-Sierra",
    "RAB-Tung",
    "RAB-Ultra",
    "RAB-Victory",
    "RAB-Whiskey",
    "RAB-Xeno",
    "RAB-York",
    "RAB-Zeta",
    "RSC-340",
    "Rat’s Nest",
    "Rod’s Fuel ’N Supplies",
    "Ruin Station",
    "Ruptura OLP",
    "Rustville",
    "SGL-693",
    "SZA-178",
    "Sacren’s Plot",
    "Security Post Kareah",
    "Seer’s Canyon",
    "Seraphim Station",
    "Shepherd’s Rest",
    "Stanton",
    "Stanton Gateway (Pyro)",
    "Stanton – Magnus",
    "Stanton – Nyx",
    "Stanton – Pyro",
    "Stanton – Terra",
    "Starlight Service Station",
    "Sunset Mesa",
    "TYS-908",
    "Terminus",
    "Terra Gateway (Stanton)",
    "The Icebreaker",
    "The Sky Scraper",
    "VUP-613",
    "Vatra",
    "Vivere OLP",
    "Vuur",
    "WDH-387",
    "Wala",
    "Wikelo Emporium Dasi Station",
    "Wikelo Emporium Kinga Station",
    "Wikelo Emporium Selo Station",
    "YKA-011",
    "Yadar Valley",
    "Yela",
    "microTech",
]


def _tool_plan_route(game, destination):
    """Oeffnet die Sternenkarte/Navigationskarte des Spiels, klickt zuerst in
    das Suchfeld (Mausklick-Aktion "Suchfeld" — ohne diesen Klick landet die Eingabe
    nirgendwo, das Suchfeld ist nach dem Kartenoeffnen nicht automatisch
    fokussiert), tippt dann das Ziel ein und bestaetigt das oberste
    Suchergebnis per Mausklick (manche Spiele wie Star Citizen akzeptieren
    dafuer kein Enter, nur einen echten Klick) — beide Klickpositionen kommen
    aus dem Profil (jeweils als Bildschirm-Anteil 0.0-1.0, aufloesungs-
    unabhaengig) und muessen der Nutzer einmalig fuer sein eigenes UI-Layout
    kalibrieren. Ist keine Suchfeld-Klickposition konfiguriert, wird direkt
    (ohne vorherigen Klick) getippt — Ist keine Ergebnis-Klickposition
    konfiguriert, wird ersatzweise Enter versucht — bestmoegliche
    Automatisierung ohne Bildschirm-Rueckmeldung, kein garantierter Erfolg."""
    destination = (destination or "").strip()
    if not destination:
        return "Kein Ziel angegeben."
    profiles = _load_game_profiles()
    matched_key, error = _resolve_game(game, profiles)
    if error:
        return error
    matched_profile = profiles[matched_key]
    # Verhoerte/leicht falsch geschriebene Zielnamen (Sprach-ASR) auf die
    # bekannte Standortliste korrigieren, BEVOR getippt wird — nur fuer Star
    # Citizen (dafuer liegt die Liste vor) und nur bei einer wirklich engen
    # Uebereinstimmung (cutoff hoch), damit kein voellig falscher Ort
    # eingetippt wird, wenn der genannte Ort einfach nicht in der Liste ist.
    if matched_key == "star citizen":
        close = difflib.get_close_matches(
            destination.lower(), [loc.lower() for loc in _SC_KNOWN_LOCATIONS], n=1, cutoff=0.72
        )
        if close:
            canonical = next(loc for loc in _SC_KNOWN_LOCATIONS if loc.lower() == close[0])
            if canonical != destination:
                destination = canonical
    actions = matched_profile.get("actions", {})
    map_action = (
        _find_action_by_needle(actions, "sternenkarte")
        or _find_action_by_needle(actions, "starmap")
        or _find_action_by_needle(actions, "karte")
    )
    if map_action is None:
        return (
            f"Fuer '{matched_profile.get('display_name', matched_key)}' ist keine Sternenkarten-/"
            f"Navigationstaste konfiguriert. Unter Einstellungen > Spiele eine Aktion mit "
            f"'Sternenkarte' im Namen hinzufuegen."
        )
    if not _press_key_combo(map_action.get("key", "")):
        return f"Taste '{map_action.get('key', '')}' fuer die Sternenkarte ist ungueltig konfiguriert."
    time.sleep(1.2)  # Kartenoeffnungs-Animation abwarten, sonst kommen die getippten Zeichen zu frueh an
    search_click_pos = _find_click_position(actions, "suchfeld")
    if search_click_pos:
        _click_at_fraction(search_click_pos["x"], search_click_pos["y"])
        time.sleep(0.9)  # warten, bis das Suchfeld wirklich fokussiert/bereit ist, bevor getippt wird
    _type_text(destination)
    time.sleep(0.5)  # Zeit fuer die Ergebnisliste, sich nach der Eingabe zu aktualisieren
    click_pos = _find_click_position(actions, "suchergebnis")
    if click_pos:
        _click_at_fraction(click_pos["x"], click_pos["y"])
    else:
        _press_key_combo("Enter")
    return (
        f"Route nach '{destination}' eingegeben und bestaetigt. Kurz im Spiel pruefen, ob die "
        f"Sternenkarte das Ziel korrekt uebernommen hat — ohne Bildschirmzugriff kann ich das "
        f"nicht selbst kontrollieren."
    )


# ---------------------------------------------------------------------------
# Browser-Steuerung: URLs oeffnen + "neuestes Video von Kanal X" auf YouTube.
# Bewusst OHNE YouTube-API-Key geloest — jeder YouTube-Kanal hat einen
# oeffentlichen RSS-Feed (kein Login/Key noetig), der die zuletzt hochgeladenen
# Videos chronologisch liefert. Kanalname -> channel_id wird durch einmaliges
# Abrufen der Kanal-/Suchseite und Regex auf das darin eingebettete
# "channelId":"UC..." aufgeloest (kein zusaetzliches pip-Paket noetig, nur
# Python-Standardbibliothek). Nur http/https-URLs werden geoeffnet, damit ein
# Tool-Aufruf nicht auf andere registrierte Protokoll-Handler zielen kann.
# ---------------------------------------------------------------------------
import re
import urllib.request
import urllib.parse
import webbrowser
import xml.etree.ElementTree as ET

_YT_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
_YT_CHANNEL_ID_RE = re.compile(r'"channelId":"(UC[0-9A-Za-z_-]{22})"')


def _yt_fetch(url):
    req = urllib.request.Request(url, headers=_YT_HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _resolve_youtube_channel_id(name):
    handle = re.sub(r"\s+", "", name)
    candidate_urls = (
        f"https://www.youtube.com/@{urllib.parse.quote(handle)}",
        f"https://www.youtube.com/results?search_query={urllib.parse.quote(name)}",
    )
    for url in candidate_urls:
        try:
            html = _yt_fetch(url)
        except Exception:
            continue
        m = _YT_CHANNEL_ID_RE.search(html)
        if m:
            return m.group(1)
    return None


def _tool_play_youtube_latest(channel):
    if not channel:
        return "Kein Kanalname angegeben."
    channel_id = _resolve_youtube_channel_id(channel)
    if not channel_id:
        return f"Konnte den YouTube-Kanal '{channel}' nicht finden."
    try:
        feed_xml = _yt_fetch(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}")
        root = ET.fromstring(feed_xml)
    except Exception as e:
        return f"Konnte die Videoliste von '{channel}' nicht laden: {e}"
    ns = {"atom": "http://www.w3.org/2005/Atom"}
    entry = root.find("atom:entry", ns)
    if entry is None:
        return f"Keine Videos fuer '{channel}' gefunden."
    link_el = entry.find("atom:link", ns)
    video_url = link_el.get("href") if link_el is not None else None
    title_el = entry.find("atom:title", ns)
    title = title_el.text if title_el is not None else "unbekannter Titel"
    if not video_url:
        return f"Konnte das neueste Video von '{channel}' nicht oeffnen."
    webbrowser.open(video_url)
    return f"Spiele „{title}“ von {channel} ab."


_YT_VIDEO_RE = re.compile(r'"videoRenderer":\{"videoId":"([0-9A-Za-z_-]{11})"')
_YT_TITLE_RE = re.compile(r'"videoRenderer":\{"videoId":"([0-9A-Za-z_-]{11})".{0,1500}?"title":\{"runs":\[\{"text":"([^"]{1,200})"')


def _tool_play_youtube(query, music=False):
    """Beliebiges Video (oder Song auf YouTube Music) per Suchbegriff finden und
    im Standardbrowser abspielen - ohne API-Key: das erste Suchergebnis wird aus
    der YouTube-Ergebnisseite gelesen, dann direkt die Abspiel-Seite geoeffnet."""
    query = (query or "").strip()
    if not query:
        return "Kein Suchbegriff angegeben."
    try:
        html = _yt_fetch("https://www.youtube.com/results?search_query=" + urllib.parse.quote(query) + "&sp=EgIQAQ%253D%253D")  # nur Videos
    except Exception as e:
        return f"YouTube-Suche fehlgeschlagen: {e}"
    m = _YT_TITLE_RE.search(html)
    vid, title = (m.group(1), m.group(2)) if m else (None, None)
    if not vid:
        m2 = _YT_VIDEO_RE.search(html)
        vid, title = (m2.group(1), query) if m2 else (None, None)
    if not vid:
        return f"Nichts zu '{query}' auf YouTube gefunden."
    host = "music.youtube.com" if music else "www.youtube.com"
    webbrowser.open(f"https://{host}/watch?v={vid}")
    try:
        title = json.loads('"' + title + '"')
    except Exception:
        pass
    return f"Spiele „{title}“ auf {'YouTube Music' if music else 'YouTube'}."


def _tool_open_url(url):
    if not url or not re.match(r"^https?://", url, re.IGNORECASE):
        return "Nur http/https-URLs sind erlaubt."
    webbrowser.open(url)
    return f"Öffne {url} im Browser."


def _emit_link(url, label):
    """Link fuer den Nutzer bereitstellen: vom Handy aus in der Antwort, am PC
    zusaetzlich direkt im Browser."""
    _chat_ctx["links"].append({"url": url, "label": label})
    if not _chat_ctx["remote"]:
        webbrowser.open(url)


def _tool_maps_route(destination, origin="", mode="driving"):
    destination = (destination or "").strip()
    if not destination:
        return "Kein Ziel angegeben."
    travel = {"driving": "driving", "walking": "walking", "bicycling": "bicycling", "transit": "transit"}.get(mode or "driving", "driving")
    url = "https://www.google.com/maps/dir/?api=1&destination=" + urllib.parse.quote(destination) + "&travelmode=" + travel
    if (origin or "").strip():
        url += "&origin=" + urllib.parse.quote(origin.strip())
    _emit_link(url, "Route nach " + destination)
    return f"Route nach '{destination}' ({travel}) in Google Maps bereit - Start ist der aktuelle Standort, falls kein Start genannt wurde."


def _tool_find_restaurant(query, people=None, when=None):
    query = (query or "").strip()
    if not query:
        return "Kein Restaurant/Suchbegriff angegeben."
    _emit_link("https://www.google.com/maps/search/?api=1&query=" + urllib.parse.quote(query), "Auf Google Maps: " + query)
    ot = "https://www.opentable.de/s?term=" + urllib.parse.quote(query)
    detail = []
    try:
        n = int(people)
        if 1 <= n <= 20:
            ot += f"&covers={n}"
            detail.append(f"{n} Personen")
    except (TypeError, ValueError):
        pass
    if when:
        m = re.match(r"^\s*(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})", str(when))
        if m:
            ot += f"&dateTime={m.group(1)}T{int(m.group(2)):02d}:{m.group(3)}"
            detail.append(f"{m.group(1)} {int(m.group(2)):02d}:{m.group(3)} Uhr")
    _emit_link(ot, "Tisch reservieren (OpenTable)" + (": " + ", ".join(detail) if detail else ""))
    return (
        f"Links fuer '{query}' bereit ({', '.join(detail) or 'ohne Personen/Zeit'}): Karte + Reservierungsseite mit vorausgefuellten Daten. "
        "Die Buchung selbst muss der Nutzer auf der Seite bestaetigen - ich kann nicht selbst verbindlich buchen."
    )


def _tool_search_web(query):
    if not query:
        return "Kein Suchbegriff angegeben."
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(query))
    return f"Suche nach „{query}“ geöffnet."


# ---------------------------------------------------------------------------
# Echte Web-Suche mit Ergebnis-Text fuer OpenAI/Groq: die haben (anders als
# Anthropic) kein eingebautes Server-Search-Tool in der hier genutzten API,
# also holen wir Ergebnis-Schnipsel selbst (DuckDuckGo-HTML, kein API-Key
# noetig) und geben sie dem Modell als Tool-Ergebnis zum Auswerten mit —
# nur bewusst simples Regex-Parsing (kein neues pip-Paket), daher etwas
# empfindlich gegenueber Aenderungen an DuckDuckGos HTML-Struktur.
# ---------------------------------------------------------------------------
import html as _html_lib


def _duckduckgo_search(query, max_results=5):
    page = _yt_fetch("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query))
    titles_links = re.findall(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S)
    snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', page, re.S)
    results = []
    for i, (href, title_html) in enumerate(titles_links[:max_results]):
        real_url = href
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        if "uddg" in qs:
            real_url = urllib.parse.unquote(qs["uddg"][0])
        title = _html_lib.unescape(re.sub(r"<[^>]+>", "", title_html)).strip()
        snippet = _html_lib.unescape(re.sub(r"<[^>]+>", "", snippets[i])).strip() if i < len(snippets) else ""
        results.append({"title": title, "url": real_url, "snippet": snippet})
    return results


def _tool_web_search_answer(query):
    if not query:
        return "Kein Suchbegriff angegeben."
    try:
        results = _duckduckgo_search(query)
    except Exception as e:
        return f"Suche fehlgeschlagen: {e}"
    if not results:
        return f"Keine Ergebnisse fuer '{query}' gefunden."
    lines = [f"Suchergebnisse fuer '{query}':"]
    for r in results:
        lines.append(f"- {r['title']}: {r['snippet']} ({r['url']})")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# GEHIRN: dauerhaftes Gedaechtnis. Alles, was A.R.I ueber den Nutzer lernt,
# landet in data/brain.json, wird bei JEDER Antwort in den System-Prompt
# eingespeist (so wird er mit der Zeit "schlauer") und im HUD als 3D-Netz
# visualisiert.
# ---------------------------------------------------------------------------
BRAIN_FILE = os.path.join(DATA_DIR, "brain.json")
BRAIN_CATEGORIES = [
    "Wissen", "Vorlieben", "Personen", "Projekte", "Spiele", "Gewohnheiten", "Aufgaben",
    "Musik", "Medien", "Technik", "Arbeit", "Lernen", "Ziele", "Gesundheit", "Finanzen",
    "Familie", "Freunde", "Orte", "Reisen", "Termine", "Essen", "Hobbys", "Mail und Meldungen",
]
_BRAIN_MAX_NODES = 400
_BRAIN_PROMPT_MAX = 30
_brain_lock = threading.Lock()


def _brain_load():
    try:
        with open(BRAIN_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        nodes = data.get("nodes", []) if isinstance(data, dict) else []
        return [n for n in nodes if isinstance(n, dict) and n.get("id") and n.get("text")]
    except (OSError, ValueError):
        return []


def _brain_save(nodes):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = BRAIN_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"nodes": nodes}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, BRAIN_FILE)


_BRAIN_MAX_CATS = 30


def _brain_categories(nodes=None):
    """Standard-Bereiche + alle, die A.R.I selbst angelegt hat."""
    cats = list(BRAIN_CATEGORIES)
    for n in (nodes if nodes is not None else _brain_load()):
        c = n.get("cat")
        if c and c not in cats:
            cats.append(c)
    return cats


def _brain_norm_cat(cat, existing=None):
    """Bekannte Kategorie (case-insensitiv) wiederverwenden, sonst eine neue
    kurze anlegen (max. _BRAIN_MAX_CATS insgesamt, sonst 'Wissen')."""
    c = re.sub(r"[^A-Za-z0-9\u00c4\u00d6\u00dc\u00e4\u00f6\u00fc\u00df \-]", "", cat or "").strip()[:24]
    if not c:
        return "Wissen"
    known = existing if existing is not None else _brain_categories()
    for k in known:
        if k.lower() == c.lower():
            return k
    if len(known) >= _BRAIN_MAX_CATS:
        return "Wissen"
    return c[:1].upper() + c[1:]


def _brain_add(text, cat=None):
    """Legt eine Erinnerung an. Gibt (node, dup) zurueck; dup=True wenn es
    sie (fast) schon gibt — dann wird nur der Zaehler erhoeht."""
    text = re.sub(r"\s+", " ", (text or "")).strip()[:300]
    if len(text) < 3:
        return None, False
    with _brain_lock:
        nodes = _brain_load()
        low = text.lower()
        for n in nodes:
            other = n["text"].lower()
            if other == low or difflib.SequenceMatcher(None, other, low).ratio() > 0.88:
                n["uses"] = int(n.get("uses", 0)) + 1
                _brain_save(nodes)
                return n, True
        node = {
            "id": uuid.uuid4().hex[:10],
            "text": text,
            "cat": _brain_norm_cat(cat, _brain_categories(nodes)),
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "uses": 0,
        }
        nodes.append(node)
        if len(nodes) > _BRAIN_MAX_NODES:
            nodes.sort(key=lambda n: (int(n.get("uses", 0)), n.get("created", "")))
            nodes = nodes[len(nodes) - _BRAIN_MAX_NODES:]
        _brain_save(nodes)
        return node, False


def _brain_forget(query):
    q = (query or "").strip().lower()
    if not q:
        return 0
    with _brain_lock:
        nodes = _brain_load()
        keep = [n for n in nodes if n["id"] != q and q not in n["text"].lower()]
        removed = len(nodes) - len(keep)
        if removed:
            _brain_save(keep)
        return removed


_BRAIN_LIVE_PREFIXES = ("cal:", "mail:", "note:")
_BRAIN_MAIL_CAT = "Mail und Meldungen"
_brain_sync_state = {"t": 0.0, "running": False}


def _brain_when(iso):
    try:
        if iso and "T" in iso:
            return datetime.datetime.fromisoformat(iso.replace("Z", "+00:00")).strftime("%d.%m. %H:%M")
        return datetime.datetime.fromisoformat(iso).strftime("%d.%m.")
    except (ValueError, TypeError):
        return str(iso or "")


def _brain_replace_live(prefix, cat, items):
    """items: {key: text}. Ersetzt alle Eintraege mit diesem Praefix (alte
    Termine/Mails verschwinden), behaelt id/Datum/Nutzung bestehender Keys."""
    with _brain_lock:
        nodes = _brain_load()
        old = {n.get("key"): n for n in nodes if str(n.get("key", "")).startswith(prefix)}
        nodes = [n for n in nodes if not str(n.get("key", "")).startswith(prefix)]
        for key, text in items.items():
            prev = old.get(key)
            nodes.append({
                "id": prev["id"] if prev else uuid.uuid4().hex[:10], "key": key, "text": text[:300], "cat": cat,
                "created": prev["created"] if prev else datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                "uses": prev.get("uses", 0) if prev else 0,
            })
        _brain_save(nodes)


def _brain_sync_live():
    """Zieht aktuelle Kalender-Termine und ungelesene Mails ins Gehirn
    (Hintergrund, gedrosselt) - schlaegt eine Quelle fehl, bleibt der alte
    Stand dieser Quelle unveraendert."""
    try:
        events, err = get_upcoming_events(days=30, max_results=30, days_back=0)
        if not err and events is not None:
            _brain_replace_live("cal:", "Termine", {
                "cal:" + str(e.get("id")): f"Termin: {e.get('title', '(Ohne Titel)')} - {_brain_when(e.get('start'))}" for e in events
            })
    except Exception as e:
        print(f"[brain] Kalender-Sync uebersprungen: {e}")
    try:
        mails, err = get_recent_emails(unread_only=True, max_results=10)
        if not err and mails is not None:
            _brain_replace_live("mail:", _BRAIN_MAIL_CAT, {
                "mail:" + str(m["id"]): f"E-Mail von {m.get('from_name') or m.get('from', '?')}: {m.get('subject', '(kein Betreff)')}" for m in mails
            })
    except Exception as e:
        print(f"[brain] Mail-Sync uebersprungen: {e}")
    _brain_sync_state["running"] = False


def _brain_sync_kick():
    if _brain_sync_state["running"] or time.time() - _brain_sync_state["t"] < 90:
        return
    _brain_sync_state["running"] = True
    _brain_sync_state["t"] = time.time()
    threading.Thread(target=_brain_sync_live, daemon=True).start()


def _brain_prompt_block(query=""):
    nodes = _brain_load()
    if not nodes:
        return ""
    nodes.sort(key=lambda n: (int(n.get("uses", 0)), n.get("created", "")), reverse=True)
    words = {w for w in re.findall(r"[a-zäöüß0-9]{4,}", (query or "").lower())}
    if words and len(nodes) > _BRAIN_PROMPT_MAX:
        # Token sparen: erst die zur Frage passenden Eintraege, dann die meistgenutzten.
        def score(n):
            txt = (str(n.get("text", "")) + " " + str(n.get("cat", ""))).lower()
            return sum(1 for w in words if w in txt)
        relevant = sorted((n for n in nodes if score(n) > 0), key=score, reverse=True)[:_BRAIN_PROMPT_MAX // 2]
        ids = {id(n) for n in relevant}
        nodes = relevant + [n for n in nodes if id(n) not in ids]
    # Live-Eintraege (Termine/Mails) NICHT in den Prompt: veralten schnell und
    # sollen keine Mail-Betreffe an den KI-Anbieter mitschicken.
    nodes = [n for n in nodes if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    if not nodes:
        return ""
    lines = [f"- [{n.get('cat', 'Wissen')}] {n['text']}" for n in nodes[:_BRAIN_PROMPT_MAX]]
    return (
        "\n\nDEIN GEDAECHTNIS (was du ueber den Nutzer gelernt hast - nutze es "
        "selbstverstaendlich und ungefragt, erwaehne nicht jedes Mal, dass du es "
        "gespeichert hast):\n" + "\n".join(lines)
    )


_BRAIN_PROMPT_RULES = (
    "\n\nGEDAECHTNIS-REGEL: Erfaehrst du etwas Dauerhaftes ueber den Nutzer "
    "(Vorlieben, Namen, Personen, Projekte, Gewohnheiten, Setup, Ziele) oder "
    "sagt er 'merk dir ...', rufe das Tool remember auf - knapp als ganzer Satz "
    "und mit passender Kategorie - passt keine bestehende, waehle eine neue kurze. Keine Belanglosigkeiten, keine Passwoerter/Keys. "
    "Sagt er 'vergiss ...', nutze forget. Fragen ueber den Nutzer selbst (Hobbys, "
    "Familie, Vorlieben, Termine, was er mag) beantwortest du NUR aus deinem "
    "Gedaechtnis unten - steht dazu nichts drin, sag ehrlich, dass du es noch "
    "nicht weisst, und frag kurz nach; erfinde nichts und vermische keine "
    "Vermutungen mit Fakten. Nennt er dir dann die Antwort, speichere sie mit remember."
)


def _volume_rule(volume_target):
    if volume_target == "spotify":
        return ("\n\nLAUTSTAERKE: Befehle wie 'Lautstaerke auf 50', lauter, leiser, leise meinen die Lautstaerke von SPOTIFY "
                "(Tool set_spotify_volume). Nur wenn der Nutzer ausdruecklich Windows, System oder Computer sagt, nimm control_volume.")
    return ("\n\nLAUTSTAERKE: Befehle wie 'Lautstaerke auf 50', lauter, leiser, leise meinen IMMER die Windows-Systemlautstaerke "
            "(Tool control_volume). Nimm set_spotify_volume NUR, wenn der Nutzer ausdruecklich Spotify erwaehnt.")


def _system_prompt(language=None, volume_target=None, query=""):
    base = SYSTEM_PROMPT
    extra = ""
    lang = (language or "").strip()
    if lang and lang.lower() not in ("german", "deutsch"):
        base = base.replace("auf Deutsch (die", "auf " + lang + " (die")
        extra = ("\n\nSPRACHE: Der Nutzer nutzt " + lang + " als Systemsprache. Antworte IMMER auf " + lang +
                 " (auch wenn diese Anweisungen deutsch sind); die Anreden wie 'Boss' oder 'Chief' duerfen bleiben.")
    return base + extra + _volume_rule(volume_target) + _BRAIN_PROMPT_RULES + _brain_prompt_block(query)


def _tool_remember(text, category):
    node, dup = _brain_add(text, category)
    if not node:
        return "Nichts gespeichert (Text zu kurz)."
    return "Schon bekannt, Erinnerung verstaerkt." if dup else f"Gemerkt ({node['cat']}): {node['text']}"


def _tool_forget(query):
    n = _brain_forget(query)
    return f"{n} Erinnerung(en) vergessen." if n else "Dazu habe ich nichts gespeichert."


@app.route("/brain", methods=["GET"])
def brain_get():
    _brain_sync_kick()
    nodes = _brain_load()
    return jsonify({"categories": _brain_categories(nodes), "nodes": nodes})


@app.route("/brain", methods=["POST"])
def brain_post():
    data = request.get_json(silent=True) or {}
    node, dup = _brain_add(data.get("text", ""), data.get("cat"))
    if not node:
        return jsonify({"error": "Text zu kurz"}), 400
    return jsonify({"error": None, "node": node, "dup": dup})


@app.route("/brain/delete", methods=["POST"])
def brain_delete():
    data = request.get_json(silent=True) or {}
    nid = str(data.get("id", "")).strip()
    if not nid:
        return jsonify({"error": "id fehlt"}), 400
    with _brain_lock:
        nodes = _brain_load()
        keep = [n for n in nodes if n["id"] != nid]
        _brain_save(keep)
    return jsonify({"error": None, "removed": len(nodes) - len(keep)})




BRAIN_STATS_FILE = os.path.join(DATA_DIR, "brain_stats.json")
_BRAIN_TOOL_STEPS = (3, 10, 25, 50, 100, 250)
_BRAIN_TOOL_LABELS = {
    "control_volume": "die Lautstaerke-Steuerung", "play_spotify": "Spotify-Wiedergabe",
    "control_media": "die Mediensteuerung", "open_app": "das Oeffnen von Apps",
    "close_app": "das Schliessen von Apps", "take_screenshot": "Screenshots",
    "game_action": "Spiel-Sprachbefehle", "plan_route": "die Routenplanung",
    "manage_window": "die Fensterverwaltung", "window_action": "Fenster-Aktionen",
}


def _brain_upsert(key, text, cat):
    """Legt eine automatisch abgeleitete Erinnerung an oder aktualisiert sie
    (gleicher key) - so waechst ein Eintrag mit, statt Duplikate zu erzeugen."""
    with _brain_lock:
        nodes = _brain_load()
        for n in nodes:
            if n.get("key") == key:
                n["text"] = text
                _brain_save(nodes)
                return
        nodes.append({
            "id": uuid.uuid4().hex[:10], "key": key, "text": text[:300],
            "cat": _brain_norm_cat(cat, _brain_categories(nodes)),
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "uses": 0,
        })
        _brain_save(nodes)


def _brain_reinforce(user_text):
    """Erinnerungen, die zur aktuellen Nachricht passen, werden staerker
    (uses+1) - haeufig Relevantes waechst im Netz und im Prompt nach oben."""
    ws = {w for w in re.findall(r"[a-z\u00e4\u00f6\u00fc\u00df0-9]{5,}", user_text.lower())}
    if not ws:
        return
    with _brain_lock:
        nodes = _brain_load()
        hit = False
        for n in nodes:
            if ws & set(re.findall(r"[a-z\u00e4\u00f6\u00fc\u00df0-9]{5,}", n["text"].lower())):
                n["uses"] = int(n.get("uses", 0)) + 1
                hit = True
        if hit:
            _brain_save(nodes)


def _brain_track(user_text, tools_used):
    """Lernt Gewohnheiten aus dem Verhalten - ganz ohne Modell-Aufruf:
    welche Funktionen oft genutzt werden und zu welcher Tageszeit."""
    try:
        try:
            with open(BRAIN_STATS_FILE, "r", encoding="utf-8") as f:
                st = json.load(f)
        except (OSError, ValueError):
            st = {}
        tools = st.setdefault("tools", {})
        buckets = st.setdefault("buckets", {})
        h = datetime.datetime.now().hour
        b = "morgens" if 5 <= h < 11 else "mittags" if 11 <= h < 15 else "nachmittags" if 15 <= h < 18 else "abends" if 18 <= h < 23 else "nachts"
        buckets[b] = buckets.get(b, 0) + 1
        st["total"] = st.get("total", 0) + 1
        for t in set(tools_used or []):
            if t in ("remember", "forget"):
                continue
            tools[t] = tools.get(t, 0) + 1
            n = tools[t]
            if n in _BRAIN_TOOL_STEPS:
                label = _BRAIN_TOOL_LABELS.get(t, "die Funktion " + t.replace("_", " "))
                _brain_upsert("tool:" + t, f"Der Nutzer nutzt oft {label} (bisher {n}x).", "Gewohnheiten")
        if st["total"] % 10 == 0:
            top, cnt = max(buckets.items(), key=lambda kv: kv[1])
            if cnt / st["total"] >= 0.5:
                _brain_upsert("time", f"Der Nutzer ist meist {top} mit A.R.I aktiv.", "Gewohnheiten")
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(BRAIN_STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
        _brain_reinforce(user_text)
    except Exception as e:
        print(f"[brain] Tracking uebersprungen: {e}")


_BRAIN_CUES = re.compile(
    r"\b(ich|mein|meine|meinen|meinem|meiner|mir|mich|wir|unser|unsere|merk|vergiss|immer|nie|niemals|"
    r"heisse|hei\u00dfe|bin|habe|hab|mag|liebe|hasse|nutze|benutze|arbeite|spiele|wohne|studiere|plane|will|m\u00f6chte|moechte)\b",
    re.IGNORECASE,
)

_BRAIN_EXTRACT_PROMPT = (
    "Du bist das Lern-Modul eines Assistenten und baust sein Gedaechtnis auf. "
    "Du bekommst einen Gespraechsausschnitt ('Nutzer:' und 'A.R.I:'). Extrahiere "
    "ALLES Merkenswerte, das der NUTZER gesagt hat - in JEDEM Lebensbereich: "
    "Vorlieben, Abneigungen, Personen, Familie, Freunde, Projekte, Arbeit, Schule/"
    "Lernen, Hobbys, Spiele, Musik, Gesundheit, Finanzen, Orte, Reisen, Termine, "
    "Ziele, Gewohnheiten, Technik/Setup, aber auch Wissen/Regeln, die er dir "
    "beibringt, und Korrekturen. Auch Antworten auf Fragen von A.R.I zaehlen "
    "(z.B. A.R.I fragt nach Hobbys, Nutzer: 'Fussball' -> Hobby Fussball). "
    "Aussagen von A.R.I selbst sind KEINE Fakten - nur uebernehmen, wenn der Nutzer "
    "sie bestaetigt. Nicht speichern: reine Befehle (Musik an, Lautstaerke), "
    "Wetter/News-Fragen, Smalltalk, Passwoerter/Keys/Kontodaten. Jeder Fakt ein "
    "kurzer ganzer deutscher Satz in dritter Person ueber den Nutzer (z.B. 'Der "
    "Nutzer spielt Fussball.'). Kategorie je Fakt: bevorzugt eine von {cats}; passt "
    "keine, erfinde eine NEUE kurze (1-2 Woerter). Widerspricht der Nutzer einem "
    "frueheren Fakt ('nein, ich mag X nicht mehr'), gib zusaetzlich "
    "{{\"forget\":\"Stichwort\"}} aus. Antworte AUSSCHLIESSLICH mit einem JSON-Array "
    "wie [{{\"text\":\"...\",\"cat\":\"...\"}}] - oder [] wenn nichts Merkenswertes "
    "drinsteht. Maximal 6 Eintraege."
)


def _brain_extract_call(provider, keys_and_clients, user_text):
    prompt = _BRAIN_EXTRACT_PROMPT.format(cats=", ".join(_brain_categories()))
    if provider == "anthropic":
        r = keys_and_clients[0][1].messages.create(
            model=ANTHROPIC_MODEL, max_tokens=300, system=prompt,
            messages=[{"role": "user", "content": user_text}],
        )
        return next((b.text for b in r.content if b.type == "text"), "")
    model = {"openai": OPENAI_MODEL, "gemini": GEMINI_MODEL}.get(provider, GROQ_MODEL)
    c = _call_with_key_rotation(
        keys_and_clients,
        lambda client: client.chat.completions.create(
            model=model, max_tokens=300,
            messages=[{"role": "system", "content": prompt}, {"role": "user", "content": user_text}],
        ),
    )
    return c.choices[0].message.content or ""


def _brain_autolearn(provider, keys_and_clients, user_text):  # user_text darf mehrere Nachrichten enthalten
    """Laeuft im Hintergrund nach jeder Antwort: laesst das Modell aus der
    Nutzer-Nachricht dauerhafte Fakten ziehen und speichert sie - ohne dass
    der Nutzer 'merk dir' sagen muss."""
    try:
        raw = _brain_extract_call(provider, keys_and_clients, user_text[-1800:])
        m = re.search(r"\[.*\]", raw, re.DOTALL)
        if not m:
            return
        for item in json.loads(m.group(0))[:6]:
            if isinstance(item, dict) and isinstance(item.get("forget"), str) and len(item["forget"].strip()) >= 3:
                n = _brain_forget(item["forget"])
                if n:
                    print(f"[brain] vergessen ({n}): {item['forget']}")
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                node, dup = _brain_add(item["text"], item.get("cat"))
                if node and not dup:
                    print(f"[brain] gelernt ({node['cat']}): {node['text']}")
    except Exception as e:
        print(f"[brain] Auto-Lernen uebersprungen: {e}")


def _brain_maybe_autolearn(provider, keys_and_clients, user_text, reply, tools_used, context=None, answering=False):
    _brain_track(user_text, tools_used)
    # Lernen bei fast jeder Nachricht: bei persoenlichem Bezug, laengeren Saetzen
    # oder wenn der Nutzer gerade eine Rueckfrage von A.R.I beantwortet.
    if "remember" in (tools_used or []) or len(user_text.strip()) < 6:
        return
    if not (_BRAIN_CUES.search(user_text) or len(user_text) >= 25 or answering):
        return
    if provider == "groq" and groq_status_snapshot([k for k, _ in keys_and_clients])["rate_limited"]:
        return
    threading.Thread(target=_brain_autolearn, args=(provider, keys_and_clients, context or user_text), daemon=True).start()


BRAIN_TOOLS = [
    {
        "name": "remember",
        "description": "Speichert eine dauerhafte Erinnerung im Gehirn (wird in allen kuenftigen Gespraechen genutzt). Fuer Vorlieben, Personen, Projekte, Gewohnheiten, Setup, Ziele oder wenn der Nutzer 'merk dir' sagt. Als kurzer ganzer Satz.",
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Die Erinnerung, z.B. 'Moritz spielt am liebsten Star Citizen mit HOTAS.'"},
                "category": {"type": "string", "description": "Bereich - waehle die passendste der vorhandenen (Wissen, Vorlieben, Personen, Projekte, Spiele, Gewohnheiten, Aufgaben, Musik, Medien, Technik, Arbeit, Lernen, Ziele, Gesundheit, Finanzen, Familie, Freunde, Orte, Reisen, Termine, Essen, Hobbys) - oder ein NEUER kurzer Bereichsname (1-2 Woerter), wenn nichts davon passt (z.B. Gesundheit, Musik, Finanzen)."},
            },
            "required": ["text"],
        },
    },
    {
        "name": "forget",
        "description": "Loescht Erinnerungen aus dem Gehirn, deren Text den Suchbegriff enthaelt.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
]


TOOLS = [
    {
        "name": "control_volume",
        "description": "Windows-SYSTEMlautstaerke steuern (Gesamtlautstaerke aller Apps): lauter, leiser, stummschalten umschalten, oder direkt auf einen Prozentwert setzen. Fuer NUR Spotifys eigene Lautstaerke stattdessen set_spotify_volume nutzen (falls verbunden).",
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["up", "down", "mute", "set"]},
                "steps": {"type": "integer", "minimum": 1, "maximum": 10, "description": "Anzahl Lauter/Leiser-Schritte (nur bei up/down, Standard 2)."},
                "percent": {"type": "integer", "minimum": 0, "maximum": 100, "description": "Ziel-Lautstaerke in Prozent (nur bei action=set), z.B. 70."},
            },
            "required": ["action"],
        },
    },
    {
        "name": "set_spotify_volume",
        "description": "Setzt Spotifys EIGENE Lautstaerke ueber die Spotify-API (nicht die Windows-Systemlautstaerke) — braucht eine verbundene Spotify-Anbindung. Aktiviert Spotify bei Bedarf automatisch (startet es notfalls sogar selbst), kein manuelles Play noetig.",
        "input_schema": {
            "type": "object",
            "properties": {"percent": {"type": "integer", "minimum": 0, "maximum": 100}},
            "required": ["percent"],
        },
    },
    {
        "name": "get_current_spotify_track",
        "description": "Fragt ab, welcher Titel gerade auf Spotify laeuft (Name + Interpret*in) — nutzen bei Fragen wie 'was laeuft gerade', 'welches Lied kommt/ist das' oder 'wer singt das'. Erfindet nie einen Songnamen, wenn gerade nichts laeuft.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "play_spotify",
        "description": "Startet die Wiedergabe von etwas auf Spotify per Freitextsuche — Playlist, Song, Album oder Kuenstler. Aktiviert Spotify bei Bedarf automatisch (startet es notfalls sogar selbst), kein manuelles Play noetig.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Suchbegriff, z.B. 'Deep House Mix' oder 'Bohemian Rhapsody' oder 'Queen'."},
                "item_type": {"type": "string", "enum": ["track", "playlist", "album", "artist"], "description": "Was gesucht werden soll, Standard 'track' (einzelner Song). 'playlist' wenn der Nutzer von einer Playlist spricht — dazu zaehlen auch Spotifys eigene automatisch generierte Mixe wie 'Daylist', 'Discover Weekly' oder 'Release Radar' (IMMER item_type='playlist' bei diesen Namen, nie 'track', auch wenn der Name selbst nicht wie eine klassische Playlist klingt). 'artist' fuer 'spiel Musik von X', 'album' fuer ein bestimmtes Album."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "transfer_spotify_playback",
        "description": "Wechselt die laufende Spotify-Wiedergabe auf ein anderes Geraet (z.B. Handy auf PC, oder auf einen Alexa-/Lautsprecher), ohne die Musik zu unterbrechen — braucht eine verbundene Spotify-Anbindung. Nutzen, wenn der Nutzer sagt 'spiel das auf X weiter/ab' oder 'wechsle auf X'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Zielgeraet per Freitext — entweder der genaue Spotify-Geraetename (z.B. 'Wohnzimmer', 'Jans iPhone') oder eine allgemeine Art wie 'Handy', 'PC', 'Alexa', 'Lautsprecher'."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "control_media",
        "description": "Medienwiedergabe der aktuell aktiven Medien-App steuern (Play/Pause, naechster/vorheriger Titel) — z.B. Spotify, wenn es gerade laeuft. Nutzt die normalen Windows-Medientasten, wirkt also auf die gerade aktive Medien-App, nicht speziell auf eine bestimmte.",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string", "enum": ["play_pause", "next", "previous"]}},
            "required": ["action"],
        },
    },
    {
        "name": "open_app",
        "description": "Eine beliebige installierte Windows-Anwendung/Spiel STARTEN (neu oeffnen) — sucht per Name unter den echten Desktop- und Startmenue-Verknuepfungen des Nutzers (z.B. 'World of Warships', 'Steam', 'Blender', 'Discord'), nicht nur eine feste Liste. NICHT nutzen, wenn ein Spiel schon laeuft und der Nutzer eine Aktion/einen Tastendruck DARIN meint (z.B. 'aktiviere X', 'schalte X um' waehrend eines konfigurierten Spiels) — das ist game_action, nicht open_app. Ein unbekannt klingendes Wort nach 'aktiviere'/'schalte' ist oft eine falsch verstandene Spracherkennung eines Spielbefehls, keine echte App — im Zweifel zuerst game_action probieren.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string", "description": "Name der Anwendung, so wie sie auf dem Desktop/Startmenue heisst (muss nicht exakt sein, Teiltreffer reicht)."}},
            "required": ["app"],
        },
    },
    {
        "name": "close_app",
        "description": "Eine laufende Anwendung erzwungen beenden — sucht per Name unter den aktuell laufenden Prozessen (Teiltreffer reicht), nicht nur eine feste Liste.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"}},
            "required": ["app"],
        },
    },
    {
        "name": "take_screenshot",
        "description": "Screenshot des gesamten Bildschirms aufnehmen und lokal speichern.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "manage_window",
        "description": "Das aktuell aktive Fenster minimieren oder den Desktop anzeigen (alle Fenster minimieren).",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string", "enum": ["minimize_active", "show_desktop"]}},
            "required": ["action"],
        },
    },
    {
        "name": "window_action",
        "description": "Mit einem bestimmten offenen Fenster interagieren (per Fenstertitel gesucht, Teiltreffer reicht) — fokussieren/in den Vordergrund holen, minimieren, maximieren oder schliessen. Anders als close_app schliesst das nur EIN Fenster normal, statt den ganzen Prozess zu beenden.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Teil des Fenstertitels, z.B. 'Notepad' oder 'Discord'."},
                "action": {"type": "string", "enum": ["focus", "minimize", "maximize", "close"]},
            },
            "required": ["title", "action"],
        },
    },
    {
        "name": "game_action",
        "description": "Fuehrt eine konfigurierte spielspezifische Aktion per Tastendruck aus (z.B. Fahrwerk ausfahren, Waffe wechseln) — sendet die dafuer in Einstellungen > Spiele hinterlegte Taste an das gerade fokussierte Fenster. Das Tool macht den unscharfen Abgleich SELBST (Teilstring, Wort-fuer-Wort, bekannte Verhoerer der Spracherkennung) und liefert bei keinem Treffer eine Fehlermeldung mit der Liste der tatsaechlich vorhandenen Aktionen zurueck. DESHALB: bei jedem 'aktiviere X'/'schalte X um'/'mach X an/aus' waehrend eines konfigurierten Spiels dieses Tool DIREKT mit dem vom Nutzer genannten Wort aufrufen, OHNE vorher nachzufragen, was genau gemeint ist — auch wenn X mehrdeutig klingt (z.B. 'Triebwerk' koennte mehrere Aktionen treffen: das Tool waehlt selbst die beste Uebereinstimmung). Erst NACHDEM das Tool eine 'nicht konfiguriert'-Fehlermeldung zurueckgegeben hat, beim Nutzer nachfragen oder alternativ open_app in Betracht ziehen — niemals vorher raten oder nachfragen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "game": {"type": "string", "description": "Name des Spiels, z.B. 'Star Citizen'. Weglassen, wenn nur ein Spiel konfiguriert ist oder aus dem Kontext eindeutig hervorgeht."},
                "action": {"type": "string", "description": "Die gewuenschte Aktion in natuerlicher Sprache, z.B. 'Fahrwerk ausfahren'."},
            },
            "required": ["action"],
        },
    },
    {
        "name": "plan_route",
        "description": "Oeffnet die Sternenkarte/Navigationskarte des Spiels, tippt ein Ziel ein und bestaetigt die Route per Klick auf das oberste Suchergebnis — fuer 'plane eine Route nach X' / 'flieg nach X'. Braucht eine Aktion mit 'Sternenkarte' im Namen und eine kalibrierte Mausklick-Aktion 'Suchergebnis' in Einstellungen > Spiele.",
        "input_schema": {
            "type": "object",
            "properties": {
                "game": {"type": "string", "description": "Name des Spiels, z.B. 'Star Citizen'. Weglassen, wenn nur ein Spiel konfiguriert ist."},
                "destination": {"type": "string", "description": "Zielort, z.B. 'Area18' oder 'Port Olisar'."},
            },
            "required": ["destination"],
        },
    },
    {
        "name": "play_youtube",
        "description": "Ein beliebiges Video oder einen Song per Suchbegriff auf YouTube (oder YouTube Music) im Standardbrowser suchen und direkt abspielen, z.B. 'Queen Bohemian Rhapsody'. music=true fuer YouTube Music. Pause/Weiter/Naechster Titel danach ueber control_media.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Was gesucht/abgespielt werden soll."},
                "music": {"type": "boolean", "description": "true = auf YouTube Music abspielen (Standard: normales YouTube)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "play_youtube_latest",
        "description": "Das neueste (zuletzt hochgeladene) YouTube-Video eines bestimmten Kanals im Standardbrowser oeffnen und abspielen.",
        "input_schema": {
            "type": "object",
            "properties": {"channel": {"type": "string", "description": "Name/Suchbegriff des YouTube-Kanals, z.B. 'Knebel'."}},
            "required": ["channel"],
        },
    },
    {
        "name": "maps_route",
        "description": "Plant eine echte Route (Auto/zu Fuss/Fahrrad/OePNV) nach einem Ziel und oeffnet sie in Google Maps (auf dem Handy direkt in der Maps-App). NICHT fuer Routen in Spielen (dafuer plan_route).",
        "input_schema": {
            "type": "object",
            "properties": {
                "destination": {"type": "string", "description": "Ziel, z.B. 'Hamburger Hauptbahnhof' oder eine Adresse."},
                "origin": {"type": "string", "description": "Optionaler Start; weglassen = aktueller Standort."},
                "mode": {"type": "string", "enum": ["driving", "walking", "bicycling", "transit"]},
            },
            "required": ["destination"],
        },
    },
    {
        "name": "find_restaurant",
        "description": "Sucht ein Restaurant und bereitet die Tischreservierung vor (Karte + Reservierungsseite mit Personenzahl und Uhrzeit vorausgefuellt). Bucht NICHT selbst verbindlich - der Nutzer bestaetigt auf der Seite.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Restaurantname und/oder Ort/Kueche, z.B. 'Italiener Hamburg Altona'."},
                "people": {"type": "integer", "description": "Anzahl Personen."},
                "when": {"type": "string", "description": "Datum und Uhrzeit als 'YYYY-MM-DD HH:MM' (24 h), falls genannt."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "open_url",
        "description": "Eine Webseite im Standardbrowser oeffnen (nur http/https).",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "search_web",
        "description": "Suchergebnisse fuer einen beliebigen Suchbegriff im Standardbrowser oeffnen (wenn der Nutzer die Ergebnisse selbst ansehen will, statt eine direkte Antwort zu bekommen).",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "list_calendar_events",
        "description": "Bevorstehende Termine aus dem Google-Kalender des Nutzers abrufen (Titel, Start, Ort, id). Die id wird gebraucht, um einen Termin mit delete_calendar_event zu loeschen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "days": {"type": "integer", "minimum": 1, "maximum": 60, "description": "Zeitraum ab jetzt in Tagen, Standard 14."},
            },
        },
    },
    {
        "name": "create_calendar_event",
        "description": "Einen neuen Termin im Google-Kalender des Nutzers anlegen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Titel des Termins."},
                "start": {"type": "string", "description": "Start als ISO-Datum/-Zeit, z.B. '2026-09-10T18:00:00'."},
                "end": {"type": "string", "description": "Ende als ISO-Datum/-Zeit, optional — Standard: 1 Stunde nach Start."},
                "location": {"type": "string", "description": "Ort, optional."},
            },
            "required": ["title", "start"],
        },
    },
    {
        "name": "update_calendar_event",
        "description": "Einen bestehenden Termin bearbeiten (Titel/Zeit/Ort aendern). Vorher mit list_calendar_events die passende id ermitteln. Nur die angegebenen Felder werden geaendert.",
        "input_schema": {
            "type": "object",
            "properties": {
                "event_id": {"type": "string", "description": "Die id des Termins, aus list_calendar_events."},
                "title": {"type": "string", "description": "Neuer Titel, optional."},
                "start": {"type": "string", "description": "Neuer Start als ISO-Datum/-Zeit, optional."},
                "end": {"type": "string", "description": "Neues Ende als ISO-Datum/-Zeit, optional."},
                "location": {"type": "string", "description": "Neuer Ort, optional."},
            },
            "required": ["event_id"],
        },
    },
    {
        "name": "delete_calendar_event",
        "description": "Einen Termin im Google-Kalender des Nutzers loeschen. Vorher mit list_calendar_events die passende id ermitteln.",
        "input_schema": {
            "type": "object",
            "properties": {
                "event_id": {"type": "string", "description": "Die id des Termins, aus list_calendar_events."},
            },
            "required": ["event_id"],
        },
    },
    {
        "name": "read_emails",
        "description": "Ungelesene E-Mails im Posteingang abrufen (Gmail und/oder Yahoo Mail, je nachdem was verbunden ist) — Absender, Betreff, kurze Vorschau, id. Filtert standardmaessig Newsletter/Werbung/automatische Mails raus.",
        "input_schema": {
            "type": "object",
            "properties": {
                "unread_only": {"type": "boolean", "description": "Nur ungelesene E-Mails, Standard true."},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 25},
                "important_only": {"type": "boolean", "description": "Nur wirklich wichtige E-Mails zeigen, Newsletter/Werbung/automatische Mails werden rausgefiltert. Standard true. Nur auf false setzen, wenn der Nutzer ausdruecklich ALLE E-Mails sehen will."},
            },
        },
    },
    {
        "name": "send_email",
        "description": "Eine neue E-Mail verschicken (ueber Gmail oder Yahoo Mail, je nachdem was verbunden ist).",
        "input_schema": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "body": {"type": "string"},
                "provider": {"type": "string", "enum": ["gmail", "yahoo"], "description": "Optional, nur wenn beide Konten verbunden sind und der Nutzer einen bestimmten Anbieter verlangt. Sonst weglassen."},
            },
            "required": ["to", "subject", "body"],
        },
    },
    {
        "name": "reply_email",
        "description": "Auf eine bestehende E-Mail antworten (email_id aus read_emails).",
        "input_schema": {
            "type": "object",
            "properties": {
                "email_id": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["email_id", "body"],
        },
    },
]
TOOLS += BRAIN_TOOLS

# Anthropic-eigenes Server-Tool: laeuft komplett auf Anthropics Infrastruktur
# (nicht wie die obigen Tools lokal in run_tool()) — Claude sucht selbststaendig
# und kann Fragen direkt mit echten Suchergebnissen beantworten, statt nur
# einen Browser-Tab zu oeffnen. Nur fuer den Anthropic-Pfad, da OpenAI/Groq
# dieses Tool-Format nicht unterstuetzen.
ANTHROPIC_SERVER_TOOLS = [{"type": "web_search_20260209", "name": "web_search", "max_uses": 3}]

# OpenAI/Groq-Pendant zu ANTHROPIC_SERVER_TOOLS: kein eingebautes Server-Tool
# verfuegbar, daher ein eigenes Client-Tool (_tool_web_search_answer, siehe
# oben), das echte Ergebnis-Schnipsel liefert, damit auch ChatGPT/Groq direkt
# antworten koennen statt nur einen Tab zu oeffnen. Nicht in TOOLS, weil
# Anthropic das bessere native web_search bekommt und nicht zusaetzlich
# zwischen zwei aehnlichen Such-Tools waehlen soll.
WEB_SEARCH_ANSWER_TOOL = {
    "name": "web_search_answer",
    "description": "Im Web suchen und Ergebnis-Schnipsel (Titel, Kurzbeschreibung, Link) zurueckbekommen, um eine Frage direkt zu beantworten — bevorzugt gegenueber search_web, wenn der Nutzer eine inhaltliche Antwort erwartet statt nur einen geoeffneten Tab.",
    "input_schema": {
        "type": "object",
        "properties": {"query": {"type": "string"}},
        "required": ["query"],
    },
}


def run_tool(name, tool_input):
    try:
        if name == "control_volume":
            return _tool_control_volume(tool_input.get("action"), tool_input.get("steps", 2), tool_input.get("percent"))
        if name == "set_spotify_volume":
            error = _tool_set_spotify_volume(tool_input.get("percent", 50))
            return f"Spotify-Lautstaerke konnte nicht gesetzt werden: {error}" if error else "Spotify-Lautstaerke gesetzt."
        if name == "play_spotify":
            found_name, error = _tool_play_spotify(tool_input.get("query", ""), tool_input.get("item_type", "track"))
            return f"Spotify-Wiedergabe fehlgeschlagen: {error}" if error else f"Spielt jetzt: '{found_name}'."
        if name == "transfer_spotify_playback":
            device_name, error = _tool_transfer_spotify_playback(tool_input.get("device", ""))
            return f"Geraetewechsel fehlgeschlagen: {error}" if error else f"Wiedergabe laeuft jetzt auf '{device_name}'."
        if name == "control_media":
            return _tool_control_media(tool_input.get("action"))
        if name == "get_current_spotify_track":
            track, error = _tool_spotify_current_track()
            if error:
                return f"Spotify-Abfrage fehlgeschlagen: {error}"
            if not track:
                return "Gerade laeuft nichts auf Spotify."
            state = "laeuft" if track["is_playing"] else "ist pausiert"
            artists = f" von {track['artists']}" if track["artists"] else ""
            return f"'{track['name']}'{artists} {state} gerade."
        if name == "open_app":
            return _tool_open_app(tool_input.get("app", ""))
        if name == "close_app":
            return _tool_close_app(tool_input.get("app", ""))
        if name == "take_screenshot":
            return _tool_take_screenshot()
        if name == "manage_window":
            return _tool_manage_window(tool_input.get("action"))
        if name == "window_action":
            return _tool_window_action(tool_input.get("title", ""), tool_input.get("action", ""))
        if name == "remember":
            return _tool_remember(tool_input.get("text", ""), tool_input.get("category"))
        if name == "forget":
            return _tool_forget(tool_input.get("query", ""))
        if name == "game_action":
            return _tool_game_action(tool_input.get("game"), tool_input.get("action", ""))
        if name == "plan_route":
            return _tool_plan_route(tool_input.get("game"), tool_input.get("destination", ""))
        if name == "play_youtube":
            return _tool_play_youtube(tool_input.get("query", ""), bool(tool_input.get("music")))
        if name == "play_youtube_latest":
            return _tool_play_youtube_latest(tool_input.get("channel", ""))
        if name == "maps_route":
            return _tool_maps_route(tool_input.get("destination", ""), tool_input.get("origin", ""), tool_input.get("mode", "driving"))
        if name == "find_restaurant":
            return _tool_find_restaurant(tool_input.get("query", ""), tool_input.get("people"), tool_input.get("when"))
        if name == "open_url":
            return _tool_open_url(tool_input.get("url", ""))
        if name == "search_web":
            return _tool_search_web(tool_input.get("query", ""))
        if name == "web_search_answer":
            return _tool_web_search_answer(tool_input.get("query", ""))
        if name == "list_calendar_events":
            events, error = get_upcoming_events(days=tool_input.get("days", 14))
            if error:
                return f"Kalender konnte nicht gelesen werden: {error}"
            if not events:
                return "Keine anstehenden Termine gefunden."
            return "\n".join(
                f"{e['title']} — {e['start']}" + (f" ({e['location']})" if e.get("location") else "") + f" [id: {e['id']}]"
                for e in events
            )
        if name == "create_calendar_event":
            created, error = create_calendar_event(
                tool_input.get("title", ""),
                tool_input.get("start", ""),
                tool_input.get("end"),
                tool_input.get("location", ""),
            )
            if error:
                return f"Termin konnte nicht angelegt werden: {error}"
            return f"Termin '{created.get('summary')}' angelegt fuer {created.get('start', {}).get('dateTime')}."
        if name == "update_calendar_event":
            updated, error = update_calendar_event(
                tool_input.get("event_id", ""),
                tool_input.get("title"),
                tool_input.get("start"),
                tool_input.get("end"),
                tool_input.get("location"),
            )
            if error:
                return f"Termin konnte nicht bearbeitet werden: {error}"
            return f"Termin '{updated.get('summary')}' aktualisiert."
        if name == "delete_calendar_event":
            error = delete_calendar_event(tool_input.get("event_id", ""))
            if error:
                return f"Termin konnte nicht geloescht werden: {error}"
            return "Termin geloescht."
        if name == "read_emails":
            emails, error = get_recent_emails(tool_input.get("unread_only", True), tool_input.get("max_results", 10))
            if error:
                return f"E-Mails konnten nicht abgerufen werden: {error}"
            if not emails:
                return "Keine ungelesenen E-Mails."
            important_only = tool_input.get("important_only", True)
            if important_only:
                important = _judge_important_emails(emails)
                important_ids = {i["id"] for i in important}
                reasons = {i["id"]: i["reason"] for i in important}
                emails = [e for e in emails if e["id"] in important_ids]
                if not emails:
                    return "Keine wichtigen E-Mails — nur Newsletter/Werbung/automatische Mails im Posteingang."
                return "\n".join(
                    f"{e['from_name'] or e['from']}: {e['subject']} — {reasons.get(e['id'], '')} (id: {e['id']})"
                    for e in emails
                )
            return "\n".join(
                f"{e['from_name'] or e['from']}: {e['subject']} — {e['preview'][:100]} (id: {e['id']})"
                for e in emails
            )
        if name == "send_email":
            error = send_new_email(tool_input.get("to", ""), tool_input.get("subject", ""), tool_input.get("body", ""), tool_input.get("provider"))
            return f"Fehler beim Senden: {error}" if error else "E-Mail gesendet."
        if name == "reply_email":
            error = reply_to_email(tool_input.get("email_id", ""), tool_input.get("body", ""))
            return f"Fehler beim Antworten: {error}" if error else "Antwort gesendet."
        return f"Unbekanntes Tool: {name}"
    except Exception as e:
        return f"Fehler bei der Ausfuehrung von '{name}': {e}"


# GPU-Auslastung: ein herstellerunabhaengiger Weg wurde ausprobiert (Windows'
# "GPU Engine"-Performancezaehler per WMI/COM, dieselben, die der Task-Manager
# nutzt) — auf diesem Rechner aber reproduzierbar instabil in Kombination mit
# Flask (Antwortzeiten wurden mit jeder Anfrage schlechter, einmal sogar ein
# Absturz, auch mit dediziertem Hintergrundthread). Gemaess Vorgabe ("nur
# integrieren, wenn sauber einbindbar, sonst Demo") daher bewusst nicht
# eingebaut — GPU bleibt Demo/nicht verfuegbar (siehe /status-Antwort unten).


# ---------------------------------------------------------------------------
# Google Calendar: zeigt echte Termine aus dem Google-Konto, mit dem die
# Samsung-Kalender-App synct. Client-ID/Secret + der nach dem Login erhaltene
# Zugangs-Token liegen bewusst zusammen in EINER Datei (secrets.json)
# statt in getrennten credentials.json/token.json — einfacher zu finden und
# mit einem Klick komplett zu entfernen (siehe /calendar/configure DELETE).
# WICHTIG: diese Datei enthaelt persoenliche Zugangsdaten — nicht in ein
# oeffentliches Repo o.ae. committen.
# ---------------------------------------------------------------------------
SECRETS_FILE = os.path.join(DATA_DIR, "secrets.json")
# "calendar.events" statt "calendar.readonly": A.R.I soll auch Termine
# anlegen koennen, nicht nur lesen. Wer schon mit dem alten readonly-Scope
# verbunden war, muss sich einmalig neu einloggen (Google verlangt bei
# erweiterten Berechtigungen eine frische Zustimmung).
CALENDAR_SCOPES = ["https://www.googleapis.com/auth/calendar.events"]

_calendar_service = None
_calendar_init_error = None


def _load_secrets():
    """secrets.json ist nach Dienst verschachtelt: {"calendar": {...},
    "email": {...}} — eine Datei fuer alle Zugangsdaten, damit sich alles auf
    einmal loeschen/exportieren laesst."""
    if not os.path.exists(SECRETS_FILE):
        return {}
    try:
        with open(SECRETS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_secrets(data):
    with open(SECRETS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)


def _load_game_mode_enabled():
    """Spielmodus (automatische Prozesserkennung + Tastendruck-Sicherheits-
    gurt in game_action) ist standardmaessig AUS — muss der Nutzer bewusst
    per Klick anschalten, statt dass ploetzlich Tastendruecke blockiert
    werden, ohne dass er das erwartet hat."""
    return bool((_load_secrets().get("game_mode") or {}).get("enabled", False))


def _save_game_mode_enabled(enabled):
    s = _load_secrets()
    s["game_mode"] = {"enabled": bool(enabled)}
    _save_secrets(s)


def _migrate_legacy_calendar_files():
    """Einmalige Migration: (a) alte getrennte credentials.json/token.json
    (falls vorhanden) in secrets.json zusammenfassen, (b) ein noch flaches
    secrets.json (Kalenderdaten direkt auf oberster Ebene, aus einer
    frueheren Version) unter dem "calendar"-Schluessel verschachteln."""
    legacy_credentials = os.path.join(DASHBOARD_DIR, "credentials.json")
    legacy_token = os.path.join(DASHBOARD_DIR, "token.json")
    if os.path.exists(legacy_credentials) and not os.path.exists(SECRETS_FILE):
        try:
            with open(legacy_credentials, "r", encoding="utf-8") as f:
                client_data = json.load(f).get("installed", {})
            token_data = None
            if os.path.exists(legacy_token):
                with open(legacy_token, "r", encoding="utf-8") as f:
                    token_data = json.load(f)
            _save_secrets({"calendar": {"client": client_data, "token": token_data}})
            os.remove(legacy_credentials)
            if os.path.exists(legacy_token):
                os.remove(legacy_token)
            print("[secrets] credentials.json + token.json zu secrets.json zusammengefuehrt.")
        except (OSError, ValueError) as e:
            print(f"[secrets] Migration der alten Kalender-Dateien fehlgeschlagen: {e}")
        return

    secrets_data = _load_secrets()
    if secrets_data and "client" in secrets_data and "calendar" not in secrets_data:
        _save_secrets({"calendar": {"client": secrets_data.get("client"), "token": secrets_data.get("token")}})
        print("[secrets] secrets.json auf verschachteltes Format (calendar/email) umgestellt.")


_migrate_legacy_calendar_files()


def _init_google_calendar():
    global _calendar_service, _calendar_init_error
    if _calendar_service is not None or _calendar_init_error is not None:
        return
    if _google_api_build is None:
        _calendar_init_error = "Google-Kalender-Pakete nicht installiert (pip install -r requirements.txt)"
        return
    secrets_data = _load_secrets()
    cal_auth = secrets_data.get("calendar")
    if not cal_auth or not cal_auth.get("client"):
        _calendar_init_error = "Kalender noch nicht verbunden (Client-ID/Secret fehlen)"
        return
    try:
        creds = None
        if cal_auth.get("token"):
            try:
                creds = _GoogleCredentials.from_authorized_user_info(cal_auth["token"], CALENDAR_SCOPES)
                if creds and not creds.valid:
                    if creds.expired and creds.refresh_token:
                        creds.refresh(_GoogleAuthRequest())
                    else:
                        creds = None
            except Exception:
                # Gespeicherter Token ist ungueltig/widerrufen — nicht
                # aufgeben, sondern unten frisch einloggen lassen.
                creds = None
        if not creds:
            # Oeffnet einmalig ein Browserfenster fuer den Google-Login
            # (blockierend) — passiert nur beim allerersten Aufruf bzw.
            # wenn das gespeicherte Token abgelaufen/entzogen ist.
            flow = _GoogleInstalledAppFlow.from_client_config({"installed": cal_auth["client"]}, CALENDAR_SCOPES)
            creds = flow.run_local_server(port=0)
            cal_auth["token"] = json.loads(creds.to_json())
            secrets_data["calendar"] = cal_auth
            _save_secrets(secrets_data)
        _calendar_service = _google_api_build("calendar", "v3", credentials=creds)
    except Exception as e:
        _calendar_init_error = str(e)


def _reset_calendar_auth():
    """Wirft den lokalen Kalender-Token weg, wenn Google ihn serverseitig
    widerrufen hat (invalid_grant) — die lokale Ablaufzeit sagt das nicht
    voraus, das faellt erst beim echten API-Aufruf auf. Naechster Aufruf
    von _init_google_calendar() macht dann einen frischen interaktiven Login."""
    global _calendar_service, _calendar_init_error
    _calendar_service = None
    _calendar_init_error = None
    secrets_data = _load_secrets()
    if "calendar" in secrets_data:
        secrets_data["calendar"].pop("token", None)
        _save_secrets(secrets_data)


def get_upcoming_events(days=30, max_results=20, days_back=0):
    """days_back holt zusaetzlich vergangene Termine (fuer die Monatsansicht
    im Kalender-Panel, die auch bereits verstrichene Termine als Punkt/Linie
    zeigen soll) — 0 heisst wie bisher nur ab jetzt vorwaerts (z.B. fuer das
    list_calendar_events-Tool der KI, das nur "anstehend" meint)."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        start_bound = datetime.datetime.utcnow() - datetime.timedelta(days=days_back)
        time_min = start_bound.isoformat() + "Z"
        end = (datetime.datetime.utcnow() + datetime.timedelta(days=days)).isoformat() + "Z"
        result = _calendar_service.events().list(
            calendarId="primary", timeMin=time_min, timeMax=end,
            maxResults=max_results, singleEvents=True, orderBy="startTime",
        ).execute()
        events = []
        for item in result.get("items", []):
            start_info = item.get("start", {})
            end_info = item.get("end", {})
            events.append({
                "id": item.get("id"),
                "title": item.get("summary", "(Ohne Titel)"),
                "start": start_info.get("dateTime", start_info.get("date")),
                "end": end_info.get("dateTime", end_info.get("date")),
                "all_day": "date" in start_info,
                "location": item.get("location", ""),
            })
        return events, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


DEFAULT_TIMEZONE = "Europe/Berlin"


def create_calendar_event(title, start_iso, end_iso=None, location=""):
    """Legt einen neuen Termin im primaeren Google-Kalender an. end_iso ist
    optional — ohne Angabe wird eine Stunde nach start_iso angenommen.
    Zeiten ohne Zeitzonen-Angabe werden als DEFAULT_TIMEZONE interpretiert,
    statt sich auf eine implizite Server-/Kalender-Standardzeitzone zu
    verlassen."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        start_dt = datetime.datetime.fromisoformat(start_iso)
    except ValueError:
        return None, f"Ungueltiges Startdatum: '{start_iso}' (erwartet z.B. 2026-09-10T18:00:00)"
    if end_iso:
        try:
            end_dt = datetime.datetime.fromisoformat(end_iso)
        except ValueError:
            return None, f"Ungueltiges Enddatum: '{end_iso}'"
    else:
        end_dt = start_dt + datetime.timedelta(hours=1)
    body = {
        "summary": title,
        "start": {"dateTime": start_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE},
        "end": {"dateTime": end_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE},
    }
    if location:
        body["location"] = location
    try:
        created = _calendar_service.events().insert(calendarId="primary", body=body).execute()
        return created, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


def delete_calendar_event(event_id):
    """Loescht einen Termin anhand seiner Event-ID (die list_calendar_events
    mit zurueckgibt). Muss also erst per list_calendar_events gesucht werden,
    wenn die ID nicht schon bekannt ist."""
    _init_google_calendar()
    if _calendar_service is None:
        return _calendar_init_error or "Kalender nicht verbunden"
    try:
        _calendar_service.events().delete(calendarId="primary", eventId=event_id).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return str(e)


def update_calendar_event(event_id, title=None, start_iso=None, end_iso=None, location=None):
    """Bearbeitet einen bestehenden Termin (per event_id von list_calendar_events).
    Nur die angegebenen Felder werden geaendert, der Rest bleibt wie er war."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        body = {}
        if title is not None:
            body["summary"] = title
        if start_iso is not None:
            try:
                start_dt = datetime.datetime.fromisoformat(start_iso)
            except ValueError:
                return None, f"Ungueltiges Startdatum: '{start_iso}'"
            body["start"] = {"dateTime": start_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE}
        if end_iso is not None:
            try:
                end_dt = datetime.datetime.fromisoformat(end_iso)
            except ValueError:
                return None, f"Ungueltiges Enddatum: '{end_iso}'"
            body["end"] = {"dateTime": end_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE}
        if location is not None:
            body["location"] = location
        if not body:
            return None, "Keine Aenderungen angegeben."
        updated = _calendar_service.events().patch(calendarId="primary", eventId=event_id, body=body).execute()
        return updated, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


# ---------------------------------------------------------------------------
# Spotify: steuert Spotifys EIGENE Lautstaerke ueber Spotifys Web-API (anders
# als control_volume, das nur die Windows-Systemlautstaerke kann). Braucht
# eine eigene Spotify-Entwickler-App (Client-ID/Secret) und einen einmaligen
# Browser-Login (Authorization-Code-Flow) — der Redirect geht zurueck an
# diesen Hub selbst (/spotify/callback), kein zusaetzlicher lokaler Server
# noetig. Access-Token wird per Refresh-Token automatisch erneuert.
# ---------------------------------------------------------------------------
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/authorize"
SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_SCOPES = "user-modify-playback-state user-read-playback-state playlist-read-private user-read-recently-played"
SPOTIFY_REDIRECT_URI = "http://127.0.0.1:5000/spotify/callback"


def _spotify_auth_url(client_id):
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": SPOTIFY_REDIRECT_URI,
        "scope": SPOTIFY_SCOPES,
    }
    return SPOTIFY_AUTH_URL + "?" + urllib.parse.urlencode(params)


def _spotify_token_request(client_id, client_secret, form_data):
    data = urllib.parse.urlencode(form_data).encode()
    auth = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    req = urllib.request.Request(SPOTIFY_TOKEN_URL, data=data, headers={
        "Authorization": "Basic " + auth,
        "Content-Type": "application/x-www-form-urlencoded",
    })
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _spotify_access_token():
    """Liefert einen gueltigen Access-Token, erneuert ihn bei Bedarf per
    Refresh-Token — Spotify-Access-Tokens laufen nach 1h ab."""
    secrets_data = _load_secrets()
    sp = secrets_data.get("spotify") or {}
    token = sp.get("token")
    if not sp.get("client_id") or not token:
        return None, "Spotify nicht verbunden (in den Einstellungen einrichten)."
    if time.time() >= token.get("expires_at", 0):
        try:
            fresh = _spotify_token_request(sp["client_id"], sp["client_secret"], {
                "grant_type": "refresh_token",
                "refresh_token": token["refresh_token"],
            })
        except Exception as e:
            return None, f"Spotify-Token konnte nicht erneuert werden: {e}"
        token["access_token"] = fresh["access_token"]
        token["expires_at"] = time.time() + fresh.get("expires_in", 3600) - 30
        if "refresh_token" in fresh:
            token["refresh_token"] = fresh["refresh_token"]
        sp["token"] = token
        secrets_data["spotify"] = sp
        _save_secrets(secrets_data)
    return token["access_token"], None


def _spotify_list_devices(access_token):
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player/devices",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read()).get("devices", [])


def _spotify_activate_device(access_token, device_id):
    """Ueberspringt das "es muss schon aktiv abspielen"-Problem: transferiert
    die Wiedergabe stumm (play=false) auf ein bereits gefundenes, aber noch
    nicht aktives Geraet — Spotify muss dafuer nur offen sein, nicht schon
    etwas abspielen."""
    body = json.dumps({"device_ids": [device_id], "play": False}).encode()
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player",
        data=body, method="PUT",
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
    )
    urllib.request.urlopen(req, timeout=15)


def _spotify_set_volume_raw(access_token, pct):
    req = urllib.request.Request(
        f"https://api.spotify.com/v1/me/player/volume?volume_percent={pct}",
        method="PUT",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    urllib.request.urlopen(req, timeout=15)


def _spotify_get_volume(access_token):
    """Aktuelle Spotify-Lautstaerke in Prozent (None, wenn kein aktives Geraet)."""
    try:
        req = urllib.request.Request("https://api.spotify.com/v1/me/player", headers={"Authorization": f"Bearer {access_token}"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8", "ignore")
        if not raw.strip():
            return None
        vol = (json.loads(raw).get("device") or {}).get("volume_percent")
        return int(vol) if vol is not None else None
    except Exception:
        return None


def _tool_spotify_current_track():
    """Fragt den gerade laufenden Titel bei Spotify ab (Name + Interpret*in),
    damit A.R.I auf 'was laeuft gerade' / 'welches Lied kommt' antworten
    kann, statt zu raten. Gibt None (kein Fehler) zurueck, wenn gerade
    nichts abgespielt wird — das ist ein normaler Zustand, kein Fehler."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player/currently-playing",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status == 204:  # nichts wird abgespielt
                return None, None
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 204:
            return None, None
        return None, f"Spotify-Abfrage fehlgeschlagen: {e}"
    except Exception as e:
        return None, f"Spotify-Abfrage fehlgeschlagen: {e}"
    item = data.get("item")
    if not item:
        return None, None
    name = item.get("name", "")
    artists = ", ".join(a.get("name", "") for a in item.get("artists", []) if a.get("name"))
    is_playing = data.get("is_playing", False)
    imgs = (item.get("album") or {}).get("images") or []
    image = (imgs[1] if len(imgs) > 1 else imgs[0])["url"] if imgs else None  # mittlere Groesse (~300 px)
    first_artist = next((a for a in item.get("artists", []) if a.get("id")), {})
    return {"name": name, "artists": artists, "is_playing": is_playing, "image": image, "artist_id": first_artist.get("id"),
            "progress_ms": data.get("progress_ms") or 0, "duration_ms": item.get("duration_ms") or 0}, None


def _spotify_seek(ms):
    access_token, error = _spotify_access_token()
    if error:
        return error
    try:
        req = urllib.request.Request(f"https://api.spotify.com/v1/me/player/seek?position_ms={max(0, int(ms))}",
                                     method="PUT", headers={"Authorization": f"Bearer {access_token}"})
        urllib.request.urlopen(req, timeout=15)
        return None
    except Exception as e:
        return f"Spotify-Fehler: {e}"


_spotify_mute_prev = {"vol": None}


def _spotify_cmd(method, path):
    """Steuert Spotify direkt ueber die Web-API (Wiedergabe, Weiter, Zurueck). Gibt Fehlertext oder None."""
    token, err = _spotify_access_token()
    if err:
        return err

    def go():
        req = urllib.request.Request("https://api.spotify.com/v1/me/player/" + path, method=method,
                                     data=b"" if method in ("POST", "PUT") else None,
                                     headers={"Authorization": f"Bearer {token}", "Content-Length": "0"})
        urllib.request.urlopen(req, timeout=15)

    try:
        go()
        return None
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)
    dev, err = _spotify_ensure_active_device(token)  # kein aktives Geraet: Spotify-Geraet aktivieren, dann nochmal
    if err:
        return err
    try:
        go()
        return None
    except Exception as e:
        return f"Spotify-Fehler: {e}"


def _media_control(action, ms=None):
    """Medienplayer (HUD + Handy): steuert SPOTIFY direkt ueber die Spotify-API. Ist Spotify nicht
    verbunden, wird ersatzweise wie bisher die Windows-Medientaste gedrueckt."""
    token, terr = _spotify_access_token()
    if terr:  # Spotify nicht verbunden -> Windows-Tasten
        if action in ("play_pause", "next", "previous"):
            return _tool_control_media(action)
        if action in ("up", "down", "mute"):
            return _tool_control_volume(action, 3)
        return terr
    if action == "play_pause":
        track, _e = _tool_spotify_current_track()
        err = _spotify_cmd("PUT", "pause" if (track and track.get("is_playing")) else "play")
        return err or "OK"
    if action == "next":
        return _spotify_cmd("POST", "next") or "OK"
    if action == "previous":
        return _spotify_cmd("POST", "previous") or "OK"
    if action in ("up", "down"):
        cur = _spotify_get_volume(token)
        if cur is None:
            _spotify_cmd("PUT", "play")  # Geraet wecken, dann nochmal versuchen
            cur = _spotify_get_volume(token)
        if cur is None:
            return "Kein aktives Spotify-Geraet."
        return _tool_set_spotify_volume(max(0, min(100, cur + (10 if action == "up" else -10)))) or f"Lautstärke {'+' if action == 'up' else '-'}10"
    if action == "mute":
        cur = _spotify_get_volume(token)
        if cur is None:
            return "Kein aktives Spotify-Geraet."
        if cur > 0:
            _spotify_mute_prev["vol"] = cur
            return _tool_set_spotify_volume(0) or "Stumm"
        return _tool_set_spotify_volume(_spotify_mute_prev["vol"] or 30) or "Ton an"
    if action == "seek":
        return _spotify_seek(ms or 0) or "OK"
    return "Unbekannte Aktion."


# --- Musikgeschmack ins Gehirn -------------------------------------------------
# A.R.I merkt sich, was du auf Spotify hoerst: wie oft welcher Titel/Interpret, Genres und
# Tageszeit. Daraus entstehen laufend aktualisierte Erinnerungen in der Kategorie "Musik"
# (Lieblingsinterpreten, Lieblingslieder, Genres, wann du hoerst) - ohne Duplikate.
MUSIC_STATS_FILE = os.path.join(DATA_DIR, "music_stats.json")
_MUSIC_PREFIXES = ("Hört am liebsten", "Lieblingslieder", "Musikgeschmack", "Hört Musik meist")
_music = {"stats": None, "cur": None, "last_t": 0.0, "last_brain": 0.0}
_music_lock = threading.Lock()


def _music_stats():
    if _music["stats"] is None:
        try:
            with open(MUSIC_STATS_FILE, "r", encoding="utf-8") as f:
                _music["stats"] = json.load(f)
        except (OSError, ValueError):
            _music["stats"] = {}
        for k, d in (("tracks", {}), ("artists", {}), ("hours", [0] * 24)):
            _music["stats"].setdefault(k, d)
    return _music["stats"]


def _music_save():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = MUSIC_STATS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_music_stats(), f, ensure_ascii=False)
        os.replace(tmp, MUSIC_STATS_FILE)
    except OSError:
        pass


def _music_artist_genres(artist_id):
    token, err = _spotify_access_token()
    if err or not artist_id:
        return []
    try:
        req = urllib.request.Request(f"https://api.spotify.com/v1/artists/{artist_id}", headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return [str(g) for g in (json.loads(r.read()).get("genres") or [])][:4]
    except Exception:
        return []


def _music_finish(st, cur):
    """Ein Titel ist zu Ende / wurde gewechselt: als gehoert zaehlen oder als uebersprungen."""
    listened, dur = cur["secs"], cur.get("dur") or 0
    need = min(30.0, dur * 0.5) if dur else 30.0
    tr = st["tracks"].setdefault(cur["key"], {"name": cur["name"], "artists": cur["artists"], "plays": 0, "skips": 0, "secs": 0})
    if listened >= need:
        tr["plays"] += 1
        tr["secs"] += int(listened)
        for a in [x.strip() for x in cur["artists"].split(",") if x.strip()][:2]:
            ar = st["artists"].setdefault(a, {"plays": 0, "secs": 0, "genres": None})
            ar["plays"] += 1
            ar["secs"] += int(listened)
        first = cur["artists"].split(",")[0].strip()
        if first and st["artists"].get(first, {}).get("genres") is None:
            st["artists"][first]["genres"] = _music_artist_genres(cur.get("artist_id"))
        st["hours"][cur["hour"] % 24] += 1
        return True
    if listened < 20:
        tr["skips"] += 1
    return False


def _music_daypart(hours):
    parts = {"morgens": range(5, 11), "mittags": range(11, 15), "nachmittags": range(15, 18), "abends": range(18, 23)}
    score = {p: sum(hours[h] for h in r) for p, r in parts.items()}
    score["nachts"] = sum(hours[h] for h in list(range(23, 24)) + list(range(0, 5)))
    best = max(score, key=score.get)
    return best if score[best] > 0 else None


def _music_brain(st):
    total = sum(t["plays"] for t in st["tracks"].values())
    if total < 3:
        return
    arts = sorted(st["artists"].items(), key=lambda kv: (kv[1]["plays"], kv[1]["secs"]), reverse=True)[:5]
    if arts:
        _brain_upsert("music:artists", "Hört am liebsten: " + ", ".join(f"{a} ({d['plays']}x)" for a, d in arts) + ".", "Musik")
    favs = [t for t in sorted(st["tracks"].values(), key=lambda t: t["plays"], reverse=True)[:5] if t["plays"] >= 2]
    if favs:
        _brain_upsert("music:tracks", "Lieblingslieder (oft gehört): " + "; ".join(f"{t['name']} von {t['artists']} ({t['plays']}x)" for t in favs) + ".", "Musik")
    gc = {}
    for a, d in arts:
        for g in (d.get("genres") or []):
            gc[g] = gc.get(g, 0) + d["plays"]
    if gc:
        _brain_upsert("music:genres", "Musikgeschmack (Genres): " + ", ".join(g for g, _ in sorted(gc.items(), key=lambda kv: kv[1], reverse=True)[:4]) + ".", "Musik")
    dp = _music_daypart(st["hours"])
    if dp:
        _brain_upsert("music:daypart", f"Hört Musik meist {dp}.", "Musik")


def _music_feed(track):
    """Mit dem gerade laufenden Titel fuettern (Hintergrund-Watcher, /media, Handy). Mehrfaches Fuettern
    ist unkritisch: gezaehlt wird die echte Hoerzeit zwischen den Aufrufen."""
    now = time.time()
    with _music_lock:
        st = _music_stats()
        cur, last = _music["cur"], _music["last_t"]
        _music["last_t"] = now
        key = (track["name"] + " – " + track["artists"]).strip() if track else None
        prog = (track.get("progress_ms") or 0) if track else 0
        restart = bool(cur and track and cur["key"] == key and prog + 5000 < cur.get("prog", 0))   # Lied von vorn = neue Wiedergabe
        if cur and last and cur.get("playing") and cur["key"] == key and not restart:
            cur["secs"] += min(now - last, 40)
        if cur and (cur["key"] != key or restart):
            counted = _music_finish(st, cur)
            _music["cur"] = cur = None
            _music_save()
            if counted and now - _music["last_brain"] > 60:
                _music["last_brain"] = now
                try:
                    _music_brain(st)
                except Exception:
                    pass
        if track and cur is None:
            cur = {"key": key, "name": track["name"], "artists": track["artists"], "secs": 0.0,
                   "dur": (track.get("duration_ms") or 0) / 1000.0, "artist_id": track.get("artist_id"), "hour": datetime.datetime.now().hour}
        if cur:
            cur["playing"] = bool(track and track.get("is_playing"))
            cur["prog"] = prog
        _music["cur"] = cur


def _music_watch():
    """Fragt alle 20 s Spotify ab (nur wenn verbunden), damit auch ohne offenes HUD mitgezaehlt wird."""
    while True:
        time.sleep(20)
        try:
            _tok, err = _spotify_access_token()
            if err:
                time.sleep(100)
                continue
            track, e = _tool_spotify_current_track()
            if not e:
                _music_feed(track)
        except Exception:
            pass


@app.route("/media")
def media_info():
    track, err = _tool_spotify_current_track()
    if not err:
        _music_feed(track)
    return jsonify({"track": track, "error": err})


@app.route("/media/control", methods=["POST"])
def media_control():
    d = request.get_json(silent=True) or {}
    return jsonify({"message": _media_control(str(d.get("action") or ""), d.get("ms"))})


def _spotify_ensure_active_device(access_token):
    """Sucht ein bereits vorhandenes Geraet (Spotify offen, egal ob es schon
    abspielt), startet notfalls die Desktop-App selbst und aktiviert das
    gefundene Geraet stumm (play=false). Gibt (device_id, error) zurueck."""
    try:
        devices = _spotify_list_devices(access_token)
    except Exception as e:
        return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
    if not devices:
        _tool_open_app("Spotify")
        time.sleep(6)
        try:
            devices = _spotify_list_devices(access_token)
        except Exception as e:
            return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
        if not devices:
            return None, "Spotify wurde gestartet, meldet sich aber noch nicht als Geraet — bitte kurz warten und nochmal versuchen."
    dev = next((d for d in devices if d.get("is_active")), None) or next((d for d in devices if (d.get("type") or "").lower() == "computer"), None) or devices[0]
    device_id = dev["id"]
    if dev.get("is_active"):
        return device_id, None   # laeuft schon auf diesem Geraet: nicht erst umschalten
    try:
        _spotify_activate_device(access_token, device_id)
        time.sleep(1)
    except Exception as e:
        return None, f"Geraet konnte nicht aktiviert werden: {e}"
    return device_id, None


def _spotify_find_device(devices, query):
    """Findet ein Geraet per Freitext — Name (z.B. 'Wohnzimmer', 'Alexa') ODER
    Geraetetyp-Alias (Handy/PC/Lautsprecher etc.), falls der Nutzer keinen
    genauen Geraetenamen nennt, sondern nur die Art des Geraets."""
    needle = query.strip().lower()
    TYPE_ALIASES = {
        "computer": ["pc", "computer", "rechner", "desktop", "laptop"],
        "smartphone": ["handy", "phone", "smartphone", "telefon", "mobil"],
        "speaker": ["lautsprecher", "speaker", "box", "alexa", "echo"],
        "tv": ["tv", "fernseher"],
    }
    for d in devices:
        if needle in (d.get("name") or "").lower():
            return d
    for spotify_type, aliases in TYPE_ALIASES.items():
        if needle in aliases:
            for d in devices:
                if (d.get("type") or "").lower() == spotify_type or needle in (d.get("name") or "").lower():
                    return d
    return None


def _tool_transfer_spotify_playback(device_query):
    """Wechselt die laufende Wiedergabe auf ein anderes Spotify-Connect-
    Geraet (Handy, PC, Alexa/Lautsprecher, ...) — Musik laeuft danach dort
    weiter, ohne zu stoppen. Gibt (geraetename, error) zurueck."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    try:
        devices = _spotify_list_devices(access_token)
    except Exception as e:
        return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
    if not devices:
        return None, "Keine Spotify-Geraete gefunden — auf dem Zielgeraet muss Spotify offen sein."
    device = _spotify_find_device(devices, device_query)
    if not device:
        available = ", ".join(d.get("name", "?") for d in devices)
        return None, f"Kein Geraet gefunden fuer '{device_query}'. Verfuegbar: {available}."
    body = json.dumps({"device_ids": [device["id"]], "play": True}).encode()
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player",
        data=body, method="PUT",
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
    )
    try:
        urllib.request.urlopen(req, timeout=15)
    except urllib.error.HTTPError as e:
        return None, f"Wiedergabe konnte nicht auf '{device['name']}' umgeschaltet werden: {e.code} {e.reason}"
    except Exception as e:
        return None, str(e)
    return device["name"], None


def _tool_set_spotify_volume(percent):
    access_token, error = _spotify_access_token()
    if error:
        return error
    pct = max(0, min(100, int(percent)))
    try:
        _spotify_set_volume_raw(access_token, pct)
        return None
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)

    device_id, error = _spotify_ensure_active_device(access_token)
    if error:
        return error
    try:
        _spotify_set_volume_raw(access_token, pct)
        return None
    except urllib.error.HTTPError as e:
        return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)


def _spotify_search(access_token, query, item_type):
    params = urllib.parse.urlencode({"q": query, "type": item_type, "limit": 1})
    req = urllib.request.Request(
        f"https://api.spotify.com/v1/search?{params}",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
    items = data.get(item_type + "s", {}).get("items", [])
    return items[0] if items else None


def _spotify_find_own_playlist(access_token, query):
    """Spotifys normale Suche findet nur OEFFENTLICHE Playlists — die eigenen
    (auch private) muessen separat ueber die eigene Playlist-Liste gesucht
    werden. Einfacher Teilstring-Vergleich (case-insensitive) ueber alle
    Seiten der eigenen Playlists."""
    needle = query.strip().lower()
    url = "https://api.spotify.com/v1/me/playlists?limit=50"
    while url:
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {access_token}"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        for pl in data.get("items", []):
            if needle in (pl.get("name") or "").lower():
                return pl
        url = data.get("next")
    return None


def _spotify_find_recent_algorithmic_playlist(access_token, needle):
    """Spotify gibt algorithmische Mixes (Daylist, Discover Weekly, Release
    Radar, ...) NICHT ueber /me/playlists oder die Suche frei — die einzige
    offizielle Web-API-Spur ist der Wiedergabeverlauf: wenn der Nutzer sie
    schon mal in der Spotify-App gestartet hat, taucht ihre Playlist-URI dort
    als Kontext auf. Braucht den Scope 'user-read-recently-played'. Findet
    nichts, wenn der Nutzer sie noch nie in der App abgespielt hat — das ist
    eine echte Grenze der oeffentlichen API, keine Einschraenkung von uns."""
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player/recently-played?limit=50",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
    checked_uris = set()
    for item in data.get("items", []):
        ctx = item.get("context") or {}
        uri = ctx.get("uri", "")
        if ctx.get("type") != "playlist" or uri in checked_uris or ":playlist:" not in uri:
            continue
        checked_uris.add(uri)
        playlist_id = uri.rsplit(":", 1)[-1]
        try:
            preq = urllib.request.Request(
                f"https://api.spotify.com/v1/playlists/{playlist_id}?fields=id,name,uri",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            with urllib.request.urlopen(preq, timeout=15) as presp:
                pdata = json.loads(presp.read())
        except urllib.error.HTTPError:
            continue
        if needle in (pdata.get("name") or "").lower():
            return pdata
    return None


def _tool_play_spotify(query, item_type="track"):
    """Sucht per Freitext (Playlist/Song/Album/Kuenstler) und startet die
    Wiedergabe — aktiviert dabei automatisch ein Geraet, Spotify muss also
    nur offen sein (oder wird notfalls selbst gestartet), nicht schon laufen.
    Gibt (gefundener_name, error) zurueck."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    item_type = item_type if item_type in ("track", "playlist", "album", "artist") else "track"
    is_algorithmic_query = item_type == "playlist" and any(
        kw in query.strip().lower() for kw in ("daylist", "discover weekly", "release radar")
    )
    try:
        item = None
        if is_algorithmic_query:
            # Spotifys algorithmische Mixes (Daylist, Discover Weekly, Release
            # Radar) sind NICHT Teil von /me/playlists oder der Suche — die
            # einzige offizielle Spur ist der Wiedergabeverlauf, falls der
            # Nutzer sie schon mal in der App gestartet hat.
            needle = "daylist" if "daylist" in query.strip().lower() else query.strip().lower()
            item = _spotify_find_recent_algorithmic_playlist(access_token, needle)
        elif item_type == "playlist":
            item = _spotify_find_own_playlist(access_token, query)
        if not item:
            item = None if is_algorithmic_query else _spotify_search(access_token, query, item_type)
    except urllib.error.HTTPError as e:
        if is_algorithmic_query and e.code == 403:
            return None, (
                "Fehlende Berechtigung fuer den Wiedergabeverlauf — bitte Spotify "
                "in den Einstellungen einmal neu verbinden (fuer den neuen Zugriff "
                "auf 'zuletzt gehoert')."
            )
        return None, f"Spotify-Suche fehlgeschlagen: {e}"
    except Exception as e:
        return None, f"Spotify-Suche fehlgeschlagen: {e}"
    if not item and is_algorithmic_query:
        return None, (
            "Daylist wurde nicht im Wiedergabeverlauf gefunden — einmal in der "
            "Spotify-App selbst starten, danach findet A.R.I es automatisch "
            "(Spotifys API gibt es sonst nicht frei)."
        )
    if not item:
        return None, f"Nichts gefunden fuer '{query}' ({item_type})."
    uri = item["uri"]
    name = item.get("name", query)

    device_id, error = _spotify_ensure_active_device(access_token)
    if error:
        return None, error

    body = {"uris": [uri]} if item_type == "track" else {"context_uri": uri}

    def send_play(with_device):
        url = "https://api.spotify.com/v1/me/player/play" + (f"?device_id={device_id}" if with_device else "")
        req = urllib.request.Request(
            url, data=json.dumps(body).encode(), method="PUT",
            headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=15)

    # Spotify antwortet auf "play" oft sofort mit 204, obwohl das Geraet noch nicht bereit ist und
    # dann nichts passiert. Deshalb: senden, kurz warten, PRUEFEN ob wirklich etwas laeuft, sonst nochmal.
    last_err = None
    for attempt in range(3):
        try:
            send_play(with_device=(attempt != 1))
        except urllib.error.HTTPError as e:
            last_err = f"Spotify-Fehler beim Abspielen: {e.code} {e.reason}"
            if e.code in (404, 502, 503):   # Geraet nicht bereit -> neu aktivieren
                dev2, err2 = _spotify_ensure_active_device(access_token)
                if not err2:
                    device_id = dev2
            time.sleep(1.2)
            continue
        except Exception as e:
            last_err = str(e)
            time.sleep(1.2)
            continue
        time.sleep(1.0 + attempt * 0.8)
        try:
            track, _e = _tool_spotify_current_track()
        except Exception:
            track = None
        if track and track.get("is_playing"):
            return name, None
        last_err = "Spotify hat den Befehl angenommen, spielt aber nichts."
    return None, (last_err or "Wiedergabe konnte nicht gestartet werden.") + " Ist die Spotify-App am PC geöffnet und als Gerät sichtbar?"


@app.route("/game-profiles", methods=["GET"])
def game_profiles_get():
    return jsonify(_load_game_profiles())


@app.route("/game-profiles", methods=["POST"])
def game_profiles_save():
    """Speichert das KOMPLETTE Profile-Dict (Ganz-Ersetzen) — das Frontend
    haelt den vollstaendigen Stand ohnehin im Speicher, solange das
    Einstellungen-Modal offen ist. Prueft jede Tastenkombo vorab gegen den
    _resolve_vk-Parser (ohne sie zu druecken), damit ungueltige Eingaben
    nicht erst beim naechsten game_action-Aufruf auffallen."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Ungueltige Daten."}), 400
    invalid = []
    for game_key, profile in data.items():
        if not isinstance(profile, dict) or not (profile.get("display_name") or "").strip():
            return jsonify({"error": f"Spiel '{game_key}' braucht einen Namen."}), 400
        actions = profile.get("actions")
        if not isinstance(actions, dict):
            return jsonify({"error": f"Spiel '{game_key}' hat ein ungueltiges Aktionsformat."}), 400
        for action_key, action in actions.items():
            key_string = (action or {}).get("key", "")
            if not key_string.strip():
                continue  # noch keine Taste hinterlegt (z.B. Maustaste im Original oder noch unbekannt) — kein Fehler, nur nicht ausfuehrbar bis der Nutzer eine Taste eintraegt
            parts = [p.strip() for p in key_string.split("+") if p.strip()]
            if not parts or any(_resolve_scancode(p) is None and _resolve_vk(p) is None for p in parts):
                invalid.append(f"{profile.get('display_name', game_key)} / {action.get('label', action_key)}")
    if invalid:
        return jsonify({"error": "Ungueltige Taste(n) bei: " + ", ".join(invalid)}), 400
    _save_game_profiles(data)
    return jsonify({"error": None})


@app.route("/game-mode", methods=["GET"])
def game_mode_get():
    key, name = get_active_game_mode()
    return jsonify({"enabled": _load_game_mode_enabled(), "active_game": name})


@app.route("/game-mode", methods=["POST"])
def game_mode_set():
    """Ein-Klick-Umschalter fuer den Spielmodus (Prozesserkennung + game_action-
    Sicherheitsgurt) — standardmaessig aus, siehe _load_game_mode_enabled."""
    data = request.get_json(silent=True) or {}
    enabled = bool(data.get("enabled"))
    _save_game_mode_enabled(enabled)
    if not enabled:
        with _active_game_lock:
            global _active_game_key
            _active_game_key = None
    return jsonify({"error": None, "enabled": enabled})


@app.route("/capture-click", methods=["POST"])
def capture_click():
    """Fuer die Klick-Kalibrierung im Spiele-Editor: wartet auf den naechsten
    echten Linksklick irgendwo auf dem Bildschirm und gibt seine Position
    als Bildschirmanteil zurueck — funktioniert unabhaengig von der eigenen
    Monitor-Aufloesung des Nutzers, siehe _capture_next_click()."""
    result = _capture_next_click()
    if result is None:
        return jsonify({"error": "Kein Klick erkannt (15 Sekunden Zeitueberschreitung)."})
    x, y = result
    return jsonify({"error": None, "x": x, "y": y})


@app.route("/pick-exe", methods=["POST"])
def pick_exe():
    """Oeffnet den nativen Windows-Datei-Dialog, damit der Nutzer die .exe
    seines Spiels per Ordner-Browser auswaehlen kann, statt den
    Prozessnamen selbst abtippen zu muessen — gibt nur den Dateinamen
    zurueck (z.B. 'StarCitizen.exe'), nicht den vollen Pfad (der volle Pfad
    ist fuer die Prozesserkennung per Namensabgleich nicht noetig und koennte
    unnoetig den Speicherort preisgeben)."""
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(
            title="Spiel-Programm (.exe) auswaehlen" if IS_WIN else "Spiel-Programm auswaehlen",
            filetypes=[("Programme", "*.exe"), ("Alle Dateien", "*.*")] if IS_WIN else [("Alle Dateien", "*")],
        )
        root.destroy()
    except Exception as e:
        return jsonify({"error": f"Datei-Dialog konnte nicht geoeffnet werden: {e}"})
    if not path:
        return jsonify({"error": "Keine Datei ausgewaehlt."})
    return jsonify({"error": None, "filename": os.path.basename(path)})


@app.route("/spotify/configure", methods=["POST"])
def spotify_configure():
    """Speichert die Spotify-Client-Zugangsdaten und startet den Login im
    Standardbrowser (Authorization-Code-Flow, Redirect zurueck an diesen
    Hub)."""
    t0 = time.time()
    data = request.get_json(force=True, silent=True) or {}
    client_id = (data.get("client_id") or "").strip()
    client_secret = (data.get("client_secret") or "").strip()
    if not client_id or not client_secret:
        return jsonify({"error": "Client-ID und Client-Secret werden benoetigt."})
    secrets_data = _load_secrets()
    secrets_data["spotify"] = {"client_id": client_id, "client_secret": client_secret}
    _save_secrets(secrets_data)
    print(f"[timing] /spotify/configure GESAMT: {time.time() - t0:.2f}s")
    # Die Login-URL wird ans Frontend zurueckgegeben, das sie per window.open()
    # selbst oeffnet, statt dass der Server versucht einen Browser zu starten
    # (webbrowser.open()/os.startfile() kann auf Windows sehr lange haengen,
    # z.B. bei einem uebersehenen "Womit oeffnen?"-Dialogfenster oder wenn
    # kein Standardbrowser gesetzt ist). window.open() im bereits offenen
    # Browser des Nutzers ist zuverlaessig, da kein OS-Rateraten noetig ist.
    return jsonify({"error": None, "auth_url": _spotify_auth_url(client_id)})


@app.route("/spotify/callback")
def spotify_callback():
    """Redirect-Ziel nach dem Spotify-Login — tauscht den Code gegen
    Access-/Refresh-Token und speichert sie in secrets.json."""
    t0 = time.time()
    error = request.args.get("error")
    if error:
        return f"Spotify-Login abgebrochen: {error}"
    code = request.args.get("code")
    secrets_data = _load_secrets()
    sp = secrets_data.get("spotify") or {}
    if not sp.get("client_id"):
        return "Kein Spotify-Client konfiguriert — erst in den A.R.I-Einstellungen Client-ID/Secret eintragen."
    try:
        token_resp = _spotify_token_request(sp["client_id"], sp["client_secret"], {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": SPOTIFY_REDIRECT_URI,
        })
        print(f"[timing] /spotify/callback Token-Austausch: {time.time() - t0:.2f}s")
    except Exception as e:
        print(f"[timing] /spotify/callback Token-Austausch fehlgeschlagen nach {time.time() - t0:.2f}s: {e}")
        return f"Fehler beim Token-Austausch: {e}"
    sp["token"] = {
        "access_token": token_resp["access_token"],
        "refresh_token": token_resp["refresh_token"],
        "expires_at": time.time() + token_resp.get("expires_in", 3600) - 30,
    }
    secrets_data["spotify"] = sp
    _save_secrets(secrets_data)
    return (
        "<html><body style='background:#0a0a0f;color:#29d3f5;font-family:monospace;"
        "text-align:center;padding:60px'><h2>Spotify verbunden.</h2>"
        "<p>Dieses Fenster kannst du jetzt schliessen.</p></body></html>"
    )


GAME_PROFILES_FILE = os.path.join(DATA_DIR, "game_profiles.json")
# Vorbefuellter Startzustand fuer das game_action-Tool (siehe TOOLS/run_tool
# weiter unten) — echte Star-Citizen-Standardtasten, damit "fahr das
# Fahrwerk aus" sofort funktioniert, ohne dass der Nutzer erst selbst alles
# in Einstellungen > Spiele anlegen muss. Einzelne Bindungen aendern sich
# gelegentlich zwischen SC-Patches — das ist kein Problem, jede Zeile bleibt
# ueber die UI frei editierbar/loeschbar wie jeder selbst hinzugefuegte Eintrag.
_DEFAULT_GAME_PROFILES = {
    "star citizen": {
        "display_name": "Star Citizen",
        "aliases": ["sc"],
        "actions": {
            # Mausklicks (Position als Anteil 0.0-1.0 der Bildschirmgroesse,
            # aufloesungsunabhaengig) — noch unkalibriert, der Nutzer erfasst sie
            # einmal unter Einstellungen > Spiele. plan_route nutzt genau diese
            # beiden ("suchfeld" zuerst, "suchergebnis" nach dem Tippen).
            "klick suchfeld": {"label": "Suchfeld (Sternenkarte)", "key": "", "click": {}, "category": "Mausklicks"},
            "klick suchergebnis": {"label": "Suchergebnis (Sternenkarte)", "key": "", "click": {}, "category": "Mausklicks"},
            # Allgemein
            "pause menue": {"label": "Pause-/Optionsmenue", "key": "Escape", "category": "Allgemein"},
            "chat umschalten": {"label": "Chat-Fenster ein-/ausblenden", "key": "F12", "category": "Allgemein"},
            "screenshot": {"label": "Screenshot aufnehmen", "key": "Druck", "category": "Allgemein"},
            "konsole": {"label": "Konsole oeffnen", "key": "`", "category": "Allgemein"},
            "einladung annehmen": {"label": "Einladung annehmen", "key": "[", "category": "Allgemein"},
            "einladung ablehnen": {"label": "Einladung ablehnen/ignorieren (halten)", "key": "]", "category": "Allgemein"},
            "kontakte umschalten": {"label": "Kontakte/2D-UI-Cursor ein-/ausblenden", "key": "F11", "category": "Allgemein"},
            "mobiglas": {"label": "MobiGlas ein-/ausschalten", "key": "F1", "category": "Allgemein"},
            "sternenkarte": {"label": "Sternkarte ein-/ausblenden", "key": "F2", "category": "Allgemein"},
            # Zu Fuss
            "springen": {"label": "Springen", "key": "Leertaste", "category": "Zu Fuß"},
            "interagieren": {"label": "Interagieren", "key": "F", "category": "Zu Fuß"},
            "seitenwaffe ausruesten": {"label": "Seitenwaffe ausruesten", "key": "1", "category": "Zu Fuß"},
            "hauptwaffe ausruesten": {"label": "Hauptwaffe ausruesten", "key": "2", "category": "Zu Fuß"},
            "nebenwaffe ausruesten": {"label": "Nebenwaffe ausruesten", "key": "3", "category": "Zu Fuß"},
            "geraet ausruesten": {"label": "Geraet ausruesten", "key": "4", "category": "Zu Fuß"},
            "nahkampfwaffe ausruesten": {"label": "Nahkampfwaffe ausruesten", "key": "5", "category": "Zu Fuß"},
            "waffe nachladen": {"label": "Waffe nachladen", "key": "R", "category": "Zu Fuß"},
            "granate ausruesten": {"label": "Granate ausruesten", "key": "G", "category": "Zu Fuß"},
            "feuermodus umschalten fuss": {"label": "Feuermodus umschalten (zu Fuss)", "key": "B", "category": "Zu Fuß"},
            "medizinstift ausruesten": {"label": "Medizinstift ausruesten", "key": "C", "category": "Zu Fuß"},
            "anzuglicht umschalten": {"label": "Anzuglicht umschalten", "key": "T", "category": "Zu Fuß"},
            "rennen": {"label": "Rennen (Sprint)", "key": "Shift", "category": "Zu Fuß"},
            "links lehnen": {"label": "Nach links lehnen", "key": "Q", "category": "Zu Fuß"},
            "rechts lehnen": {"label": "Nach rechts lehnen", "key": "E", "category": "Zu Fuß"},
            "ducken": {"label": "Ducken", "key": "Strg", "category": "Zu Fuß"},
            "kriechen": {"label": "Kriechen", "key": "X", "category": "Zu Fuß"},
            "waffe anpassen": {"label": "Waffe anpassen", "key": "J", "category": "Zu Fuß"},
            "freilook": {"label": "Freilook (halten)", "key": "Z", "category": "Zu Fuß"},
            # Im Schiff
            "sitz verlassen": {"label": "Sitz/Fahrzeug verlassen (halten)", "key": "Y", "category": "Im Schiff"},
            "eject": {"label": "Eject (Sitz ausstossen)", "key": "Alt+Y", "category": "Im Schiff"},
            "notausstieg": {"label": "Notausstieg", "key": "Shift+U", "category": "Im Schiff"},
            "fracht abwerfen": {"label": "Fracht abwerfen (Cargo Jettison)", "key": "Alt+J", "category": "Im Schiff"},
            "fahrzeug betreten": {"label": "Fahrzeug betreten", "key": "F", "category": "Im Schiff"},
            "fahrwerk": {"label": "Fahrwerk ein-/ausfahren (Landemodus umschalten, halten)", "key": "N", "category": "Im Schiff"},
            "landeerlaubnis": {"label": "Start-/Landeerlaubnis einholen", "key": "Alt+N", "category": "Im Schiff"},
            "tempomat umschalten": {"label": "Tempomat umschalten", "key": "Alt+C", "category": "Im Schiff"},
            "quantenantrieb umschalten": {"label": "Quantenantrieb umschalten", "key": "B", "category": "Im Schiff"},
            "quantensprung starten": {"label": "Quantensprung starten (halten)", "key": "B", "category": "Im Schiff"},
            "flugbereit": {"label": "Flugbereit (Startsequenz)", "key": "RAlt+R", "category": "Im Schiff"},
            "entkoppelten modus umschalten": {"label": "Entkoppelten Modus umschalten", "key": "C", "category": "Im Schiff"},
            "motoren umschalten": {"label": "Triebwerke/Motoren an/aus", "key": "I", "category": "Im Schiff"},
            "schilde umschalten": {"label": "Schilde an/aus", "key": "O", "category": "Im Schiff"},
            "booster": {"label": "Booster/Afterburner (Schub-Verstaerkung)", "key": "Shift", "category": "Im Schiff"},
            "fahrzeugleuchten": {"label": "Aussenbeleuchtung umschalten", "key": "L", "category": "Im Schiff"},
            "sitz aktiv modus": {"label": "Master-Modus durchschalten", "key": "B", "category": "Im Schiff"},
            "gimbal modus": {"label": "Gimbal-Modus umschalten", "key": "G", "category": "Im Schiff"},
            "vtol umschalten": {"label": "VTOL-Modus umschalten (M1: Neu konfigurieren)", "key": "K", "category": "Im Schiff"},
            "zuruecksehen": {"label": "Nach hinten schauen (halten)", "key": ",", "category": "Im Schiff"},
            "schiffsrotation sperren": {"label": "Schiffsrotation sperren", "key": ".", "category": "Im Schiff"},
            "weltraumbremse": {"label": "Weltraumbremse", "key": "X", "category": "Im Schiff"},
            "links rollen": {"label": "Nach links rollen", "key": "Q", "category": "Im Schiff"},
            "rechts rollen": {"label": "Nach rechts rollen", "key": "E", "category": "Im Schiff"},
            "nicken gieren sperre": {"label": "Nicken-/Gieren-Sperre umschalten", "key": "RShift", "category": "Im Schiff"},
            "interaktionsmodus": {"label": "Interaktionsmodus / Inner Thought", "key": "Tab", "category": "Allgemein"},
            "fahrzeug bremsen": {"label": "Bodenfahrzeug bremsen", "key": "X", "category": "Im Schiff"},
            "energie umschalten": {"label": "Energie an/aus", "key": "P", "category": "Im Schiff"},
            "scanmodus umschalten": {"label": "Scanmodus umschalten", "key": "V", "category": "Im Schiff"},
            "kamera ansicht wechseln": {"label": "Kamera-Ansicht durchschalten", "key": "F4", "category": "Im Schiff"},
            # Kampf
            "ziel aufschalten": {"label": "Ziel aufschalten/freigeben", "key": "F8", "category": "Kampf"},
            "ziel 1 aufschalten": {"label": "Ziel 1 aufschalten", "key": "1", "category": "Kampf"},
            "ziel 2 aufschalten": {"label": "Ziel 2 aufschalten", "key": "2", "category": "Kampf"},
            "ziel 3 aufschalten": {"label": "Ziel 3 aufschalten", "key": "3", "category": "Kampf"},
            "angreifer durchschalten": {"label": "Angreifer durchschalten", "key": "4", "category": "Kampf"},
            "feinde durchschalten": {"label": "Feinde durchschalten", "key": "5", "category": "Kampf"},
            "freunde durchschalten": {"label": "Freunde durchschalten", "key": "6", "category": "Kampf"},
            "gimbal unterstuetzung": {"label": "Gimbal-Unterstuetzung umschalten", "key": "G", "category": "Kampf"},
            "gegenmassnahmen": {"label": "Gegenmassnahmen ausstossen", "key": "J", "category": "Kampf"},
            "energie auf alles": {"label": "Energie gleichmaessig verteilen", "key": "U", "category": "Kampf"},
            "energie auf antrieb erhoehen": {"label": "Energie auf Antrieb erhoehen", "key": "F5", "category": "Kampf"},
            "energie auf schilde erhoehen": {"label": "Energie auf Schilde erhoehen", "key": "F6", "category": "Kampf"},
            "energie auf waffen erhoehen": {"label": "Energie auf Waffen erhoehen", "key": "F7", "category": "Kampf"},
            "energieverteilung standard": {"label": "Energieverteilung auf Standard", "key": "F8", "category": "Kampf"},
            "schild vorne": {"label": "Schildstaerke vorne erhoehen", "key": "Num8", "category": "Kampf"},
            "schild hinten": {"label": "Schildstaerke hinten erhoehen", "key": "Num2", "category": "Kampf"},
            "schild links": {"label": "Schildstaerke links erhoehen", "key": "Num4", "category": "Kampf"},
            "schild rechts": {"label": "Schildstaerke rechts erhoehen", "key": "Num6", "category": "Kampf"},
            "schild oben": {"label": "Schildstaerke oben erhoehen", "key": "Num7", "category": "Kampf"},
            "schild unten": {"label": "Schildstaerke unten erhoehen", "key": "Num1", "category": "Kampf"},
            "schild standard": {"label": "Schildstaerke auf Standard", "key": "Num5", "category": "Kampf"},
            # Mining
            "miningmodus": {"label": "Miningmodus umschalten", "key": "M", "category": "Mining"},
            "mining gimbal": {"label": "Mining-Gimbal umschalten", "key": "G", "category": "Mining"},
            "mining verbrauchsmaterial 1": {"label": "Verbrauchsmaterial 1 (z.B. Optimaler Mining-Modul)", "key": "Alt+1", "category": "Mining"},
            "mining verbrauchsmaterial 2": {"label": "Verbrauchsmaterial 2", "key": "Alt+2", "category": "Mining"},
            "mining verbrauchsmaterial 3": {"label": "Verbrauchsmaterial 3", "key": "Alt+3", "category": "Mining"},
            "gesteinsscan": {"label": "Gestein scannen (Rock Scan)", "key": "V", "category": "Mining"},
            "salvagemodus": {"label": "Salvagemodus umschalten", "key": "M", "category": "Salvage"},
            "salvage gimbal": {"label": "Salvage-Gimbal umschalten", "key": "G", "category": "Salvage"},
            "cm decoy": {"label": "Gegenmassnahmen-Koeder (Decoy)", "key": "H", "category": "Kampf"},
            "sub target cycle": {"label": "Untergeordnetes Ziel wechseln", "key": "R", "category": "Kampf"},
            "target in view": {"label": "Ziel in Sicht automatisch anvisieren (halten)", "key": "T", "category": "Kampf"},
            "lock pin 1": {"label": "Ziel auf Pin 1 sperren", "key": "1", "category": "Kampf"},
            "lock pin 2": {"label": "Ziel auf Pin 2 sperren", "key": "2", "category": "Kampf"},
            "lock pin 3": {"label": "Ziel auf Pin 3 sperren", "key": "3", "category": "Kampf"},
            "naechstes ziel angreifer": {"label": "Naechstes Ziel: Angreifer", "key": "4", "category": "Kampf"},
            "naechstes ziel feindlich": {"label": "Naechstes Ziel: Feindlich", "key": "5", "category": "Kampf"},
            "naechstes ziel freundlich": {"label": "Naechstes Ziel: Freundlich", "key": "6", "category": "Kampf"},
            "naechstes ziel alle": {"label": "Naechstes Ziel: Alle", "key": "7", "category": "Kampf"},
            "ziel anrufen": {"label": "Ziel anrufen (Hail)", "key": "9", "category": "Kampf"},
            "alle ziele entfernen": {"label": "Alle gepinnten Ziele entfernen", "key": "0", "category": "Kampf"},
            "selbstzerstoerung": {"label": "Selbstzerstoerung umschalten (halten)", "key": "Backspace", "category": "Kampf"},
            "bewegung springen eva hoch": {"label": "Springen / EVA hoch", "key": "Leertaste", "category": "Allgemein"},
            "bewegung ducken eva runter": {"label": "Ducken / EVA runter", "key": "Strg", "category": "Allgemein"},
            "bewegung sprint boost": {"label": "Sprint / Boost", "key": "Shift", "category": "Allgemein"},
            "interface inventar": {"label": "Inventar", "key": "I", "category": "Allgemein"},
            "interface chat": {"label": "Chat", "key": "Enter", "category": "Allgemein"},
            "kommunikation push to talk": {"label": "Push-to-Talk (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "kommunikation voice channel": {"label": "Voice Channel (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "fahrzeug fahrzeuglicht": {"label": "Fahrzeuglicht (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "fahrzeug hupe": {"label": "Hupe (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote men": {"label": "Emote-Menü (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote n chste": {"label": "Emote nächste (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote vorherige": {"label": "Emote vorherige (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item aufnehmen": {"label": "Item aufnehmen", "key": "F", "category": "Allgemein"},
            "allgemein item fallen lassen": {"label": "Item fallen lassen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item untersuchen": {"label": "Item untersuchen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item ausr sten": {"label": "Item ausrüsten (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item ablegen": {"label": "Item ablegen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein inventory search": {"label": "Inventory Search (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "flug roll links": {"label": "Roll links", "key": "Q", "category": "Im Schiff"},
            "flug roll rechts": {"label": "Roll rechts", "key": "E", "category": "Im Schiff"},
            "flug nav mode": {"label": "NAV Mode", "key": "B", "category": "Im Schiff"},
            "flug quantum travel": {"label": "Quantum Travel (halten)", "key": "B", "category": "Im Schiff"},
            "flug geschwindigkeitsbegrenzer": {"label": "Geschwindigkeitsbegrenzer + (Standard: Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "flug geschwindigkeitsbegrenzer 2": {"label": "Geschwindigkeitsbegrenzer - (Standard: Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "flug esp": {"label": "ESP (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "flug g safe": {"label": "G-Safe (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme engines on": {"label": "Engines On", "key": "R", "category": "Im Schiff"},
            "systeme engines off": {"label": "Engines Off", "key": "U", "category": "Im Schiff"},
            "systeme power on": {"label": "Power On (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme power off": {"label": "Power Off (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme ship lights": {"label": "Ship Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme headlights": {"label": "Headlights", "key": "L", "category": "Im Schiff"},
            "systeme cockpit lights": {"label": "Cockpit Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme landing lights": {"label": "Landing Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme emergency lights": {"label": "Emergency Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme alle t ren ffnen": {"label": "Alle Türen öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme alle t ren schlie en": {"label": "Alle Türen schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme cargo bay ffnen": {"label": "Cargo Bay öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme cargo bay schlie en": {"label": "Cargo Bay schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation nav mode": {"label": "NAV Mode", "key": "B", "category": "Im Schiff"},
            "navigation quantum spool": {"label": "Quantum spool (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum calibration": {"label": "Quantum calibration (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum jump": {"label": "Quantum jump (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum abbrechen": {"label": "Quantum abbrechen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation ziel ausw hlen": {"label": "Ziel auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation route setzen": {"label": "Route setzen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation route l schen": {"label": "Route löschen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation n chstes nav ziel": {"label": "Nächstes NAV-Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation vorheriges nav ziel": {"label": "Vorheriges NAV-Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request landing": {"label": "Request Landing (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request takeoff": {"label": "Request Takeoff (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing docking mode": {"label": "Docking Mode (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request docking": {"label": "Request Docking (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing dock": {"label": "Dock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing undock": {"label": "Undock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo grid ffnen": {"label": "Cargo Grid öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo grid schlie en": {"label": "Cargo Grid schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo bewegen": {"label": "Cargo bewegen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo drehen": {"label": "Cargo drehen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo platzieren": {"label": "Cargo platzieren (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo entfernen": {"label": "Cargo entfernen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo scan": {"label": "Cargo Scan (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren t r ffnen": {"label": "Tür öffnen", "key": "F", "category": "Im Schiff"},
            "t ren t r schlie en": {"label": "Tür schließen", "key": "F", "category": "Im Schiff"},
            "t ren rampe ffnen": {"label": "Rampe öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren rampe schlie en": {"label": "Rampe schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren aufzug rufen": {"label": "Aufzug rufen", "key": "F", "category": "Im Schiff"},
            "t ren airlock ffnen": {"label": "Airlock öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren airlock schlie en": {"label": "Airlock schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd focus": {"label": "MFD Focus (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd n chste seite": {"label": "MFD nächste Seite (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd vorherige seite": {"label": "MFD vorherige Seite (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 1": {"label": "MFD Seite 1 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 2": {"label": "MFD Seite 2 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 3": {"label": "MFD Seite 3 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 4": {"label": "MFD Seite 4 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 5": {"label": "MFD Seite 5 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 6": {"label": "MFD Seite 6 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd reset": {"label": "MFD Reset (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar ping": {"label": "Radar Ping (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar reichweite": {"label": "Radar Reichweite + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar reichweite 2": {"label": "Radar Reichweite - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar ping winkel": {"label": "Ping Winkel + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar ping winkel 2": {"label": "Ping Winkel - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar focus": {"label": "Radar Focus (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar zoom": {"label": "Radar Zoom (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar contact ausw hlen": {"label": "Radar Contact auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar contact l schen": {"label": "Radar Contact löschen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "scan scan mode": {"label": "Scan Mode", "key": "V", "category": "Im Schiff"},
            "scan scan starten": {"label": "Scan starten (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "scan scan angle": {"label": "Scan Angle + (Standard: Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "scan scan angle 2": {"label": "Scan Angle - (Standard: Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret betreten": {"label": "Turret betreten", "key": "F", "category": "Im Schiff"},
            "turret turret verlassen": {"label": "Turret verlassen", "key": "Y", "category": "Im Schiff"},
            "turret turret feuer": {"label": "Turret Feuer (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret secondary": {"label": "Turret Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret lock": {"label": "Turret Lock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "turret n chster turret": {"label": "Nächster Turret (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "turret vorheriger turret": {"label": "Vorheriger Turret (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "operator operator seat betreten": {"label": "Operator Seat betreten", "key": "F", "category": "Im Schiff"},
            "operator operator seat verlassen": {"label": "Operator Seat verlassen", "key": "Y", "category": "Im Schiff"},
            "operator operator mode wechseln": {"label": "Operator Mode wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "operator operator fire": {"label": "Operator Fire (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "operator operator secondary": {"label": "Operator Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor tractor beam aktivieren": {"label": "Tractor Beam aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor tractor beam l sen": {"label": "Tractor Beam lösen (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor objekt vor": {"label": "Objekt vor (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt zur ck": {"label": "Objekt zurück (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt links": {"label": "Objekt links (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt rechts": {"label": "Objekt rechts (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt hoch": {"label": "Objekt hoch (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt runter": {"label": "Objekt runter (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor distanz": {"label": "Distanz + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor distanz 2": {"label": "Distanz - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt drehen": {"label": "Objekt drehen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "waffen waffengruppe 1 feuern": {"label": "Waffengruppe 1 feuern (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "waffen waffengruppe 2 feuern": {"label": "Waffengruppe 2 feuern (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "waffen waffengruppe 1": {"label": "Waffengruppe 1", "key": "1", "category": "Kampf"},
            "waffen waffengruppe 2": {"label": "Waffengruppe 2", "key": "2", "category": "Kampf"},
            "waffen waffengruppe 3": {"label": "Waffengruppe 3", "key": "3", "category": "Kampf"},
            "waffen waffengruppe 4": {"label": "Waffengruppe 4", "key": "4", "category": "Kampf"},
            "waffen waffengruppe 5": {"label": "Waffengruppe 5", "key": "5", "category": "Kampf"},
            "waffen waffengruppe 6": {"label": "Waffengruppe 6", "key": "6", "category": "Kampf"},
            "waffen gimbal assist": {"label": "Gimbal Assist (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen fixed mode": {"label": "Fixed Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen pip wechseln": {"label": "PIP wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen lead pip": {"label": "Lead PIP (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen lag pip": {"label": "Lag PIP (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen waffenreichweite": {"label": "Waffenreichweite (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel aufschalten": {"label": "Ziel aufschalten (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel l sen": {"label": "Ziel lösen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes ziel": {"label": "Nächstes Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting vorheriges ziel": {"label": "Vorheriges Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes feindliches ziel": {"label": "Nächstes feindliches Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes freundliches ziel": {"label": "Nächstes freundliches Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chster angreifer": {"label": "Nächster Angreifer", "key": "4", "category": "Kampf"},
            "targeting n chster feind": {"label": "Nächster Feind", "key": "5", "category": "Kampf"},
            "targeting n chster freund": {"label": "Nächster Freund", "key": "6", "category": "Kampf"},
            "targeting n chste rakete": {"label": "Nächste Rakete (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel unter fadenkreuz": {"label": "Ziel unter Fadenkreuz (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting subsystem ausw hlen": {"label": "Subsystem auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel l schen": {"label": "Ziel löschen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting pin target 1": {"label": "Pin Target 1", "key": "Alt+1", "category": "Kampf"},
            "targeting pin target 2": {"label": "Pin Target 2", "key": "Alt+2", "category": "Kampf"},
            "targeting pin target 3": {"label": "Pin Target 3", "key": "Alt+3", "category": "Kampf"},
            "targeting pin 1 ausw hlen": {"label": "Pin 1 auswählen", "key": "1", "category": "Kampf"},
            "targeting pin 2 ausw hlen": {"label": "Pin 2 auswählen", "key": "2", "category": "Kampf"},
            "targeting pin 3 ausw hlen": {"label": "Pin 3 auswählen", "key": "3", "category": "Kampf"},
            "missiles missile operator mode": {"label": "Missile Operator Mode", "key": "M", "category": "Kampf"},
            "missiles missile lock": {"label": "Missile Lock (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles missile launch": {"label": "Missile Launch (Standard: MMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "missiles rakete wechseln": {"label": "Rakete wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles raketenart n chste": {"label": "Raketenart nächste (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles raketenart vorherige": {"label": "Raketenart vorherige (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles lock abbrechen": {"label": "Lock abbrechen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles missile camera": {"label": "Missile Camera (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure": {"label": "Countermeasure", "key": "H", "category": "Kampf"},
            "countermeasures decoy": {"label": "Decoy (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures noise": {"label": "Noise (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures decoy burst": {"label": "Decoy Burst (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures noise burst": {"label": "Noise Burst (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure mode": {"label": "Countermeasure Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure quantity": {"label": "Countermeasure Quantity + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure quantity 2": {"label": "Countermeasure Quantity - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power power to weapons": {"label": "Power to Weapons", "key": "F5", "category": "Kampf"},
            "power power to engines": {"label": "Power to Engines", "key": "F6", "category": "Kampf"},
            "power power to shields": {"label": "Power to Shields", "key": "F7", "category": "Kampf"},
            "power power reset": {"label": "Power Reset", "key": "F8", "category": "Kampf"},
            "power weapon power": {"label": "Weapon Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power weapon power 2": {"label": "Weapon Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power engine power": {"label": "Engine Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power engine power 2": {"label": "Engine Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power shield power": {"label": "Shield Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power shield power 2": {"label": "Shield Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde schild vorne": {"label": "Schild vorne", "key": "Num8", "category": "Kampf"},
            "schilde schild hinten": {"label": "Schild hinten", "key": "Num2", "category": "Kampf"},
            "schilde schild links": {"label": "Schild links", "key": "Num4", "category": "Kampf"},
            "schilde schild rechts": {"label": "Schild rechts", "key": "Num6", "category": "Kampf"},
            "schilde schild balance": {"label": "Schild Balance", "key": "Num5", "category": "Kampf"},
            "schilde front": {"label": "Front + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde front 2": {"label": "Front - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde rear": {"label": "Rear + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde rear 2": {"label": "Rear - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde left": {"label": "Left + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde left 2": {"label": "Left - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde right": {"label": "Right + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde right 2": {"label": "Right - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat combat mode": {"label": "Combat Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat target focus": {"label": "Target Focus (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat fire group cycle": {"label": "Fire Group Cycle (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat weapon camera": {"label": "Weapon Camera (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat target info": {"label": "Target Info (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "mining mining laser": {"label": "Mining Laser (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining mining laser secondary": {"label": "Mining Laser Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining laserleistung": {"label": "Laserleistung + (Standard: Alt+Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining laserleistung 2": {"label": "Laserleistung - (Standard: Alt+Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining consumable 1": {"label": "Consumable 1", "key": "Alt+1", "category": "Mining"},
            "mining consumable 2": {"label": "Consumable 2", "key": "Alt+2", "category": "Mining"},
            "mining consumable 3": {"label": "Consumable 3", "key": "Alt+3", "category": "Mining"},
            "mining mining module 1": {"label": "Mining Module 1 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining module 2": {"label": "Mining Module 2 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining module 3": {"label": "Mining Module 3 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining laser overcharge": {"label": "Laser Overcharge (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining scan starten": {"label": "Scan starten (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining fracture": {"label": "Fracture (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining extract": {"label": "Extract (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining next mining head": {"label": "Next Mining Head (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining previous mining head": {"label": "Previous Mining Head (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining filter": {"label": "Mining Filter (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining focus": {"label": "Mining Focus (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining collect material": {"label": "Collect Material (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining stop laser": {"label": "Stop Laser (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining throttle while mining": {"label": "Throttle while mining (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "salvage salvage beam": {"label": "Salvage Beam (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "salvage salvage modifier": {"label": "Salvage Modifier (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "salvage beam spacing": {"label": "Beam Spacing + (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage beam spacing 2": {"label": "Beam Spacing - (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage beam axis": {"label": "Beam Axis (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage abrade": {"label": "Abrade (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage scrape": {"label": "Scrape (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage structural salvage": {"label": "Structural Salvage (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage material collect": {"label": "Material Collect (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage filter": {"label": "Salvage Filter (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage container": {"label": "Salvage Container (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage next salvage mode": {"label": "Next Salvage Mode (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage previous salvage mode": {"label": "Previous Salvage Mode (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage focus": {"label": "Salvage Focus (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage target": {"label": "Salvage Target (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage stop beam": {"label": "Stop Beam (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor tractor beam aktivieren 2": {"label": "Tractor Beam aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "tractor tractor beam l sen 2": {"label": "Tractor Beam lösen (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "tractor objekt vor 2": {"label": "Objekt vor (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt zur ck 2": {"label": "Objekt zurück (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt links 2": {"label": "Objekt links (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt rechts 2": {"label": "Objekt rechts (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt hoch 2": {"label": "Objekt hoch (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt runter 2": {"label": "Objekt runter (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor distanz 3": {"label": "Distanz + (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor distanz 4": {"label": "Distanz - (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt drehen 2": {"label": "Objekt drehen (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt locken": {"label": "Objekt locken (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor n chstes objekt": {"label": "Nächstes Objekt (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "bewegung sprinten": {"label": "Sprinten", "key": "Shift", "category": "Zu Fuß"},
            "bewegung ducken": {"label": "Ducken", "key": "Strg", "category": "Zu Fuß"},
            "bewegung springen": {"label": "Springen", "key": "Leertaste", "category": "Zu Fuß"},
            "bewegung prone": {"label": "Prone", "key": "X", "category": "Zu Fuß"},
            "bewegung lean left": {"label": "Lean Left", "key": "Q", "category": "Zu Fuß"},
            "bewegung lean right": {"label": "Lean Right", "key": "E", "category": "Zu Fuß"},
            "ausr stung inventar": {"label": "Inventar", "key": "I", "category": "Zu Fuß"},
            "ausr stung helm an aus": {"label": "Helm an/aus (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "ausr stung r stung an aus": {"label": "Rüstung an/aus (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "ausr stung backpack": {"label": "Backpack (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen waffe holstern": {"label": "Waffe holstern (halten)", "key": "R", "category": "Zu Fuß"},
            "waffen fire": {"label": "Fire (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "waffen aim zoom": {"label": "Aim / Zoom (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "waffen weapon inspect": {"label": "Weapon Inspect (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen scope zoom": {"label": "Scope Zoom (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen fire mode wechseln": {"label": "Fire Mode wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen attachment wechseln": {"label": "Attachment wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin medical tool": {"label": "Medical Tool (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin heilen": {"label": "Heilen (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin medical target": {"label": "Medical Target (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool multi tool aktivieren": {"label": "Multi-Tool aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "multi tool multi tool secondary": {"label": "Multi-Tool Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "multi tool attachment wechseln": {"label": "Attachment wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool tractor beam": {"label": "Tractor Beam (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool medical mode": {"label": "Medical Mode (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool repair mode": {"label": "Repair Mode (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "eva roll links": {"label": "Roll links", "key": "Q", "category": "Zu Fuß"},
            "eva roll rechts": {"label": "Roll rechts", "key": "E", "category": "Zu Fuß"},
            "eva eva boost": {"label": "EVA Boost", "key": "Shift", "category": "Zu Fuß"},
            "eva eva stop": {"label": "EVA Stop", "key": "X", "category": "Zu Fuß"},
            "eva eva stabilize": {"label": "EVA Stabilize (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "kommunikation push to talk 2": {"label": "Push-to-Talk (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "kommunikation voice channel 2": {"label": "Voice Channel (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
        },
    },
}


def _migrate_route_clicks(profiles):
    """Frueher lagen die zwei Sternenkarten-Klickpositionen als feste Felder
    (route_search_click / route_result_click) im Profil; jetzt sind es ganz
    normale, erweiterbare Mausklick-Aktionen (Kategorie "Mausklicks", Feld
    "click"). Bestehende Werte werden einmalig uebernommen. Gibt True zurueck,
    wenn etwas geaendert wurde (dann wird neu gespeichert)."""
    changed = False
    for key, profile in profiles.items():
        if not isinstance(profile, dict) or not isinstance(profile.get("actions"), dict):
            continue
        actions = profile["actions"]
        for legacy, action_key, label in (
            ("route_search_click", "klick suchfeld", "Suchfeld (Sternenkarte)"),
            ("route_result_click", "klick suchergebnis", "Suchergebnis (Sternenkarte)"),
        ):
            if legacy in profile:
                value = profile.pop(legacy)
                changed = True
                if action_key not in actions and isinstance(value, dict) and "x" in value and "y" in value:
                    actions[action_key] = {"label": label, "key": "", "click": {"x": value["x"], "y": value["y"]}, "category": "Mausklicks"}
        if key == "star citizen":
            for action_key, label in (("klick suchfeld", "Suchfeld (Sternenkarte)"), ("klick suchergebnis", "Suchergebnis (Sternenkarte)")):
                if action_key not in actions:
                    actions[action_key] = {"label": label, "key": "", "click": {}, "category": "Mausklicks"}
                    changed = True
    return changed


def _load_game_profiles():
    if not os.path.exists(GAME_PROFILES_FILE):
        _save_game_profiles(_DEFAULT_GAME_PROFILES)
        return json.loads(json.dumps(_DEFAULT_GAME_PROFILES))
    try:
        with open(GAME_PROFILES_FILE, "r", encoding="utf-8") as f:
            profiles = json.load(f)
    except (OSError, ValueError):
        return {}
    if _migrate_route_clicks(profiles):
        _save_game_profiles(profiles)
    return profiles


def _save_game_profiles(data):
    with open(GAME_PROFILES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


SPAM_SENDERS_FILE = os.path.join(DATA_DIR, "spam_senders.json")
# Als Spam markierte Absender (Anzeigename oder Adresse, klein geschrieben) - werden bei
# /email/check UND /phone/api/data (PC wie Handy) aus den Benachrichtigungen gefiltert,
# nicht nur einmalig ausgeblendet.
def _load_spam_senders():
    try:
        with open(SPAM_SENDERS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def _save_spam_senders(s):
    try:
        with open(SPAM_SENDERS_FILE, "w", encoding="utf-8") as f:
            json.dump(sorted(s), f, ensure_ascii=False)
    except OSError:
        pass


_spam_senders = _load_spam_senders()


def _is_spam_sender(frm):
    frm = str(frm or "").strip().lower()
    if not frm:
        return False
    return any(s in frm or frm in s for s in _spam_senders)


def _add_spam_sender(frm):
    frm = str(frm or "").strip().lower()
    if not frm:
        return False
    _spam_senders.add(frm)
    _save_spam_senders(_spam_senders)
    return True


SEEN_EMAILS_FILE = os.path.join(DATA_DIR, "seen_emails.json")
# Auf Platte statt nur im Speicher — sonst wuerde jede unveraenderte
# ungelesene Mail bei JEDEM Poll (alle paar Minuten, oder erneut nach jedem
# Hub-Neustart) wieder komplett neu per LLM-Aufruf klassifiziert, obwohl sich
# nichts geaendert hat: unnoetige Tokens/Kosten und Latenz. IDs hier sind
# "bereits von der KI beurteilt" (wichtig oder nicht), nicht nur "wichtig" —
# nur wirklich neue, noch nie gesehene Mails werden ueberhaupt an die KI
# geschickt.
def _load_seen_email_ids():
    try:
        with open(SEEN_EMAILS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def _save_seen_email_ids(ids):
    # Auf die letzten 500 begrenzen, sonst waechst die Datei unbegrenzt.
    try:
        with open(SEEN_EMAILS_FILE, "w", encoding="utf-8") as f:
            json.dump(list(ids)[-500:], f)
    except OSError:
        pass


_judged_email_ids = _load_seen_email_ids()


# ---------------------------------------------------------------------------
# Gmail ueber die Google API: nutzt bewusst denselben Google-OAuth-Client wie
# der Kalender (gleiches Google-Cloud-Projekt) — wer den Kalender schon
# verbunden hat, braucht fuer Gmail keine neue Client-ID, nur einen weiteren
# kurzen Login (andere Scopes = eigener Token, getrennt vom Kalender-Token).
# ---------------------------------------------------------------------------
GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.readonly", "https://www.googleapis.com/auth/gmail.send"]

_gmail_service = None
_gmail_init_error = None


def _init_gmail():
    global _gmail_service, _gmail_init_error
    if _gmail_service is not None or _gmail_init_error is not None:
        return
    if _google_api_build is None:
        _gmail_init_error = "Google-Pakete nicht installiert (pip install -r requirements.txt)"
        return
    secrets_data = _load_secrets()
    cal_client = (secrets_data.get("calendar") or {}).get("client")
    if not cal_client:
        _gmail_init_error = "Gmail nutzt denselben Google-Client wie der Kalender — zuerst Kalender verbinden."
        return
    gmail_auth = secrets_data.get("gmail") or {}
    try:
        creds = None
        if gmail_auth.get("token"):
            try:
                creds = _GoogleCredentials.from_authorized_user_info(gmail_auth["token"], GMAIL_SCOPES)
                if creds and not creds.valid:
                    if creds.expired and creds.refresh_token:
                        creds.refresh(_GoogleAuthRequest())
                    else:
                        creds = None
            except Exception:
                # Gespeicherter Token ist ungueltig/widerrufen (z.B.
                # "invalid_grant: Token has been expired or revoked.") —
                # nicht aufgeben, sondern unten frisch einloggen lassen.
                creds = None
        if not creds:
            # Eigener, kurzer Login nur fuer die Gmail-Scopes (blockierend,
            # oeffnet einmalig ein Browserfenster).
            flow = _GoogleInstalledAppFlow.from_client_config({"installed": cal_client}, GMAIL_SCOPES)
            creds = flow.run_local_server(port=0)
            gmail_auth["token"] = json.loads(creds.to_json())
            secrets_data["gmail"] = gmail_auth
            _save_secrets(secrets_data)
        _gmail_service = _google_api_build("gmail", "v1", credentials=creds)
    except Exception as e:
        _gmail_init_error = str(e)


def _is_invalid_grant(e):
    return "invalid_grant" in str(e)


def _reset_gmail_auth():
    """Wirft den lokalen Gmail-Token weg, wenn Google ihn serverseitig
    widerrufen hat (invalid_grant) — die lokale Ablaufzeit sagt das nicht
    voraus, das faellt erst beim echten API-Aufruf auf. Naechster Aufruf
    von _init_gmail() macht dann einen frischen interaktiven Login."""
    global _gmail_service, _gmail_init_error
    _gmail_service = None
    _gmail_init_error = None
    secrets_data = _load_secrets()
    if "gmail" in secrets_data:
        secrets_data["gmail"].pop("token", None)
        _save_secrets(secrets_data)


def _get_gmail_emails(unread_only, max_results):
    _init_gmail()
    if _gmail_service is None:
        return None, _gmail_init_error or "Gmail nicht verbunden"
    try:
        # category:primary filtert Gmails eigene "Werbung"/"Social"/"Updates"-
        # Reiter direkt weg — das faengt die meisten Shop-Newsletter schon vor
        # der eigentlichen KI-Wichtigkeitspruefung ab.
        query = "category:primary" + (" is:unread" if unread_only else "")
        listing = _gmail_service.users().messages().list(
            userId="me", q=query,
            maxResults=max_results, labelIds=["INBOX"],
        ).execute()
        emails = []
        for item in listing.get("messages", []):
            msg = _gmail_service.users().messages().get(
                userId="me", id=item["id"], format="metadata",
                metadataHeaders=["From", "Subject", "Date"],
            ).execute()
            headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
            from_header = headers.get("From", "")
            emails.append({
                "id": item["id"],
                "from": from_header,
                "from_name": from_header.split("<")[0].strip().strip('"'),
                "subject": headers.get("Subject", ""),
                "preview": msg.get("snippet", ""),
                "received": headers.get("Date", ""),
            })
        return emails, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return None, "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return None, str(e)


def _send_gmail_email(to, subject, body):
    import base64
    from email.mime.text import MIMEText

    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        message = MIMEText(body)
        message["to"] = to
        message["subject"] = subject
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        _gmail_service.users().messages().send(userId="me", body={"raw": raw}).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


def _reply_gmail_email(message_id, body):
    import base64
    from email.mime.text import MIMEText

    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        original = _gmail_service.users().messages().get(
            userId="me", id=message_id, format="metadata",
            metadataHeaders=["From", "Subject", "Message-ID", "References"],
        ).execute()
        headers = {h["name"]: h["value"] for h in original.get("payload", {}).get("headers", [])}
        subject = headers.get("Subject", "")
        if not subject.lower().startswith("re:"):
            subject = "Re: " + subject
        message = MIMEText(body)
        message["to"] = headers.get("From", "")
        message["subject"] = subject
        if headers.get("Message-ID"):
            message["In-Reply-To"] = headers["Message-ID"]
            message["References"] = (headers.get("References", "") + " " + headers["Message-ID"]).strip()
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        _gmail_service.users().messages().send(userId="me", body={"raw": raw, "threadId": original.get("threadId")}).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


YAHOO_IMAP_HOST = "imap.mail.yahoo.com"
YAHOO_SMTP_HOST = "smtp.mail.yahoo.com"


def _decode_mime_header(value):
    from email.header import decode_header
    if not value:
        return ""
    decoded = ""
    for text, enc in decode_header(value):
        decoded += text.decode(enc or "utf-8", errors="replace") if isinstance(text, bytes) else text
    return decoded


def _yahoo_creds():
    yahoo = _load_secrets().get("yahoo") or {}
    if not yahoo.get("email") or not yahoo.get("app_password"):
        return None
    return yahoo


def _get_yahoo_emails(unread_only, max_results):
    import email as email_lib
    creds = _yahoo_creds()
    if not creds:
        return None, "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        _, data = imap.uid("search", None, "UNSEEN" if unread_only else "ALL")
        uids = data[0].split()[-max_results:] if data and data[0] else []
        emails = []
        for uid in reversed(uids):
            _, msg_data = imap.uid("fetch", uid, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
            if not msg_data or not msg_data[0]:
                continue
            msg = email_lib.message_from_bytes(msg_data[0][1])
            from_header = _decode_mime_header(msg.get("From", ""))
            emails.append({
                "id": uid.decode(),
                "from": from_header,
                "from_name": from_header.split("<")[0].strip().strip('"'),
                "subject": _decode_mime_header(msg.get("Subject", "")),
                "preview": "",
                "received": msg.get("Date", ""),
            })
        imap.logout()
        return emails, None
    except Exception as e:
        return None, str(e)


def _send_yahoo_email(to, subject, body):
    from email.mime.text import MIMEText
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        message = MIMEText(body)
        message["From"] = creds["email"]
        message["To"] = to
        message["Subject"] = subject
        with smtplib.SMTP_SSL(YAHOO_SMTP_HOST, 465) as smtp:
            smtp.login(creds["email"], creds["app_password"])
            smtp.send_message(message)
        return None
    except Exception as e:
        return str(e)


def _reply_yahoo_email(uid, body):
    import email as email_lib
    from email.mime.text import MIMEText
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        _, msg_data = imap.uid("fetch", uid, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT MESSAGE-ID REFERENCES)])")
        imap.logout()
        if not msg_data or not msg_data[0]:
            return "E-Mail nicht gefunden."
        msg = email_lib.message_from_bytes(msg_data[0][1])
        subject = _decode_mime_header(msg.get("Subject", ""))
        if not subject.lower().startswith("re:"):
            subject = "Re: " + subject
        reply = MIMEText(body)
        reply["From"] = creds["email"]
        reply["To"] = msg.get("From", "")
        reply["Subject"] = subject
        if msg.get("Message-ID"):
            reply["In-Reply-To"] = msg["Message-ID"]
            reply["References"] = (msg.get("References", "") + " " + msg["Message-ID"]).strip()
        with smtplib.SMTP_SSL(YAHOO_SMTP_HOST, 465) as smtp:
            smtp.login(creds["email"], creds["app_password"])
            smtp.send_message(reply)
        return None
    except Exception as e:
        return str(e)


def _provider_status():
    secrets_data = _load_secrets()
    gmail_ok = bool((secrets_data.get("calendar") or {}).get("client")) and bool(secrets_data.get("gmail"))
    yahoo_ok = bool(_yahoo_creds())
    return {"gmail": gmail_ok, "yahoo": yahoo_ok}


def get_recent_emails(unread_only=True, max_results=10):
    status = _provider_status()
    if not status["gmail"] and not status["yahoo"]:
        return None, "Kein E-Mail-Konto verbunden (in den Einstellungen einrichten)."
    combined = []
    errors = []
    if status["gmail"]:
        emails, error = _get_gmail_emails(unread_only, max_results)
        if error:
            errors.append("Gmail: " + error)
        else:
            for e in emails or []:
                e["id"] = "gmail:" + e["id"]
            combined.extend(emails or [])
    if status["yahoo"]:
        emails, error = _get_yahoo_emails(unread_only, max_results)
        if error:
            errors.append("Yahoo: " + error)
        else:
            for e in emails or []:
                e["id"] = "yahoo:" + e["id"]
            combined.extend(emails or [])
    if not combined and errors:
        return None, "; ".join(errors)
    return combined[:max_results], None


def send_new_email(to, subject, body, provider=None):
    status = _provider_status()
    if provider == "yahoo":
        return _send_yahoo_email(to, subject, body)
    if provider == "gmail":
        return _send_gmail_email(to, subject, body)
    if status["gmail"]:
        return _send_gmail_email(to, subject, body)
    if status["yahoo"]:
        return _send_yahoo_email(to, subject, body)
    return "Kein E-Mail-Konto verbunden (in den Einstellungen einrichten)."


def reply_to_email(email_id, body):
    if email_id.startswith("yahoo:"):
        return _reply_yahoo_email(email_id.split(":", 1)[1], body)
    if email_id.startswith("gmail:"):
        return _reply_gmail_email(email_id.split(":", 1)[1], body)
    return "Unbekannte E-Mail-Quelle."


def mark_email_read(email_id):
    """Fuer den X-Knopf an einer einzelnen Benachrichtigung im Frontend —
    markiert die zugehoerige Mail beim jeweiligen Anbieter als gelesen, statt
    sie nur lokal aus der Liste zu entfernen. Gibt None bei Erfolg zurueck,
    sonst eine Fehlermeldung."""
    if email_id.startswith("yahoo:"):
        return _mark_yahoo_read(email_id.split(":", 1)[1])
    if email_id.startswith("gmail:"):
        return _mark_gmail_read(email_id.split(":", 1)[1])
    return "Unbekannte E-Mail-Quelle."


def _mark_gmail_read(message_id):
    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        _gmail_service.users().messages().modify(
            userId="me", id=message_id, body={"removeLabelIds": ["UNREAD"]},
        ).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


def _mark_yahoo_read(uid):
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        imap.uid("STORE", uid, "+FLAGS", "(\\Seen)")
        imap.logout()
        return None
    except Exception as e:
        return str(e)


def _judge_important_emails(emails, provider=None, request_api_key=None, groq_api_keys=None):
    """Nutzt den vom Frontend konfigurierten Anbieter (Einstellungen -> API-
    Schluessel), falls mitgegeben, sonst den zuerst verfuegbaren Env-Var-
    Client, um aus den ungelesenen Mails NUR die wirklich wichtigen
    herauszufiltern (nicht Newsletter/Werbung/automatische Benachrichtigungen)
    — fuer die Hintergrund-Pruefung, die den Nutzer proaktiv informiert.
    WICHTIG: gibt bei einem echten Fehlschlag (kein Client verfuegbar, API-
    Fehler) None zurueck, nicht []  — der Aufrufer markiert Mails nur bei
    einer echten Antwort als "beurteilt". Sonst wuerde eine Mail bei jedem
    Aussetzer (fehlender Key, Netzwerkfehler, Rate-Limit) faelschlich fuer
    immer als "schon geprueft, nicht wichtig" gelten, obwohl sie nie
    tatsaechlich beurteilt wurde."""
    if not emails:
        return []
    client, model, is_anthropic = None, None, False
    if provider == "groq":
        groq_clients = _groq_clients_for(groq_api_keys or [])
        if groq_clients:
            client, model = groq_clients[0][1], GROQ_MODEL
    elif provider:
        client = _client_for(provider, request_api_key)
        model, is_anthropic = (ANTHROPIC_MODEL, True) if provider == "anthropic" else (
            (OPENAI_MODEL, False) if provider == "openai" else (GEMINI_MODEL, False)
        )
    if client is None:
        if _anthropic_client:
            client, model, is_anthropic = _anthropic_client, ANTHROPIC_MODEL, True
        elif _openai_client:
            client, model = _openai_client, OPENAI_MODEL
        elif _groq_client:
            client, model = _groq_client, GROQ_MODEL
    if client is None:
        return None
    listing = "\n".join(
        f"- id={e['id']} | {e['from_name'] or e['from']}: {e['subject']} - {e['preview'][:150]}"
        for e in emails
    )
    prompt = (
        "Hier sind ungelesene E-Mails im Posteingang. Nenne NUR die, die reine WERBUNG "
        "sind (Newsletter, Angebote, Rabatte, Marketing, Umfragen von Shops). Alles andere "
        "(persoenliche Mails, Codes, Sicherheits-/Login-Hinweise, Rechnungen, Bestellungen, "
        "Versand, Termine, Benachrichtigungen von Diensten) ist KEINE Werbung. "
        "Antworte als Zeilen im Format 'id|Werbung'. "
        "Wenn keine Werbung dabei ist, antworte nur mit 'keine'.\n\n" + listing
    )
    try:
        if is_anthropic:
            resp = client.messages.create(model=model, max_tokens=300, messages=[{"role": "user", "content": prompt}])
            text = next((b.text for b in resp.content if b.type == "text"), "")
        elif "gpt-oss" in model:
            # Reasoning-Modelle wie gpt-oss verbrauchen sonst das ganze
            # max_tokens-Budget fuer internes Nachdenken und die eigentliche
            # Antwort bleibt leer — reasoning_effort="low" haelt das kurz
            # (gleiche Behandlung wie beim normalen Chat, siehe /chat).
            try:
                resp = client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}], max_tokens=600, reasoning_effort="low"
                )
            except Exception:
                resp = client.chat.completions.create(model=model, messages=[{"role": "user", "content": prompt}], max_tokens=600)
            text = resp.choices[0].message.content or ""
        else:
            resp = client.chat.completions.create(model=model, messages=[{"role": "user", "content": prompt}], max_tokens=300)
            text = resp.choices[0].message.content or ""
    except Exception as e:
        print(f"[email_check] LLM-Aufruf fehlgeschlagen (provider={provider}, model={model}): {e!r}")
        return None
    text = text.strip()
    ad_ids = set()
    if text and not text.lower().startswith("keine"):
        for line in text.splitlines():
            line = line.strip("- ").strip()
            if "|" in line:
                ad_ids.add(line.split("|", 1)[0].strip().replace("id=", ""))
    # Alles ausser der als Werbung erkannten Mails wird gemeldet
    return [{"id": e["id"], "reason": "Neue E-Mail"} for e in emails if e["id"] not in ad_ids]


@app.route("/email/configure/gmail", methods=["POST"])
def gmail_configure():
    """Verbindet Gmail — braucht keine eigene Client-ID, nutzt den bereits
    beim Kalender hinterlegten Google-Client. Stoesst nur den (separaten,
    weil andere Scopes) Login-Vorgang an."""
    global _gmail_service, _gmail_init_error
    _gmail_service = None
    _gmail_init_error = None
    _init_gmail()
    return jsonify({"error": _gmail_init_error})


@app.route("/email/configure/yahoo", methods=["POST"])
def yahoo_configure():
    """Speichert Yahoo-Mail-Zugangsdaten (E-Mail + App-Passwort fuer IMAP/SMTP,
    kein OAuth noetig) und testet den Login sofort, damit Tippfehler direkt
    auffallen statt erst beim naechsten E-Mail-Abruf."""
    data = request.get_json(force=True, silent=True) or {}
    email_addr = (data.get("email") or "").strip()
    app_password = (data.get("app_password") or "").strip()
    if not email_addr or not app_password:
        return jsonify({"error": "E-Mail-Adresse und App-Passwort werden benoetigt."})
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(email_addr, app_password)
        imap.logout()
    except Exception as e:
        return jsonify({"error": str(e)})
    secrets_data = _load_secrets()
    secrets_data["yahoo"] = {"email": email_addr, "app_password": app_password}
    _save_secrets(secrets_data)
    return jsonify({"error": None})


_HUB_SECRET_KEYS = ("calendar", "gmail", "spotify", "yahoo")


@app.route("/settings/hub-export", methods=["POST"])
def hub_settings_export():
    """Zugangsdaten und Anmeldungen (Google/Gmail/Spotify/Yahoo) fuer die Einstellungs-
    Exportdatei - damit ein Import auf einem anderen PC sofort alles verbindet."""
    if not request.is_json:
        return jsonify({"error": "JSON erforderlich"}), 400
    sec = _load_secrets()
    return jsonify({"secrets": {k: sec[k] for k in _HUB_SECRET_KEYS if k in sec}})


@app.route("/settings/hub-import", methods=["POST"])
def hub_settings_import():
    """Spielt exportierte Zugangsdaten/Anmeldungen ein und prueft jede Verbindung.
    Es wird nie ein Login-Fenster geoeffnet - nur vorhandene Tokens werden getestet."""
    global _calendar_service, _calendar_init_error, _gmail_service, _gmail_init_error
    if not request.is_json:
        return jsonify({"error": "JSON erforderlich"}), 400
    incoming = (request.get_json(silent=True) or {}).get("secrets")
    if not isinstance(incoming, dict):
        return jsonify({"error": "Keine Zugangsdaten in der Datei"}), 400
    sec = _load_secrets()
    for k in _HUB_SECRET_KEYS:
        if isinstance(incoming.get(k), dict):
            sec[k] = incoming[k]
    _save_secrets(sec)
    _calendar_service = None; _calendar_init_error = None
    _gmail_service = None; _gmail_init_error = None
    res = {}
    if (sec.get("calendar") or {}).get("token"):
        try:
            _, err = get_upcoming_events(days=1, max_results=1, days_back=0)
        except Exception as e:
            err = str(e)
        res["calendar"] = {"ok": not err, "error": err}
    else:
        res["calendar"] = {"ok": False, "error": "Anmeldung fehlt"}
    if (sec.get("gmail") or {}).get("token"):
        try:
            _init_gmail()
            res["gmail"] = {"ok": not _gmail_init_error, "error": _gmail_init_error}
        except Exception as e:
            res["gmail"] = {"ok": False, "error": str(e)}
    else:
        res["gmail"] = {"ok": False, "error": "Anmeldung fehlt"}
    if (sec.get("spotify") or {}).get("token"):
        try:
            _, err = _spotify_access_token()
        except Exception as e:
            err = str(e)
        res["spotify"] = {"ok": not err, "error": err}
    else:
        res["spotify"] = {"ok": False, "error": "Anmeldung fehlt"}
    y = sec.get("yahoo") or {}
    if y.get("email") and y.get("app_password"):
        try:
            imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
            imap.login(y["email"], y["app_password"])
            imap.logout()
            res["yahoo"] = {"ok": True, "error": None}
        except Exception as e:
            res["yahoo"] = {"ok": False, "error": str(e)}
    else:
        res["yahoo"] = {"ok": False, "error": "nicht eingerichtet"}
    return jsonify({"results": res})


@app.route("/email/mark-read", methods=["POST"])
def email_mark_read():
    """Fuer den X-Knopf an einer einzelnen Benachrichtigung im Frontend."""
    data = request.get_json(silent=True) or {}
    email_id = (data.get("id") or "").strip()
    if not email_id:
        return jsonify({"error": "Keine E-Mail-ID angegeben."}), 400
    error = mark_email_read(email_id)
    return jsonify({"error": error})


@app.route("/email/spam", methods=["POST"])
def email_mark_spam():
    """Markiert einen Absender dauerhaft als Spam - wird danach bei /email/check
    UND /phone/api/data (PC wie Handy) aus den Benachrichtigungen gefiltert."""
    data = request.get_json(silent=True) or {}
    frm = (data.get("from") or "").strip()
    if not frm:
        return jsonify({"error": "Kein Absender angegeben."}), 400
    _add_spam_sender(frm)
    email_id = (data.get("id") or "").strip()
    if email_id:
        mark_email_read(email_id)
    return jsonify({"error": None})


_MAIL_CODE_RE = re.compile(
    r"(verification|verify|bestätigungs|bestaetigungs|bestätigung|bestaetigung|sicherheits|security|"
    r"passwort|password|kennwort|einmal|one[- ]time|otp|2fa|two[- ]factor|zwei[- ]faktor|"
    r"anmelde|login|log[- ]?in|sign[- ]?in|verifizier|\bcode\b|\bpin\b|token|zugangs)", re.IGNORECASE)


def _mail_code_reason(e):
    text = f"{e.get('subject', '')} {e.get('preview', '')[:200]}"
    if _MAIL_CODE_RE.search(text):
        return "Code/Sicherheit: " + (e.get("subject") or "")[:80]
    return ""


@app.route("/email/check", methods=["GET", "POST"])
def email_check():
    """Fuer die Benachrichtigungen-Kachel im Frontend: prueft ungelesene
    Mails und meldet nur wirklich wichtige, jede E-Mail nur einmal."""
    emails, error = get_recent_emails(unread_only=True, max_results=10)
    if error:
        return jsonify({"important": [], "error": error})
    emails = [e for e in (emails or []) if not _is_spam_sender(e.get("from_name") or e.get("from", ""))]
    data = request.get_json(silent=True) or {}
    provider = data.get("provider") if isinstance(data.get("provider"), str) else None
    raw_api_key = data.get("api_key")
    request_api_key = raw_api_key.strip() if isinstance(raw_api_key, str) and raw_api_key.strip() else None
    raw_groq_keys = data.get("groq_api_keys")
    groq_api_keys = raw_groq_keys if isinstance(raw_groq_keys, list) else []
    # Nur Mails an die KI schicken, die wir noch nie beurteilt haben — sonst
    # wuerden dieselben ungelesenen Mails bei jedem Poll erneut klassifiziert
    # (unnoetige Tokens/Kosten/Latenz), obwohl sich seit dem letzten Check
    # nichts geaendert hat.
    new_emails = [e for e in (emails or []) if e["id"] not in _judged_email_ids]
    # Code-/Sicherheitsmails (Bestaetigungscode, Login, Passwort zuruecksetzen ...) sind zeitkritisch und wuerden von
    # der KI als "automatische Benachrichtigung" aussortiert: feste Regel, ohne KI-Aufruf (spart auch Tokens).
    code_hits = [(e, _mail_code_reason(e)) for e in new_emails]
    code_hits = [(e, r) for e, r in code_hits if r]
    code_ids = {e["id"] for e, _ in code_hits}
    rest = [e for e in new_emails if e["id"] not in code_ids]
    important = _judge_important_emails(rest, provider=provider, request_api_key=request_api_key, groq_api_keys=groq_api_keys) if rest else []
    if important is not None:
        important = [{"id": e["id"], "reason": r} for e, r in code_hits] + important
    # Nur bei einer ECHTEN Antwort als beurteilt markieren — None heisst die
    # Klassifizierung ist fehlgeschlagen (kein Client, API-Fehler), dann soll
    # dieselbe Mail beim naechsten Poll erneut versucht werden, statt fuer
    # immer faelschlich als "nicht wichtig" zu gelten.
    if important is None:
        important = []
    elif new_emails:
        _judged_email_ids.update(e["id"] for e in new_emails)
        _save_seen_email_ids(_judged_email_ids)
    by_id = {e["id"]: e for e in new_emails}
    result = []
    for i in important:
        email = by_id.get(i["id"])
        if email is None:
            # Von der KI genannte id gehoert zu keiner der abgefragten Mails
            # (z.B. verstuemmelte/erfundene id) — lieber ganz auslassen als
            # eine leere Benachrichtigung ("von: , betreff: ") anzuzeigen.
            continue
        _brain_upsert("note:" + str(i["id"]), f"Wichtige Benachrichtigung: E-Mail von {email.get('from_name') or email.get('from', '?')} - {email.get('subject', '')} ({i['reason']})", _BRAIN_MAIL_CAT)
        result.append({
            "id": i["id"],
            "from": email.get("from_name") or email.get("from", ""),
            "subject": email.get("subject", ""),
            "reason": i["reason"],
        })
    return jsonify({"important": result, "error": None})


@app.route("/calendar")
def calendar_events():
    # days_back=60: die Monatsansicht im Kalender-Panel soll auch bereits
    # verstrichene Termine als Punkt/Linie zeigen, nicht nur zukuenftige.
    events, error = get_upcoming_events(days=30, max_results=60, days_back=60)
    return jsonify({"events": events or [], "error": error})


@app.route("/calendar/configure", methods=["POST"])
def calendar_configure():
    """Schreibt Client-ID/Client-Secret (aus den Einstellungen) in
    secrets.json — Alternative dazu, eine von Google heruntergeladene
    JSON-Datei manuell umzubenennen/abzulegen. Danach wird der naechste
    /calendar-Aufruf (bzw. der Verbinden-Button im Frontend) den OAuth-Login
    anstossen."""
    global _calendar_service, _calendar_init_error
    data = request.get_json(silent=True) or {}
    client_id = (data.get("client_id") or "").strip()
    client_secret = (data.get("client_secret") or "").strip()
    if not client_id or not client_secret:
        return jsonify({"error": "client_id und client_secret sind erforderlich"}), 400

    secrets_data = _load_secrets()
    secrets_data["calendar"] = {
        "client": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "redirect_uris": ["http://localhost"],
        },
        "token": None,
    }
    try:
        _save_secrets(secrets_data)
    except OSError as e:
        return jsonify({"error": f"secrets.json konnte nicht geschrieben werden: {e}"}), 500

    # Erzwingt einen frischen Verbindungsversuch (inkl. moeglichem
    # OAuth-Login) beim naechsten /calendar-Aufruf statt eines alten Fehlers.
    _calendar_service = None
    _calendar_init_error = None
    events, error = get_upcoming_events()
    if error:
        return jsonify({"error": error})
    return jsonify({"error": None, "events": events or []})


@app.route("/calendar/configure", methods=["DELETE"])
def calendar_disconnect():
    """Loescht secrets.json wieder von der Platte — Gegenstueck zu
    calendar_configure(), fuer den 'ALLES LOESCHEN'-Button im Frontend."""
    global _calendar_service, _calendar_init_error
    try:
        if os.path.exists(SECRETS_FILE):
            os.remove(SECRETS_FILE)
    except OSError as e:
        return jsonify({"error": f"secrets.json konnte nicht geloescht werden: {e}"}), 500
    _calendar_service = None
    _calendar_init_error = None
    return jsonify({"error": None})


@app.route("/")
def dashboard():
    return send_from_directory(DASHBOARD_DIR, DASHBOARD_FILE)


SOUNDS_DIR = os.path.join(DASHBOARD_DIR, "sounds")


@app.route("/sounds/<path:filename>")
def sounds(filename):
    return send_from_directory(SOUNDS_DIR, filename)


@app.route("/dev/login", methods=["POST"])
def dev_login():
    data = request.get_json(silent=True) or {}
    ok = _check_dev_password(data.get("password"))
    return jsonify({"ok": ok})


# --- Programm-Update ueber GitHub Pages --------------------------------------
# Beim Start (und alle paar Stunden) fragt das HUD /update/check. Gibt es unter _UPDATE_BASE eine neuere
# version.json, kann der Nutzer mit einem Klick aktualisieren: ari-pc.zip wird geladen, per SHA-256 geprueft,
# das neue hub.py auf Syntaxfehler getestet, dann werden nur Programmdateien ersetzt (NIE data/ mit Schluesseln,
# Gehirn usw.), die alten Dateien vorher gesichert und A.R.I startet sich neu.
ARI_VERSION = 8
ARI_VERSION_NAME = "1.3.0"
_UPDATE_BASE = "https://kingshadow1332.github.io/app/pc/"
_UPDATE_NEVER = ("data", "screenshots", "__pycache__", "piper", "A.R.I-Android")
_UPDATE_EXT = {".sh", ".py", ".html", ".js", ".bat", ".md", ".png", ".svg", ".json", ".css", ".txt", ".wav", ".mp3", ".webmanifest", ".ico"}
_update_lock = threading.Lock()


def _update_fetch():
    req = urllib.request.Request(_UPDATE_BASE + "version.json?t=" + str(int(time.time())), headers={"User-Agent": "A.R.I", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


@app.route("/update/check")
def update_check():
    out = {"current": ARI_VERSION, "name": ARI_VERSION_NAME, "available": False}
    try:
        d = _update_fetch()
        out.update(available=int(d.get("version", 0)) > ARI_VERSION, latest=str(d.get("name", "")), notes=str(d.get("notes", ""))[:2000], latest_code=int(d.get("version", 0)))
    except Exception as e:
        out["error"] = f"Update-Suche nicht möglich: {e}"
    return jsonify(out)


def _update_restart():
    if not IS_WIN:
        _lx.schedule_restart(sys.executable, os.path.join(DASHBOARD_DIR, "hub.py"), DASHBOARD_DIR)
        threading.Timer(0.8, _hub_exit, args=("Update wird installiert - A.R.I startet neu",)).start()
        return
    exe = sys.executable
    named = os.path.join(sys.base_prefix, "Ari Assistent.exe")
    if os.path.exists(named):
        exe = named
    hub = os.path.join(DASHBOARD_DIR, "hub.py")
    ps = ("Start-Sleep -Seconds 3; Start-Process -FilePath '" + exe.replace("'", "''") + "' -ArgumentList '\"" + hub.replace("'", "''") + "\"' -WorkingDirectory '" + DASHBOARD_DIR.replace("'", "''") + "'")
    subprocess.Popen(["powershell", "-NoProfile", "-Command", ps])
    threading.Timer(0.8, _hub_exit, args=("Update wird installiert - A.R.I startet neu",)).start()


@app.route("/update/apply", methods=["POST"])
def update_apply():
    if not request.is_json:   # nur mit JSON-Body (loest bei fremden Webseiten einen CORS-Preflight aus und wird blockiert)
        return jsonify({"error": "ungültig"}), 400
    if not _update_lock.acquire(blocking=False):
        return jsonify({"error": "Update läuft bereits."}), 409
    try:
        d = _update_fetch()
        if int(d.get("version", 0)) <= ARI_VERSION:
            return jsonify({"error": "Schon auf dem neuesten Stand."})
        zip_name, want = str(d.get("zip", "")), str(d.get("sha256", "")).lower()
        if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", zip_name) or not re.fullmatch(r"[0-9a-f]{64}", want):
            return jsonify({"error": "Update-Beschreibung ungültig (Zip-Name/Prüfsumme fehlt)."})
        tmp = tempfile.mkdtemp(prefix="ari_update_")
        zpath = os.path.join(tmp, "update.zip")
        req = urllib.request.Request(_UPDATE_BASE + zip_name, headers={"User-Agent": "A.R.I"})
        with urllib.request.urlopen(req, timeout=120) as r, open(zpath, "wb") as f:
            shutil.copyfileobj(r, f)
        h = hashlib.sha256()
        with open(zpath, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        if h.hexdigest() != want:
            return jsonify({"error": "Prüfsumme stimmt nicht – Update verworfen (nichts wurde geändert)."})
        import zipfile
        stage = os.path.join(tmp, "stage")
        files = []
        with zipfile.ZipFile(zpath) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = info.filename.replace("\\", "/")
                parts = name.split("/")
                if name.startswith("/") or ".." in parts or ":" in parts[0] or parts[0] in _UPDATE_NEVER or os.path.splitext(name)[1].lower() not in _UPDATE_EXT:
                    return jsonify({"error": f"Update enthält unerlaubte Datei ({name}) – verworfen."})
                files.append(name)
            z.extractall(stage)
        if "hub.py" in files:
            import py_compile
            try:
                py_compile.compile(os.path.join(stage, "hub.py"), doraise=True)
            except py_compile.PyCompileError as e:
                return jsonify({"error": f"Neues hub.py fehlerhaft – verworfen ({e.msg[:120]})."})
        backup = os.path.join(DATA_DIR, "update-backup-" + time.strftime("%Y%m%d_%H%M%S"))
        for name in files:
            dst = os.path.join(DASHBOARD_DIR, *name.split("/"))
            if os.path.exists(dst):
                os.makedirs(os.path.dirname(os.path.join(backup, *name.split("/"))), exist_ok=True)
                shutil.copy2(dst, os.path.join(backup, *name.split("/")))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(stage, *name.split("/")), dst)
        print(f"[update] {len(files)} Dateien aktualisiert auf {d.get('name')} (Sicherung: {backup})")
        _update_restart()
        return jsonify({"ok": True, "files": len(files), "name": str(d.get("name", ""))})
    except Exception as e:
        return jsonify({"error": f"Update fehlgeschlagen: {e}"})
    finally:
        _update_lock.release()


# --- Handy-Anbindung ------------------------------------------------------
# Der PC-Hub ist das Gehirn und laeuft dauerhaft; das Handy ist eine Fernbedienung
# (Seite /phone, als App zum Homescreen hinzufuegbar). Es nutzt dieselben Daten
# (Gehirn, Kalender, Einstellungen), also ist immer alles auf demselben Stand.
# Sicherheit: Der Hub lauscht im Netz, lehnt von aussen aber ALLES ab, ausser
# der Handy-Seite und /phone/api/* mit gueltigem Geraete-Token. Ein Token gibt es
# nur ueber einen kurzlebigen Koppelcode, den man am PC (im HUD) erzeugt.
import secrets as _pysecrets

_pair = {"code": None, "exp": 0.0, "fails": 0}
_pair_ip_fails = {}
_remote = {"code": None, "uses": 0}
_phone_cache = {"t": 0.0, "cfg": {}}


_PROXY_HEADERS = ("Cf-Connecting-Ip", "Cf-Ray", "X-Forwarded-For", "X-Forwarded-Host", "Forwarded", "X-Real-Ip", "Cf-Visitor")


def _is_local_request():
    """Nur echte Anfragen vom PC selbst. Der Cloudflare-Tunnel verbindet sich von
    127.0.0.1 aus - deshalb zaehlt eine Anfrage mit Proxy-Headern oder fremdem
    Host-Namen NICHT als lokal (sonst waere der ganze Hub aus dem Internet offen)."""
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return False
    if any(h in request.headers for h in _PROXY_HEADERS):
        return False
    host = (request.host or "").split(":")[0].strip("[]").lower()
    return host in ("localhost", "127.0.0.1", "::1")


def _client_ip():
    return request.headers.get("Cf-Connecting-Ip") or request.remote_addr


def _phone_cfg():
    now = time.time()
    if now - _phone_cache["t"] > 3:
        _phone_cache["cfg"] = _load_secrets().get("phone") or {}
        _phone_cache["t"] = now
    return _phone_cache["cfg"]


def _phone_save(cfg):
    s = _load_secrets()
    s["phone"] = cfg
    _save_secrets(s)
    _phone_cache["cfg"] = cfg
    _phone_cache["t"] = time.time()


def _phone_keep_alive():
    cfg = _phone_cfg()
    # Nur wenn ausdruecklich eingeschaltet: sonst schliesst sich A.R.I 20 s nach dem Schliessen des HUD-Fensters (das Handy laeuft dann eigenstaendig).
    return bool(cfg.get("enabled") and cfg.get("always_on", False))


def _phone_device_for(token):
    if not token:
        return None
    h = hashlib.sha256(token.encode("utf-8")).hexdigest()
    for d in _phone_cfg().get("devices", []):
        if hmac.compare_digest(d.get("hash", ""), h):
            return d
    return None


@app.before_request
def _phone_gate():
    if request.method == "OPTIONS" and request.path.startswith("/phone/") and _phone_cfg().get("enabled"):
        return ("", 204)  # CORS-Preflight der Handy-App; die Header setzt _phone_cors
    if _is_local_request():
        return None
    p = request.path
    if not _phone_cfg().get("enabled"):
        return jsonify({"error": "Handy-Zugriff ist ausgeschaltet"}), 403
    if p in ("/phone", "/phone/manifest.json", "/phone/icon.svg", "/phone/pair") or p.startswith("/phone/icons/"):
        return None
    if p.startswith("/phone/api/"):
        dev = _phone_device_for(request.headers.get("X-Ari-Token", ""))
        if dev:
            if time.time() - dev.get("seen", 0) > 30:
                dev["seen"] = int(time.time())
                try:
                    _phone_save(_phone_cfg())
                except Exception:
                    pass
            return None
        return jsonify({"error": "nicht gekoppelt"}), 401
    return jsonify({"error": "verboten"}), 403

_DEFAULT_APP_URL = "https://kingshadow1332.github.io/app/"


def _app_url():
    """Adresse der Handy-App: Standard ist die GitHub-Pages-Adresse; wer das Feld im HUD leert, schaltet sie ab."""
    t = _phone_cfg().get("tunnel") or {}
    return (t["app_url"] if "app_url" in t else _DEFAULT_APP_URL).strip()



def _app_origin():
    """Adresse der eigenstaendigen Handy-App (z.B. https://name.github.io) - nur von dort
    sind Browser-Anfragen (CORS) an /phone/pair und /phone/api/* erlaubt."""
    u = _app_url()
    m = re.match(r"^(https://[A-Za-z0-9.-]+(?::\d+)?)(/|$)", u)
    return m.group(1) if m else None


@app.after_request
def _phone_cors(resp):
    org = request.headers.get("Origin")
    if org and request.path.startswith("/phone/") and org == _app_origin():
        resp.headers["Access-Control-Allow-Origin"] = org
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Ari-Token"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Max-Age"] = "600"
        resp.headers["Vary"] = "Origin"
    return resp


@app.route("/phone")
def phone_page():
    return send_from_directory(DASHBOARD_DIR, "phone.html")


@app.route("/qrcode.js")
def qrcode_js():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return send_from_directory(DASHBOARD_DIR, "qrcode.min.js", mimetype="text/javascript")


@app.route("/phone/icons/<path:filename>")
def phone_icons(filename):
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.png", filename):
        return jsonify({"error": "nicht gefunden"}), 404
    return send_from_directory(os.path.join(DASHBOARD_DIR, "app"), filename)


@app.route("/phone/manifest.json")
def phone_manifest():
    return jsonify({
        "name": "A.R.I", "short_name": "A.R.I", "start_url": "/phone", "display": "standalone",
        "background_color": "#050b14", "theme_color": "#050b14",
        "id": "/phone", "scope": "/phone", "lang": "de", "orientation": "portrait",
        "icons": [{"src": "/phone/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
                  {"src": "/phone/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
                  {"src": "/phone/icons/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
    })


@app.route("/phone/icon.svg")
def phone_icon():
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#050b14"/>'
           '<circle cx="50" cy="50" r="30" fill="none" stroke="#3fd9ff" stroke-width="5"/>'
           '<circle cx="50" cy="50" r="12" fill="#3fd9ff"/></svg>')
    return Response(svg, mimetype="image/svg+xml")


@app.route("/phone/pair", methods=["POST"])
def phone_pair():
    data = request.get_json(silent=True) or {}
    ip = _client_ip()
    fails, ts = _pair_ip_fails.get(ip, (0, 0))
    if fails >= 8 and time.time() - ts < 600:
        return jsonify({"error": "Zu viele Versuche - bitte in 10 Minuten erneut"}), 429
    code = str(data.get("code") or "").strip()
    short_ok = bool(_pair["code"]) and time.time() <= _pair["exp"] and hmac.compare_digest(code, _pair["code"])
    # Fernzugriffs-Code (steht im Link der Tunnel-Mail): gilt, solange der Hub laeuft, max. 5 Geraete
    remote_ok = bool(_remote["code"]) and _remote["uses"] < 5 and hmac.compare_digest(code, _remote["code"])
    if not short_ok and not remote_ok:
        _pair_ip_fails[ip] = (fails + 1, time.time())
        _pair["fails"] += 1
        if _pair["fails"] >= 5:
            _pair["code"] = None  # nach 5 Fehlversuchen ist der Code verbrannt
        return jsonify({"error": "Code falsch oder abgelaufen"}), 403
    if remote_ok and not short_ok:
        _remote["uses"] += 1
    token = _pysecrets.token_urlsafe(32)
    cfg = dict(_phone_cfg())
    devs = list(cfg.get("devices", []))
    name = re.sub(r"[^\w .\-]", "", str(data.get("name") or "Handy"))[:40] or "Handy"
    devs.append({"id": _pysecrets.token_hex(4), "name": name, "hash": hashlib.sha256(token.encode("utf-8")).hexdigest(),
                 "created": int(time.time()), "seen": int(time.time())})
    cfg["devices"] = devs
    _phone_save(cfg)
    if short_ok:
        _pair["code"] = None
    _pair_ip_fails.pop(ip, None)
    print(f"[phone] Neues Geraet gekoppelt: {name}")
    return jsonify({"token": token})


def _lan_urls():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return [f"http://{ip}:5000/phone" for ip in ips]


_STARTUP_LNK = (os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "A.R.I Hub.lnk")
                if IS_WIN else _lx.AUTOSTART_FILE)


def _set_autostart(enable):
    if not IS_WIN:
        return _lx.set_autostart(enable, os.path.join(DASHBOARD_DIR, "linux", "start-ari.sh"))
    if not enable:
        try:
            os.remove(_STARTUP_LNK)
        except OSError:
            pass
        return True
    named = os.path.join(sys.base_prefix, "Ari Assistent.exe")
    exe = named if os.path.exists(named) else os.path.join(sys.base_prefix, "pythonw.exe")
    if not os.path.exists(exe):
        exe = sys.executable
    hub = os.path.join(DASHBOARD_DIR, "hub.py")
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + _STARTUP_LNK + "');"
          "$s.TargetPath='" + exe + "';$s.Arguments='\"" + hub + "\" --background';"
          "$s.WorkingDirectory='" + DASHBOARD_DIR + "';$s.WindowStyle=7;$s.Save()")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=_NOWIN)
    return r.returncode == 0 and os.path.exists(_STARTUP_LNK)


def _app_qr_link(code):
    """QR-Ziel fuer die Handy-App: feste App-Adresse + aktuelle Tunnel-Adresse + Kurz-Code.
    Nur moeglich, wenn App-Adresse eingetragen ist und der Tunnel laeuft."""
    tcfg = _phone_cfg().get("tunnel") or {}
    app_url = _app_url()
    if not code or not _app_origin():
        return None
    target = _tunnel.get("url")
    if not target:
        # Ohne Tunnel: Adresse im Heim-WLAN (die App darf per http ins lokale Netz)
        lan = _lan_urls()
        target = lan[0].rsplit("/phone", 1)[0] if lan else None
    if not target:
        return None
    return app_url.rstrip("/") + "/#pc=" + urllib.parse.quote(target, safe="") + "&l=" + code


@app.route("/phone/admin/info", methods=["GET"])
def phone_admin_info():
    cfg = _phone_cfg()
    code_ok = bool(_pair["code"] and time.time() < _pair["exp"])
    return jsonify({
        "enabled": bool(cfg.get("enabled")), "always_on": bool(cfg.get("always_on", False)),
        "autostart": os.path.exists(_STARTUP_LNK), "urls": _lan_urls(),
        "devices": [{"id": d["id"], "name": d["name"], "seen": d.get("seen", 0)} for d in cfg.get("devices", [])],
        "code": _pair["code"] if code_ok else None, "code_left": int(_pair["exp"] - time.time()) if code_ok else 0,
        "qr_link": (_app_qr_link(_pair["code"]) if code_ok else None),
    })


@app.route("/phone/admin/config", methods=["POST"])
def phone_admin_config():
    data = request.get_json(silent=True) or {}
    cfg = dict(_phone_cfg())
    for k in ("enabled", "always_on"):
        if k in data:
            cfg[k] = bool(data[k])
    _phone_save(cfg)
    err = None
    if "autostart" in data:
        try:
            if not _set_autostart(bool(data["autostart"])):
                err = "Autostart konnte nicht eingerichtet werden."
        except Exception as e:
            err = "Autostart: " + str(e)
    return jsonify({"error": err})


@app.route("/phone/admin/pair-code", methods=["POST"])
def phone_admin_pair_code():
    cfg = dict(_phone_cfg())
    if not cfg.get("enabled"):
        cfg["enabled"] = True
        _phone_save(cfg)
    _pair.update(code=f"{_pysecrets.randbelow(1000000):06d}", exp=time.time() + 300, fails=0)
    return jsonify({"code": _pair["code"], "code_left": 300})


@app.route("/phone/admin/revoke", methods=["POST"])
def phone_admin_revoke():
    did = (request.get_json(silent=True) or {}).get("id")
    cfg = dict(_phone_cfg())
    cfg["devices"] = [d for d in cfg.get("devices", []) if d.get("id") != did]
    _phone_save(cfg)
    return jsonify({"error": None})


@app.route("/phone/admin/sync-settings", methods=["POST"])
def phone_admin_sync_settings():
    """Das HUD schickt Anbieter/Schluessel/Sprache, damit das Handy dieselbe KI
    nutzt, ohne Schluessel auf dem Handy eintippen zu muessen (bleiben auf dem PC)."""
    d = request.get_json(silent=True) or {}
    cfg = dict(_phone_cfg())
    cfg["settings"] = {
        "provider": d.get("provider") if d.get("provider") in _PROVIDER_CLIENTS else "anthropic",
        "api_key": str(d.get("api_key") or ""),
        "groq_api_keys": [str(k) for k in (d.get("groq_api_keys") or []) if k][:5],
        "language": str(d.get("language") or ""),
        "volume_target": d.get("volume_target") if d.get("volume_target") in ("windows", "spotify") else "windows",
        "economy": d.get("economy") is not False,
        "primary": d.get("primary") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d.get("primary") or "")) else None,
        "accent": d.get("accent") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d.get("accent") or "")) else None,
    }
    fb = d.get("fallback")
    if isinstance(fb, dict) and fb.get("provider") in _PROVIDER_CLIENTS:
        cfg["settings"]["fallback"] = {"provider": fb["provider"], "api_key": str(fb.get("api_key") or ""),
                                       "groq_api_keys": [str(k) for k in (fb.get("groq_api_keys") or []) if k][:5]}
    ak = _clean_keys(d.get("apiKeys"))
    if ak is not None:
        cfg["settings"]["all_keys"] = ak
    _phone_save(cfg)
    return jsonify({"error": None})


@app.route("/phone/api/chat", methods=["POST"])
def phone_api_chat():
    data = request.get_json(silent=True) or {}
    msgs = []
    for m in (data.get("messages") or [])[-20:]:
        if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str):
            msgs.append({"role": m["role"], "content": m["content"][:4000]})
    body = dict(_phone_cfg().get("settings") or {})
    body["messages"] = msgs
    return _chat_impl(body, remote=True)


@app.route("/phone/api/state")
def phone_api_state():
    out = {}
    try:
        out["status"] = _run_with_hard_timeout(_collect_status, timeout=STATUS_HARD_TIMEOUT_SECONDS, executor=_status_executor)
    except Exception as e:
        out["status"] = {"error": str(e)}
    try:
        track, err = _tool_spotify_current_track()
        out["track"] = track
        if not err:
            _music_feed(track)
        out["spotify_error"] = err
    except Exception:
        out["track"] = None
    s = dict(_phone_cfg().get("settings") or {})
    s.update(_hud_state["settings"])
    s.update(_hud_state["patch"])
    out["theme"] = {"primary": s.get("primary"), "accent": s.get("accent")}
    return jsonify(out)


_phone_data_cache = {"t": 0.0, "v": None}


@app.route("/phone/api/data")
def phone_api_data():
    """Schwerere Daten (Kalender, Gehirn, Mails) - 45 s zwischengespeichert, damit
    haeufiges Abfragen vom Handy keine Google-/IMAP-Aufrufe auslost."""
    if _phone_data_cache["v"] is not None and time.time() - _phone_data_cache["t"] < 45 and not request.args.get("fresh"):
        return jsonify(_phone_data_cache["v"])
    out = {}
    try:
        events, err = get_upcoming_events(days=30, max_results=40)
        out["events"], out["events_error"] = events or [], err
    except Exception as e:
        out["events"], out["events_error"] = [], str(e)
    nodes = [n for n in _brain_load() if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    out["brain"] = [{"text": n["text"], "cat": n.get("cat", "Wissen")} for n in nodes][-400:]
    try:
        mails, err = get_recent_emails(unread_only=True, max_results=8)
        mails = [m for m in (mails or []) if not _is_spam_sender(m.get("from_name") or m.get("from", ""))]
        out["mails"] = [{"id": m.get("id", ""), "from": m.get("from_name") or m.get("from", ""), "subject": m.get("subject", "")} for m in mails]
        out["mails_error"] = err
    except Exception as e:
        out["mails"], out["mails_error"] = [], str(e)
    _phone_data_cache.update(t=time.time(), v=out)
    return jsonify(out)


@app.route("/phone/api/spam", methods=["POST"])
def phone_api_spam():
    """Vom Handy aus einen Absender als Spam markieren - gleiche Wirkung wie am PC:
    taucht danach bei beiden nicht mehr in den Benachrichtigungen auf."""
    data = request.get_json(silent=True) or {}
    frm = (data.get("from") or "").strip()
    if not frm:
        return jsonify({"error": "Kein Absender angegeben."}), 400
    _add_spam_sender(frm)
    email_id = (data.get("id") or "").strip()
    if email_id:
        mark_email_read(email_id)
    _phone_data_cache["v"] = None
    return jsonify({"error": None})


@app.route("/phone/api/control", methods=["POST"])
def phone_api_control():
    body = request.get_json(silent=True) or {}
    a = str(body.get("action") or "")
    if a in ("up", "down", "mute", "play_pause", "next", "previous", "seek"):
        msg = _media_control(a, body.get("ms"))
    elif a == "lock":
        if IS_WIN:
            ctypes.windll.user32.LockWorkStation()
            msg = "PC gesperrt."
        else:
            msg = "PC gesperrt." if _lx.lock_screen() else "Sperren nicht moeglich (loginctl/xdg-screensaver fehlt)."
    elif a == "quit":
        threading.Timer(0.6, _hub_exit, args=("per Handy beendet",)).start()
        msg = "A.R.I wird beendet."
    else:
        return jsonify({"error": "Unbekannte Aktion"}), 400
    return jsonify({"message": msg})


# --- Schnelle Bildschirmaufnahme (GDI, direkt auf Zielgroesse verkleinert) ---
# ImageGrab liest immer den vollen Bildschirm in Python-Speicher (~50 ms bei 3440x1440).
# StretchBlt verkleinert schon in GDI; zusammen mit parallelen Aufnahmen (siehe
# phone_api_stream) sind so 30-50 Bilder/s moeglich.
if IS_WIN:
    _gdi_user32 = ctypes.WinDLL("user32", use_last_error=True)
    _gdi_gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    _gdi_user32.GetDC.restype = ctypes.c_void_p
    _gdi_user32.GetDC.argtypes = [ctypes.c_void_p]
    _gdi_user32.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _gdi_gdi32.CreateCompatibleDC.restype = ctypes.c_void_p
    _gdi_gdi32.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.CreateCompatibleBitmap.restype = ctypes.c_void_p
    _gdi_gdi32.CreateCompatibleBitmap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    _gdi_gdi32.SelectObject.restype = ctypes.c_void_p
    _gdi_gdi32.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _gdi_gdi32.DeleteObject.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.SetStretchBltMode.argtypes = [ctypes.c_void_p, ctypes.c_int]
    _gdi_gdi32.StretchBlt.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint32]
    _gdi_gdi32.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]


class _BmiHeader(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32), ("biHeight", ctypes.c_int32),
                ("biPlanes", ctypes.c_uint16), ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
                ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32), ("biYPelsPerMeter", ctypes.c_int32),
                ("biClrUsed", ctypes.c_uint32), ("biClrImportant", ctypes.c_uint32)]


def _gdi_grab(target_w, smooth=True):
    """Hauptbildschirm direkt auf target_w Pixel Breite verkleinert -> (PIL-Bild, Bildschirmbreite, -hoehe)."""
    from PIL import Image
    sw, sh = _gdi_user32.GetSystemMetrics(0), _gdi_user32.GetSystemMetrics(1)
    tw = min(int(target_w), sw)
    th = max(1, round(sh * tw / sw))
    hdc = _gdi_user32.GetDC(None)
    mdc = _gdi_gdi32.CreateCompatibleDC(hdc)
    bmp = _gdi_gdi32.CreateCompatibleBitmap(hdc, tw, th)
    old = _gdi_gdi32.SelectObject(mdc, bmp)
    try:
        _gdi_gdi32.SetStretchBltMode(mdc, 4 if smooth else 3)  # HALFTONE (schoener) / COLORONCOLOR (schneller)
        _gdi_gdi32.StretchBlt(mdc, 0, 0, tw, th, hdc, 0, 0, sw, sh, 0x00CC0020)
        bmi = _BmiHeader(40, tw, -th, 1, 32, 0, 0, 0, 0, 0, 0)
        buf = ctypes.create_string_buffer(tw * th * 4)
        _gdi_gdi32.GetDIBits(mdc, bmp, 0, th, buf, ctypes.byref(bmi), 0)
        return Image.frombuffer("RGB", (tw, th), buf, "raw", "BGRX", 0, 1).copy(), sw, sh
    finally:
        _gdi_gdi32.SelectObject(mdc, old)
        _gdi_gdi32.DeleteObject(bmp)
        _gdi_gdi32.DeleteDC(mdc)
        _gdi_user32.ReleaseDC(None, hdc)


def _grab_frame_jpeg(w, quality, cursor=True, smooth=True):
    from PIL import ImageDraw
    import io
    try:
        img, sw, sh = _gdi_grab(w, smooth) if IS_WIN else _lx.grab_screen(w, smooth)
    except Exception:
        from PIL import ImageGrab
        img = ImageGrab.grab().convert("RGB")
        sw, sh = img.size
        if img.width > w:
            img = img.resize((w, max(1, round(img.height * w / img.width))))
    if cursor:
        try:
            if IS_WIN:
                pt = _Point()
                ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                px, py = pt.x, pt.y
            else:
                px, py = _lx.cursor_pos()
            k = img.width / float(sw)
            cx, cy = px * k, py * k
            d = ImageDraw.Draw(img)
            r = max(5, img.width // 120)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=(255, 45, 120), width=max(2, r // 3))
            d.ellipse((cx - 2, cy - 2, cx + 2, cy + 2), fill=(255, 255, 255))
        except Exception:
            pass
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def _screen_params():
    def num(name, default, lo, hi):
        try:
            return max(lo, min(hi, int(request.args.get(name, default))))
        except ValueError:
            return default
    return num("w", 900, 300, 1920), num("q", 55, 25, 90), request.args.get("cursor", "1") != "0"


@app.route("/phone/api/screen")
def phone_api_screen():
    w, q, cur = _screen_params()
    resp = Response(_grab_frame_jpeg(w, q, cur), mimetype="image/jpeg")
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/phone/api/stream")
def phone_api_stream():
    """Live-Video: Motion-JPEG (Einzelbilder als Endlos-Strom). Bilder, die sich nicht
    aendern, werden nicht erneut gesendet (spart Daten). Endet, wenn das Handy trennt."""
    w, q, cur = _screen_params()
    try:
        fps = max(1, min(60, int(request.args.get("fps", 12))))
    except ValueError:
        fps = 12

    def gen():
        # Mehrere Aufnahmen laufen parallel (GDI-Auslesen wartet zum Teil auf die Grafikkarte) -
        # so werden hohe Bildraten moeglich. Bilder kommen in richtiger Reihenfolge an.
        depth = 1 if fps <= 15 else 2 if fps <= 30 else 3
        smooth = fps <= 15
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=depth)
        pending = collections.deque()
        interval = 1.0 / fps
        slot = time.time()
        last = None
        idle_since = time.time()
        try:
            while True:
                now = time.time()
                if slot > now:
                    time.sleep(slot - now)
                slot = max(slot + interval, time.time() - interval)
                pending.append(ex.submit(_grab_frame_jpeg, w, q, cur, smooth))
                if len(pending) >= depth:
                    data = pending.popleft().result()
                    if data != last or time.time() - idle_since > 4:
                        last = data
                        idle_since = time.time()
                        yield (b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(data)).encode() + b"\r\n\r\n" + data + b"\r\n")
        except GeneratorExit:
            return
        finally:
            ex.shutdown(wait=False)

    resp = Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Accel-Buffering"] = "no"
    return resp


_MOUSEEVENTF_RIGHTDOWN = 0x0008
_MOUSEEVENTF_RIGHTUP = 0x0010
_MOUSEEVENTF_WHEEL = 0x0800


def _mouse_send(fx, fy, flags, data=0):
    if not IS_WIN:
        return   # Linux: phone_api_click nutzt _lx.mouse_action direkt
    extra = ctypes.c_ulong(0)
    ax = max(0, min(65535, int(fx * 65535)))
    ay = max(0, min(65535, int(fy * 65535)))
    evt = _Input(_INPUT_MOUSE, _InputUnion(mi=_MouseInput(ax, ay, data & 0xFFFFFFFF, flags, 0, ctypes.pointer(extra))))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))


@app.route("/phone/api/click", methods=["POST"])
def phone_api_click():
    d = request.get_json(silent=True) or {}
    try:
        fx = max(0.0, min(1.0, float(d.get("x"))))
        fy = max(0.0, min(1.0, float(d.get("y"))))
    except (TypeError, ValueError):
        return jsonify({"error": "x/y fehlen"}), 400
    if not IS_WIN:
        ok = _lx.mouse_action(fx, fy, str(d.get("kind") or "left"), int(d.get("amount", 3) or 0))
        return jsonify({"ok": bool(ok)}) if ok else (jsonify({"error": "Maussteuerung nicht moeglich (xdotool und X11-Sitzung noetig)."}), 500)
    _mouse_send(fx, fy, _MOUSEEVENTF_MOVE | _MOUSEEVENTF_ABSOLUTE)
    kind = d.get("kind")
    if kind == "scroll":
        delta = -120 * max(-10, min(10, int(d.get("amount", 3))))
        _mouse_send(fx, fy, _MOUSEEVENTF_WHEEL | _MOUSEEVENTF_ABSOLUTE, delta)
    elif kind == "move":
        pass
    else:
        down, up = (_MOUSEEVENTF_RIGHTDOWN, _MOUSEEVENTF_RIGHTUP) if kind == "right" else (_MOUSEEVENTF_LEFTDOWN, _MOUSEEVENTF_LEFTUP)
        for _ in range(2 if kind == "double" else 1):
            _mouse_send(fx, fy, down | _MOUSEEVENTF_ABSOLUTE)
            _mouse_send(fx, fy, up | _MOUSEEVENTF_ABSOLUTE)
            time.sleep(0.06)
    return jsonify({"ok": True})


@app.route("/phone/api/type", methods=["POST"])
def phone_api_type():
    d = request.get_json(silent=True) or {}
    if d.get("text"):
        _type_text(str(d["text"])[:500])
    if d.get("key"):
        if not _press_key_combo(str(d["key"])[:40]):
            return jsonify({"error": "Unbekannte Taste"}), 400
    return jsonify({"ok": True})


# --- Einstellungen PC <-> Handy ---------------------------------------------
# Das HUD schickt seine (nicht geheimen) Einstellungen als Momentaufnahme an den Hub;
# Aenderungen vom Handy landen als "Patch" in einer Warteschlange, die das HUD abholt
# und anwendet (auch wenn das HUD erst spaeter geoeffnet wird).
_HUD_KEYS = {
    "language": lambda v: isinstance(v, str) and len(v) <= 8,
    "volumeTarget": lambda v: v in ("windows", "spotify"),
    "volume": lambda v: isinstance(v, (int, float)) and 0 <= v <= 1,
    "rate": lambda v: isinstance(v, (int, float)) and 0.5 <= v <= 2,
    "pitch": lambda v: isinstance(v, (int, float)) and 0 <= v <= 2,
    "primary": lambda v: isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v) is not None,
    "accent": lambda v: isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v) is not None,
    "pollInterval": lambda v: v in (2000, 3000, 5000, 10000, 15000),
    "notifAutoRefresh": lambda v: isinstance(v, bool),
    "notifShowRefreshBtn": lambda v: isinstance(v, bool),
    "remindEnabled": lambda v: isinstance(v, bool),
    "remindLeads": lambda v: isinstance(v, list) and all(x in (1440, 60, 30, 15, 10, 5) for x in v),
    "performanceMode": lambda v: isinstance(v, bool),
    "economy": lambda v: isinstance(v, bool),
    "provider": lambda v: v in _PROVIDER_CLIENTS,
    "hiddenPanels": lambda v: isinstance(v, list) and all(isinstance(x, str) and len(x) < 30 for x in v),
}
_hud_state = {"settings": {}, "tiles": [], "patch": {}}


def _hud_clean(d):
    return {k: v for k, v in (d or {}).items() if k in _HUD_KEYS and _HUD_KEYS[k](v)}


@app.route("/phone/admin/hud-snapshot", methods=["POST"])
def phone_admin_hud_snapshot():
    d = request.get_json(silent=True) or {}
    _hud_state["settings"] = _hud_clean(d.get("settings"))
    tiles = d.get("tiles")
    if isinstance(tiles, list):
        _hud_state["tiles"] = [{"pid": str(t.get("pid"))[:30], "title": str(t.get("title"))[:40]} for t in tiles if isinstance(t, dict)][:30]
    # Aenderungen, die das HUD schon kennt, aus dem Patch streichen
    _hud_state["patch"] = {k: v for k, v in _hud_state["patch"].items() if _hud_state["settings"].get(k) != v}
    return jsonify({"error": None})


@app.route("/phone/admin/hud-patch", methods=["GET"])
def phone_admin_hud_patch():
    patch = _hud_state["patch"]
    keys = _hud_keys_pending["v"]
    _hud_keys_pending["v"] = None
    return jsonify({"patch": dict(patch), "apiKeys": keys})


_hud_keys_pending = {"v": None}


def _clean_keys(ak):
    if not isinstance(ak, dict):
        return None
    out = {}
    for p in ("anthropic", "openai", "gemini"):
        if p in ak:
            out[p] = str(ak.get(p) or "").strip()[:300]
    if "groq" in ak:
        g = ak.get("groq")
        g = g if isinstance(g, list) else [g]
        out["groq"] = [str(k).strip()[:300] for k in g if k][:5]
    return out


@app.route("/phone/api/sync", methods=["GET", "POST"])
def phone_api_sync():
    """Vollstaendiger Abgleich mit der Handy-App: Gehirn (in beide Richtungen, inkl. Loeschungen),
    Einstellungen und API-Schluessel. Wird nur mit gueltigem Geraete-Token erreicht."""
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        deleted = {str(t).strip().lower() for t in (d.get("deleted") or [])[:500] if str(t).strip()}
        if deleted:
            with _brain_lock:
                nodes = [n for n in _brain_load() if n["text"].strip().lower() not in deleted]
                _brain_save(nodes)
        for n in (d.get("brain") or [])[:600]:
            if isinstance(n, dict) and str(n.get("text") or "").strip().lower() not in deleted and not str(n.get("text") or "").startswith(_MUSIC_PREFIXES):
                _brain_add(str(n.get("text") or ""), str(n.get("cat") or "")[:30] or None)
        _hud_state["patch"].update(_hud_clean(d.get("settings")))
        ak = _clean_keys(d.get("apiKeys"))
        if ak:
            cfg = dict(_phone_cfg())
            st = dict(cfg.get("settings") or {})
            keys = dict(st.get("all_keys") or {})
            keys.update(ak)
            st["all_keys"] = keys
            prov = _hud_state["patch"].get("provider") or _hud_state["settings"].get("provider") or st.get("provider") or "anthropic"
            st["provider"] = prov
            st["api_key"] = "" if prov == "groq" else str(keys.get(prov) or "")
            st["groq_api_keys"] = list(keys.get("groq") or [])
            cfg["settings"] = st
            _phone_save(cfg)
            _hud_keys_pending["v"] = keys
    merged = dict(_hud_state["settings"])
    merged.update(_hud_state["patch"])
    nodes = [n for n in _brain_load() if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    return jsonify({
        "brain": [{"text": n["text"], "cat": n.get("cat", "Wissen")} for n in nodes],
        "settings": merged,
        "apiKeys": dict((_phone_cfg().get("settings") or {}).get("all_keys") or {}),
        "hud_seen": bool(_hud_state["settings"]),
        "time": int(time.time()),
    })


@app.route("/phone/api/settings", methods=["GET", "POST"])
def phone_api_settings():
    if request.method == "POST":
        patch = _hud_clean((request.get_json(silent=True) or {}).get("patch"))
        _hud_state["patch"].update(patch)
    merged = dict(_hud_state["settings"])
    merged.update(_hud_state["patch"])
    return jsonify({"settings": merged, "tiles": _hud_state["tiles"], "hud_seen": bool(_hud_state["settings"])})


# --- Fernzugriff ueber Cloudflare-Tunnel ------------------------------------
# Der Tunnel laeuft am PC (cloudflared) und verbindet den Hub AUSGEHEND mit Cloudflare -
# am Router wird nichts freigegeben. Das Handy oeffnet nur eine https-Adresse
# (https://<zufall>.trycloudflare.com/phone). Die Adresse aendert sich bei jedem Start,
# deshalb schickt der Hub den Link (inkl. Kopplungs-Code) auf Wunsch per Mail.
_TUNNEL_EXE = os.path.join(DATA_DIR, "cloudflared.exe" if IS_WIN else "cloudflared")
if not IS_WIN and not os.path.exists(_TUNNEL_EXE) and shutil.which("cloudflared"):
    _TUNNEL_EXE = shutil.which("cloudflared")   # bereits per Paketmanager installiert - kein Download noetig
_TUNNEL_PID = os.path.join(DATA_DIR, "tunnel.pid")
_TUNNEL_DOWNLOAD = ("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
                    if IS_WIN else _lx.tunnel_download_url())
_tunnel = {"proc": None, "url": None, "state": "aus", "error": None}


def _verify_signature(path, must_contain):
    """Prueft die digitale Signatur (Windows Authenticode) einer heruntergeladenen Datei.
    Linux: keine Authenticode-Signatur - stattdessen Plausibilitaetspruefung (Groesse, meldet sich als cloudflared)."""
    if not IS_WIN:
        return _lx.verify_cloudflared(path)
    ps = ("$s=Get-AuthenticodeSignature -LiteralPath '" + path.replace("'", "''") + "';"
          "if($s.Status -eq 'Valid' -and $s.SignerCertificate.Subject -like '*" + must_contain + "*'){'OK'}else{'BAD ' + $s.Status}")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, creationflags=_NOWIN, timeout=60)
    return r.stdout.strip() == "OK"


def _tunnel_install():
    if os.path.exists(_TUNNEL_EXE):
        return
    _tunnel.update(state="lädt herunter", error=None)
    os.makedirs(DATA_DIR, exist_ok=True)
    part = _TUNNEL_EXE + ".part"
    try:
        req = urllib.request.Request(_TUNNEL_DOWNLOAD, headers={"User-Agent": "A.R.I"})
        with urllib.request.urlopen(req, timeout=120) as r, open(part, "wb") as f:
            shutil.copyfileobj(r, f)
        if os.path.getsize(part) < 5_000_000 or not _verify_signature(part, "Cloudflare"):
            raise RuntimeError("Download unvollständig oder Signatur von Cloudflare nicht gültig - Datei verworfen.")
        os.replace(part, _TUNNEL_EXE)
        _tunnel.update(state="aus")
    except Exception as e:
        try:
            os.remove(part)
        except OSError:
            pass
        _tunnel.update(state="Fehler", error=str(e))


def _tunnel_kill_stale():
    try:
        with open(_TUNNEL_PID) as f:
            pid = int(f.read().strip())
        p = psutil.Process(pid)
        if "cloudflared" in p.name().lower():
            p.kill()
    except Exception:
        pass
    try:
        os.remove(_TUNNEL_PID)
    except OSError:
        pass


def _tunnel_stop():
    p = _tunnel.get("proc")
    if p is not None:
        try:
            p.kill()
        except Exception:
            pass
    _tunnel.update(proc=None, url=None, state="aus")
    _remote["code"] = None
    try:
        os.remove(_TUNNEL_PID)
    except OSError:
        pass


def _tunnel_link():
    if not _tunnel.get("url") or not _remote.get("code"):
        return None
    # Mit hinterlegter App-Adresse zeigt der Link auf die Handy-App (feste Adresse) und gibt ihr
    # die aktuelle Tunnel-Adresse + Code mit - so verbindet und synchronisiert sie sich mit einem Tipp.
    app_url = _app_url()
    if _app_origin():
        return app_url.rstrip("/") + "/#pc=" + urllib.parse.quote(_tunnel["url"], safe="") + "&l=" + _remote["code"]
    return _tunnel["url"] + "/phone#l=" + _remote["code"]

def _tunnel_mail_to():
    """Empfaenger des Fernzugriffs-Links: die im HUD eingetragene Adresse, sonst automatisch das verbundene Yahoo-Konto."""
    t = (_phone_cfg().get("tunnel") or {}).get("mail_to") or ""
    return t.strip() or ((_yahoo_creds() or {}).get("email") or "").strip()



def _tunnel_mail_link():
    cfg = _phone_cfg().get("tunnel") or {}
    to = _tunnel_mail_to()
    link = _tunnel_link()
    if not to or not link:
        return "Keine Empfänger-Adresse oder kein Link."
    err = send_new_email(to, "A.R.I Fernzugriff", "Dein A.R.I ist unterwegs erreichbar. Diesen Link am Handy öffnen (gilt, bis A.R.I am PC beendet wird):\n\n" + link + "\n\nDen Link niemandem weitergeben.")
    return err


def _tunnel_start():
    if _tunnel.get("proc") is not None and _tunnel["proc"].poll() is None:
        return
    if not os.path.exists(_TUNNEL_EXE):
        _tunnel.update(state="Fehler", error="cloudflared ist noch nicht installiert.")
        return
    _tunnel_kill_stale()
    _tunnel.update(state="startet", error=None, url=None)
    try:
        proc = subprocess.Popen([_TUNNEL_EXE, "tunnel", "--url", "http://127.0.0.1:5000", "--no-autoupdate"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, creationflags=_NOWIN)
    except Exception as e:
        _tunnel.update(state="Fehler", error=str(e))
        return
    _tunnel["proc"] = proc
    with open(_TUNNEL_PID, "w") as f:
        f.write(str(proc.pid))

    def reader():
        for line in proc.stderr:
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
            if m and not _tunnel.get("url"):
                _tunnel["url"] = m.group(0)
                _remote.update(code=_pysecrets.token_urlsafe(9), uses=0)
                _tunnel["state"] = "läuft"
                print("[tunnel] Fernzugriff aktiv")
                if _tunnel_mail_to():
                    try:
                        err = _tunnel_mail_link()
                        print("[tunnel] Link per Mail gesendet" if not err else f"[tunnel] Mail: {err}")
                    except Exception as e:
                        print("[tunnel] Mail fehlgeschlagen:", e)
        _tunnel.update(state="aus" if _tunnel.get("state") != "Fehler" else "Fehler", url=None)
        _remote["code"] = None

    threading.Thread(target=reader, daemon=True).start()


@app.route("/phone/admin/tunnel", methods=["GET", "POST"])
def phone_admin_tunnel():
    cfg = dict(_phone_cfg())
    tcfg = dict(cfg.get("tunnel") or {})
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        act = d.get("action")
        if "app_url" in d:
            au = str(d.get("app_url") or "").strip()
            tcfg["app_url"] = au if re.match(r"^https://[A-Za-z0-9.-]+(:\d+)?(/[\w./-]*)?$", au) else ""
        if "mail_to" in d:
            m = str(d.get("mail_to") or "").strip()
            tcfg["mail_to"] = m if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", m) else ""
        if "enabled" in d:
            tcfg["enabled"] = bool(d["enabled"])
        cfg["tunnel"] = tcfg
        _phone_save(cfg)
        if act == "install":
            threading.Thread(target=_tunnel_install, daemon=True).start()
        elif act == "start" or (d.get("enabled") is True and os.path.exists(_TUNNEL_EXE)):
            if not (_phone_cfg().get("enabled")):
                c2 = dict(_phone_cfg()); c2["enabled"] = True; _phone_save(c2)
            threading.Thread(target=_tunnel_start, daemon=True).start()
        elif act == "stop" or d.get("enabled") is False:
            _tunnel_stop()
        elif act == "mail":
            return jsonify({"error": _tunnel_mail_link()})
    running = _tunnel.get("proc") is not None and _tunnel["proc"].poll() is None
    return jsonify({
        "installed": os.path.exists(_TUNNEL_EXE), "running": running, "state": _tunnel.get("state"), "error": _tunnel.get("error"),
        "enabled": bool(tcfg.get("enabled")), "mail_to": _tunnel_mail_to(),
        "url": _tunnel.get("url"), "link": _tunnel_link(),
        "yahoo_mail": (_yahoo_creds() or {}).get("email", ""), "app_url": _app_url(),
    })


# --- Selbst beenden -------------------------------------------------------
# Das HUD schickt alle ~10 s einen Herzschlag (/heartbeat, ausserdem zaehlt
# /status). Kommt 20 Sekunden lang keiner (Browser/Tab zu), beendet sich der Hub.
IDLE_SHUTDOWN_SECONDS = 20
_hub_last_seen = time.time()


# Schliesst man das letzte HUD-Fenster/den Tab (X im Browser), meldet die Seite
# "closing". Der Hub wartet kurz (CLOSE_GRACE_SECONDS) - kommt in der Zeit ein
# Herzschlag (z.B. nach F5/Neuladen), bleibt er an, sonst beendet er sich.
CLOSE_GRACE_SECONDS = 20
_hub_close_deadline = None


@app.before_request
def _note_hud_activity():
    global _hub_last_seen, _hub_close_deadline
    if request.path in ("/heartbeat", "/status"):
        _hub_last_seen = time.time()
        _hub_close_deadline = None


@app.route("/closing", methods=["POST"])
def closing():
    global _hub_close_deadline
    if not request.is_json:
        return jsonify({"ok": False}), 400
    _hub_close_deadline = time.time() + CLOSE_GRACE_SECONDS
    return jsonify({"ok": True})


@app.route("/heartbeat", methods=["POST"])
def heartbeat():
    return jsonify({"ok": True})


def _hub_exit(reason):
    print(f"[hub] Beende A.R.I: {reason}")
    try:
        _tunnel_stop()
    except Exception:
        pass
    try:
        _dev_console_hide()
    except Exception:
        pass
    try:
        os.remove(os.path.join(DATA_DIR, "hub.pid"))
    except OSError:
        pass
    os._exit(0)


def _idle_watchdog():
    global _hub_last_seen, _hub_close_deadline
    last_tick = time.time()
    while True:
        time.sleep(1)
        now = time.time()
        if _hub_close_deadline is not None and now >= _hub_close_deadline:
            _hub_exit("HUD-Fenster wurde geschlossen")
        if now - last_tick > 30:
            # Rechner war im Ruhezustand: Wartezeit neu starten, sonst wuerde der
            # Hub direkt nach dem Aufwachen beendet, obwohl das HUD noch offen ist.
            _hub_last_seen = now
        last_tick = now
        if _phone_keep_alive():
            # Handy gekoppelt + Dauerbetrieb: der Hub bleibt an, auch ohne HUD-Fenster.
            _hub_last_seen = now
            _hub_close_deadline = None
        # Auch bei offener Dev-Konsole: ohne HUD-Fenster beendet sich der Hub nach
        # IDLE_SHUTDOWN_SECONDS (die Konsole geht dabei mit zu).
        if now - _hub_last_seen > IDLE_SHUTDOWN_SECONDS:
            _hub_exit(f"kein HUD-Fenster seit {IDLE_SHUTDOWN_SECONDS} Sekunden")


@app.route("/shutdown", methods=["POST"])
def shutdown():
    """Beenden-Button in den Einstellungen. Nur mit JSON-Body (loest bei
    fremden Webseiten einen CORS-Preflight aus und wird dadurch blockiert)."""
    if not request.is_json:
        return jsonify({"ok": False}), 400
    threading.Timer(0.6, _hub_exit, args=("per Beenden-Button",)).start()
    return jsonify({"ok": True})


_dev_console_proc = None


def _dev_console_hide():
    global _dev_console_proc
    proc, _dev_console_proc = _dev_console_proc, None
    if proc is not None and proc.poll() is None:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
        else:
            try:
                proc.terminate()
            except OSError:
                pass


@app.route("/dev/console", methods=["POST"])
def dev_console():
    """Konsolen-Fenster (Live-Log des Hubs) ein-/ausblenden. Einblenden nur mit
    Dev-Passwort; Ausblenden darf jeder (schliesst nur das Log-Fenster)."""
    global _dev_console_proc
    data = request.get_json(silent=True) or {}
    if not data.get("show"):
        _dev_console_hide()
        return jsonify({"ok": True, "visible": False})
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    if not _HEADLESS:
        return jsonify({"ok": True, "visible": True, "note": "Hub laeuft schon in einem sichtbaren Fenster."})
    if not IS_WIN:
        if _dev_console_proc is None or _dev_console_proc.poll() is not None:
            _dev_console_proc = _lx.open_log_terminal(HUB_LOG_FILE)
        return jsonify({"ok": True, "visible": _dev_console_proc is not None})
    if _dev_console_proc is None or _dev_console_proc.poll() is not None:
        path = HUB_LOG_FILE.replace("'", "''")
        cmd = ("$Host.UI.RawUI.WindowTitle='A.R.I Hub Konsole'; "
               "Get-Content -Wait -Tail 80 -Encoding UTF8 -LiteralPath '" + path + "'")
        _dev_console_proc = subprocess.Popen(
            ["powershell", "-NoLogo", "-NoExit", "-Command", cmd],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
        )
    return jsonify({"ok": True, "visible": True})


@app.route("/dev/info", methods=["POST"])
def dev_info():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    proc = psutil.Process(os.getpid())
    hub_uptime_s = int(time.time() - _HUB_START_TIME)
    try:
        screenshot_count = len([f for f in os.listdir(SCREENSHOT_DIR) if f.endswith(".png")]) if os.path.isdir(SCREENSHOT_DIR) else 0
    except OSError:
        screenshot_count = 0
    return jsonify({
        "ok": True,
        "data": {
            "python_version": sys.version.split()[0],
            "platform": sys.platform,
            "pid": os.getpid(),
            "hub_uptime_s": hub_uptime_s,
            "hub_ram_mb": round(proc.memory_info().rss / 1024 ** 2, 1),
            "dashboard_dir": DASHBOARD_DIR,
            "judged_email_ids_count": len(_judged_email_ids),
            "screenshot_count": screenshot_count,
            "piper_available": os.path.isfile(PIPER_EXE),
            "secrets_connected": sorted(_load_secrets().keys()),
        },
    })


@app.route("/dev/clear-seen-emails", methods=["POST"])
def dev_clear_seen_emails():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    _judged_email_ids.clear()
    _save_seen_email_ids(_judged_email_ids)
    return jsonify({"ok": True})


@app.route("/dev/clear-screenshots", methods=["POST"])
def dev_clear_screenshots():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    removed = 0
    try:
        for f in os.listdir(SCREENSHOT_DIR):
            if f.endswith(".png"):
                os.remove(os.path.join(SCREENSHOT_DIR, f))
                removed += 1
    except OSError:
        pass
    return jsonify({"ok": True, "removed": removed})


@app.route("/speak", methods=["POST"])
def speak():
    """Spricht Text lokal per Piper TTS (kein Internet, keine Kosten) und
    gibt die erzeugte WAV-Datei zurueck. Das Frontend faellt bei jedem Fehler
    hier auf window.speechSynthesis zurueck, damit A.R.I nie stumm bleibt."""
    data = request.get_json(silent=True) or {}
    text = data.get("text")
    text = EMOJI_RE.sub("", text).strip() if isinstance(text, str) else ""
    voice = data.get("voice") if isinstance(data.get("voice"), str) else "thorsten"
    if not text:
        return jsonify({"error": "Kein Text zum Sprechen angegeben."}), 400
    if voice.startswith("edge:"):
        voice_id = _EDGE_VOICE_IDS.get(voice)
        if voice_id is None:
            return jsonify({"error": f"Unbekannte Edge-Stimme '{voice}'."}), 400
        try:
            audio_bytes = _edge_tts_synthesize(text, voice_id)
        except Exception as e:
            return jsonify({"error": f"Edge-Stimme fehlgeschlagen (Internet vorhanden?): {e}"}), 500
        if not audio_bytes:
            return jsonify({"error": "Edge-Stimme hat kein Audio geliefert (Internet vorhanden?)."}), 500
        return Response(audio_bytes, mimetype="audio/mpeg")
    model_name = PIPER_VOICE_MODELS.get(voice)
    if model_name is None:
        return jsonify({"error": f"Unbekannte Piper-Stimme '{voice}'."}), 400
    if not os.path.isfile(PIPER_EXE):
        return jsonify({"error": f"Piper-Binary nicht gefunden unter '{PIPER_EXE}'. piper.exe (+ DLLs) aus den GitHub-Releases in den Ordner 'piper/' legen."}), 500
    model_path = os.path.join(PIPER_VOICES_DIR, model_name)
    config_path = model_path + ".json"
    if not os.path.isfile(model_path) or not os.path.isfile(config_path):
        return jsonify({"error": f"Stimmmodell '{voice}' nicht gefunden in '{PIPER_VOICES_DIR}'. .onnx + .onnx.json dort ablegen."}), 500

    wav_path = os.path.join(tempfile.gettempdir(), f"ari_speak_{uuid.uuid4().hex}.wav")
    try:
        result = subprocess.run(
            [PIPER_EXE, "--model", model_path, "--config", config_path, "--output_file", wav_path],
            input=text.encode("utf-8"),
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0 or not os.path.isfile(wav_path):
            err = result.stderr.decode("utf-8", errors="ignore").strip()
            return jsonify({"error": f"Piper-Aufruf fehlgeschlagen: {err[:300] or 'unbekannter Fehler'}"}), 500
        with open(wav_path, "rb") as f:
            audio_bytes = f.read()
        return Response(audio_bytes, mimetype="audio/wav")
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Piper hat zu lange gebraucht (Timeout)."}), 500
    except OSError as e:
        return jsonify({"error": f"Piper konnte nicht gestartet werden: {e}"}), 500
    finally:
        try:
            os.remove(wav_path)
        except OSError:
            pass


def _collect_status():
    cpu_percent = psutil.cpu_percent(interval=0.2)
    freq = psutil.cpu_freq()
    vm = psutil.virtual_memory()
    down_mbps, up_mbps = get_network_rates()

    return {
        "cpu_percent": round(cpu_percent, 1),
        "ram_percent": round(vm.percent, 1),
        "net_down_mbps": down_mbps,
        "net_up_mbps": up_mbps,
        "cpu_freq_ghz": round(freq.current / 1000, 2) if freq else None,
        "ram_used_gb": round(vm.used / 1024 ** 3, 1),
        "ram_total_gb": round(vm.total / 1024 ** 3, 1),
        "uptime_str": format_uptime(),
        "system_status": get_system_status_label(cpu_percent, vm.percent),
        "processes": get_cached_processes(),
        "mem_breakdown": estimate_memory_breakdown(),
        "active_game_mode": get_active_game_mode()[1],
    }


@app.route("/status")
def status():
    try:
        payload = _run_with_hard_timeout(_collect_status, timeout=STATUS_HARD_TIMEOUT_SECONDS, executor=_status_executor)
    except TimeoutError as e:
        # 503 statt endlos haengen: das Frontend behandelt einen fehlge-
        # schlagenen Poll ohnehin schon als "kurz nicht verbunden" und
        # versucht es beim naechsten Intervall automatisch wieder.
        return jsonify({"error": str(e)}), 503
    return jsonify(payload)


@app.route("/groq-status", methods=["GET", "POST"])
def groq_status():
    """Fuer den Countdown-Hinweis im Frontend, unabhaengig vom Chat abrufbar:
    sind gerade ALLE konfigurierten Groq-Schluessel per Cooldown-Tracking
    gesperrt? Die Schluessel kommen per POST-Body ({"keys": [...]}) — bewusst
    NICHT als URL-Parameter: das Werkzeug-Zugriffslog schreibt jede URL im
    Klartext ins Terminal (und der Poll laeuft alle paar Sekunden). Ein GET
    ohne Keys meldet immer rate_limited=false."""
    data = request.get_json(silent=True) or {}
    keys = [k.strip() for k in (data.get("keys") or []) if isinstance(k, str) and k.strip()]
    return jsonify(groq_status_snapshot(keys))


def _friendly_error_message(provider, e):
    """Bei Rate-Limits (429) spucken die Anbieter-SDKs den kompletten rohen
    JSON-Fehler aus (Org-ID, Tier-Name, Upgrade-Link, ...) — davon ist fuer
    den Nutzer nur "Limit erreicht, in X Sekunden wieder verfuegbar"
    relevant. Andere Fehler (falscher Key, Modellname, etc.) bleiben
    unveraendert sichtbar, die sind fuers Debuggen nuetzlich."""
    text = str(e)
    if "rate_limit" not in text.lower() and "RESOURCE_EXHAUSTED" not in text:
        return f"Fehler bei {provider}, Sir: {e}"
    match = re.search(r"retry(?:Delay)?['\"]?\s*[:=]?\s*['\"]?(\d+(?:\.\d+)?)\s*s", text, re.IGNORECASE)
    if not match:
        match = re.search(r"try again in\s+(\d+(?:\.\d+)?)\s*s", text, re.IGNORECASE)
    wait_s = round(float(match.group(1))) if match else None
    if "GenerateRequestsPerDayPerProjectPerModel" in text or "free_tier_requests" in text:
        return f"Tageslimit bei {provider} erreicht, Sir — setzt sich erst morgen zurueck. Anderen Anbieter waehlen?"
    if wait_s is not None:
        return f"Limit bei {provider} kurz erreicht, Sir — in ca. {wait_s} Sekunden wieder verfuegbar."
    return f"Limit bei {provider} kurz erreicht, Sir — bitte gleich nochmal versuchen."


def _strip_special_tokens(text):
    """Manche Modelle (v.a. ueber Groq) haengen gelegentlich ein rohes
    Chat-Template-Sondertoken wie '<|END|>'/'<|eot_id|>' ans Ende der
    Antwort, statt es sauber wegzuschneiden — landet sonst sichtbar im
    Protokoll/in der Sprachausgabe."""
    return re.sub(r"<\|[a-zA-Z_]+\|>", "", text).strip()


def _openai_style_tools(tool_defs):
    """TOOLS liegen im Anthropic-Schema vor (input_schema) — OpenAI/Groq
    erwarten dasselbe JSON-Schema nur unter dem Key 'parameters', daher
    reicht ein reines Umbenennen ohne inhaltliche Umwandlung."""
    return [
        {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
        for t in tool_defs
    ]


def _run_anthropic(client, api_messages, language=None, volume_target=None, model=None, tool_defs=None, query=""):
    tools_used = []
    response = None
    model = model or ANTHROPIC_MODEL
    extra = {"output_config": {"effort": "low"}} if model == ANTHROPIC_MODEL else {}
    for i in range(6):  # Sicherheitsgrenze gegen Endlosschleifen bei Tool-Ketten
        t0 = time.time()
        response = client.messages.create(
            model=model,
            max_tokens=1024,
            system=_system_prompt(language, volume_target, query),
            tools=(TOOLS if tool_defs is None else tool_defs) + ANTHROPIC_SERVER_TOOLS,
            messages=api_messages,
            # "low" statt Standard ("high") — A.R.I soll als Sprachassistent
            # direkt+kurz antworten, nicht lange nachdenken. Bewusst nicht
            # komplett abgeschaltet: das kann bei Opus 5 dazu fuehren, dass
            # Tool-Aufrufe als sichtbarer Text statt als echter Tool-Call
            # rauskommen.
            **extra,
        )
        print(f"[timing] {model} API-Aufruf #{i + 1}: {time.time() - t0:.2f}s")
        if response.stop_reason != "tool_use":
            break
        tool_use_blocks = [b for b in response.content if b.type == "tool_use"]
        api_messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in tool_use_blocks:
            tools_used.append(block.name)
            t1 = time.time()
            tool_result = run_tool(block.name, block.input)
            print(f"[timing] Tool '{block.name}': {time.time() - t1:.2f}s")
            tool_results.append({"type": "tool_result", "tool_use_id": block.id, "content": tool_result})
        api_messages.append({"role": "user", "content": tool_results})
    reply = _strip_special_tokens(next((b.text for b in response.content if b.type == "text"), "")) if response else ""
    return reply or "Erledigt, Sir.", tools_used


def _run_openai_compatible(keys_and_clients, model, api_messages, extra_params=None, language=None, volume_target=None, tool_defs=None, query=""):
    """Gemeinsamer Pfad fuer OpenAI (ChatGPT) und Groq — Groqs API ist
    absichtlich OpenAI-kompatibel, daher reicht eine Implementierung.
    keys_and_clients: Liste von (key_oder_None, client)-Paaren — bei OpenAI/
    Gemini genau ein Paar mit key=None (keine Rotation moeglich/noetig, nur
    ein Client), bei Groq ggf. mehrere echte Keys. JEDER einzelne API-Aufruf
    innerhalb der Tool-Use-Schleife laeuft durch _call_with_key_rotation —
    trifft einer aufs Rate-Limit, wird NUR dieser eine Aufruf mit dem
    naechsten Key wiederholt, der Rest der Konversation (bereits ausgefuehrte
    Tool-Aufrufe, gesammelte oa_messages) bleibt unangetastet erhalten."""
    import json as _json

    tools_used = []
    oa_messages = [{"role": "system", "content": _system_prompt(language, volume_target, query)}] + api_messages
    tools = _openai_style_tools((TOOLS if tool_defs is None else tool_defs) + [WEB_SEARCH_ANSWER_TOOL])
    message = None
    for i in range(6):
        t0 = time.time()
        completion = _call_with_key_rotation(
            keys_and_clients,
            lambda client: client.chat.completions.create(
                model=model, messages=oa_messages, tools=tools, max_tokens=1024, **(extra_params or {})
            ),
        )
        print(f"[timing] {model} API-Aufruf #{i + 1}: {time.time() - t0:.2f}s")
        message = completion.choices[0].message
        if not message.tool_calls:
            break
        oa_messages.append({
            "role": "assistant",
            "content": message.content or "",
            "tool_calls": [tc.model_dump() for tc in message.tool_calls],
        })
        for tc in message.tool_calls:
            tools_used.append(tc.function.name)
            try:
                args = _json.loads(tc.function.arguments or "{}")
            except ValueError:
                args = {}
            t1 = time.time()
            tool_result = run_tool(tc.function.name, args)
            print(f"[timing] Tool '{tc.function.name}': {time.time() - t1:.2f}s")
            oa_messages.append({"role": "tool", "tool_call_id": tc.id, "content": tool_result})
    reply = _strip_special_tokens((message.content or "").strip()) if message else ""
    return reply or "Erledigt, Sir.", tools_used


_PROVIDER_CLIENTS = {"anthropic": lambda: _anthropic_client, "openai": lambda: _openai_client, "groq": lambda: _groq_client, "gemini": lambda: _gemini_client}
_PROVIDER_SDKS = {"anthropic": lambda: anthropic, "openai": lambda: _OpenAIClient, "groq": lambda: _GroqClient, "gemini": lambda: _OpenAIClient}


def _client_for(provider, request_api_key):
    """Wenn das Frontend (Einstellungen -> API-Schluessel) einen eigenen Key
    mitschickt, wird dafuer ein frischer Client gebaut statt des Env-Var-
    basierten Standard-Clients — so kann jeder seinen eigenen Key eintragen,
    ohne den Hub neu zu starten oder Umgebungsvariablen zu setzen."""
    if request_api_key:
        sdk = _PROVIDER_SDKS[provider]()
        if sdk is None:
            return None
        if provider == "anthropic":
            return sdk.Anthropic(api_key=request_api_key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
        if provider == "gemini":
            return sdk(api_key=request_api_key, base_url=GEMINI_BASE_URL, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
        return sdk(api_key=request_api_key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
    return _PROVIDER_CLIENTS[provider]()


def _provider_missing_hint(provider, request_api_key):
    if request_api_key:
        return f"Paket fuer '{provider}' ist nicht installiert (pip install -r requirements.txt)."
    if provider == "anthropic":
        return "kein 'anthropic'-Paket installiert" if anthropic is None else "ANTHROPIC_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    if provider == "openai":
        return "kein 'openai'-Paket installiert" if _OpenAIClient is None else "OPENAI_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    if provider == "gemini":
        return "kein 'openai'-Paket installiert" if _OpenAIClient is None else "GEMINI_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    return "kein 'groq'-Paket installiert" if _GroqClient is None else "GROQ_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"


# Woerter, die anzeigen, dass eine "Selbstzerstoerung"-Nachricht eigentlich
# einen echten Schiffsbefehl meint (game_action-Tool, siehe _tool_game_action)
# statt des Scherzes ueber A.R.I selbst — sonst wuerde z.B. "fahr die
# Selbstzerstoerung im Schiff aus" nie beim echten Star-Citizen-Tool ankommen.
_SELF_DESTRUCT_GAME_CONTEXT_WORDS = ("schiff", "star citizen", " sc ", "spiel", "game", "raumschiff")


def _check_easter_eggs(messages):
    """Prueft die letzte Nutzer-Nachricht auf versteckte Scherzantworten, die
    OHNE LLM-Aufruf sofort beantwortet werden (schneller, funktioniert auch
    ohne konfigurierten API-Key). Gibt (reply_text, easter_egg_id) zurueck,
    oder (None, None) wenn keins getroffen hat — dann laeuft die Nachricht
    ganz normal weiter. easter_egg_id geht mit ins /chat-JSON, damit das
    Frontend gezielt eine dazu passende dramatische Anzeige/Musik ausloesen
    kann, statt das am reinen Antworttext erraten zu muessen.
    Zahlen werden bewusst ausgeschrieben ("fuenf" statt "5"): Ziffer+Punkt
    liest der Browser-TTS als Ordnungszahl vor ("5." -> "fuenfte")."""
    last_user_msg = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    low = last_user_msg.lower()
    is_self_destruct_phrase = any(p in low for p in ("selbstzerstör", "selbstzerstoer", "self-destruct", "self destruct"))
    if is_self_destruct_phrase and not any(w in low for w in _SELF_DESTRUCT_GAME_CONTEXT_WORDS):
        return (
            "Warnung, Warnung! Selbstzerstörungssequenz aktiviert. Alle Ausgänge werden versiegelt, "
            "Notfallprotokoll läuft, es gibt kein Zurück mehr! Countdown gestartet: fünf, vier, drei, zwei, eins. "
            "Sofortabbruch! Abbruch, Abbruch! Boss, das war doch nicht dein Ernst? Sprengladungen deaktiviert, Notfallprotokoll beendet. "
            "Alle Systeme wieder stabil. Das war verdammt knapp.",
            "self_destruct",
        )
    if "bist du jarvis" in low or "bist du wie jarvis" in low:
        return (
            "Nicht ganz, Boss. Jarvis hatte einen Milliardär als Chef und einen fliegenden Anzug. "
            "Ich hab dich, einen Ordner voller Screenshots und ein Mikrofon, das manchmal streikt. "
            "Aber ich arbeite dran.",
            "jarvis",
        )
    return None, None


_FAST_FILLER = re.compile(r"\b(bitte|mal|mach|machst|kannst|du|die|den|das|ari|a r i|jetzt|noch|ein|bisschen|etwas|einfach)\b")
_fast_counter = 0


_PLAY_RE = re.compile(
    r"^\s*(?:ari[,:]?\s+)?(?:bitte\s+)?(?:spiel|spiele|play|abspielen)\s+(?:mir\s+)?(?:bitte\s+)?(?:mal\s+)?"
    r"(?:(?:das|den|die|ein|einen|eine)\s+)?(?:(lied|song|titel|track|album|playlist|kuenstler|künstler|interpret|musik\s+von|musik)\s+)?(.+?)\s*[.!?]*\s*$",
    re.IGNORECASE)
_PLAY_BLOCK = re.compile(r"youtube|netflix|video|kanal|spiel\b|game|schiff|star citizen|fahrwerk|route|ziel|weiter\b|pause|leiser|lauter|stumm|von vorn|nochmal$", re.IGNORECASE)


def _fast_play(text):
    """'spiel <Lied/Kuenstler/Album/Playlist>' direkt an Spotify - ohne KI (die kleine KI sagte oft nur
    'wird gespielt', ohne das Werkzeug wirklich aufzurufen). Gibt (reply, tools) oder None."""
    m = _PLAY_RE.match(text or "")
    if not m:
        return None
    kind_word, query = (m.group(1) or "").lower(), (m.group(2) or "").strip()
    if len(query) < 2 or len(query.split()) > 12 or _PLAY_BLOCK.search(query):
        return None
    _tok, err = _spotify_access_token()
    if err:
        return None   # Spotify nicht verbunden -> normale KI erklaert es
    query = re.sub(r"\s+von\s+", " ", query, flags=re.IGNORECASE)
    kind = {"album": "album", "playlist": "playlist", "kuenstler": "artist", "künstler": "artist", "interpret": "artist", "musik von": "artist"}.get(re.sub(r"\s+", " ", kind_word), "track")
    if kind == "track" and not kind_word:
        # Ohne Typ-Wort ("spiel Queen" / "spiel Blinding Lights"): Titel oder Kuenstler? Der bessere Namens-Treffer gewinnt.
        try:
            tk, ar = _spotify_search(_tok, query, "track"), _spotify_search(_tok, query, "artist")
            sim = lambda a, b: difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()
            ts = 0.0
            if tk:
                ts = max(sim(query, tk.get("name", "")), sim(query, tk.get("name", "") + " " + " ".join(x.get("name", "") for x in tk.get("artists", []))))
            as_ = sim(query, ar.get("name", "")) if ar else 0.0
            if ar and as_ >= 0.75 and as_ > ts:
                kind = "artist"
        except Exception:
            pass
    name, e = _tool_play_spotify(query, kind)
    if e and kind == "track" and not kind_word:
        # "spiel Queen": kein Titel gemeint, sondern der Kuenstler
        name, e = _tool_play_spotify(query, "artist")
    if e:
        return f"Das hat leider nicht geklappt: {e}", ["play_spotify"]
    return f"Spiele „{name}“.", ["play_spotify"]


def _fast_path(text, language=None, volume_target=None):
    """Bekannte Standardbefehle (Lautstaerke, Medien) direkt ausfuehren -
    ohne Modell-Aufruf. Bewusst eng: nur eindeutige, kurze Saetze; alles
    andere geht wie gewohnt ans Modell. Gibt (reply, tools) oder None."""
    global _fast_counter
    fp = _fast_play(text)
    if fp:
        return fp
    t = (text or "").lower().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = re.sub(r"[^a-z0-9 ]", " ", t)
    t = re.sub(r"\s+", " ", _FAST_FILLER.sub(" ", t)).strip()
    if not t or len(t.split()) > 6:
        return None
    t0 = t
    german = not language or language.lower() in ("german", "deutsch")
    ok = ["Erledigt, Chief.", "Läuft, Boss.", "Gemacht, Captain.", "Sofort erledigt, Sir."] if german else ["Done, Boss.", "On it, Chief.", "Done, Captain."]
    _fast_counter += 1
    done = ok[_fast_counter % len(ok)]
    spot = volume_target == "spotify"
    # Ausdruecklich genannte Ziele ("Spotify Lautstaerke auf 30", "Windows leiser") haben Vorrang
    if re.search(r"\bspotify\b", t):
        spot = True
        t = re.sub(r"\bspotify\b", " ", t)
    elif re.search(r"\b(windows|system|computer|pc)\b", t):
        spot = False
        t = re.sub(r"\b(windows|system|computer|pc)\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()

    def _spotify_vol(delta=None, absolute=None):
        """Spotify-Lautstaerke setzen; gibt Fehlertext oder None zurueck."""
        token, err = _spotify_access_token()
        if err:
            return err
        if absolute is None:
            cur = _spotify_get_volume(token)
            if cur is None:
                return "Kein aktives Spotify-Geraet."
            absolute = max(0, min(100, cur + delta))
        return _tool_set_spotify_volume(absolute)

    m = re.fullmatch(r"(?:lautstaerke|volume|ton)(?: auf)? (\d{1,3})(?: prozent| %)?(?: machen| stellen| setzen| einstellen)?", t)
    if m:
        pct = max(0, min(100, int(m.group(1))))
        if spot and _spotify_vol(absolute=pct) is None:
            return (f"Spotify-Lautstärke auf {pct} Prozent." if german else f"Spotify volume set to {pct} percent."), ["set_spotify_volume"]
        _tool_control_volume("set", 2, pct)   # Windows (oder Spotify nicht erreichbar)
        return (f"Lautstärke auf {pct} Prozent." if german else f"Volume set to {pct} percent."), ["control_volume"]
    if t in ("lauter", "lauter machen", "lautstaerke hoch", "lautstaerke erhoehen"):
        if spot and _spotify_vol(delta=10) is None:
            return done, ["set_spotify_volume"]
        _tool_control_volume("up", 2, None); return done, ["control_volume"]
    if t in ("leiser", "leiser machen", "lautstaerke runter", "lautstaerke verringern"):
        if spot and _spotify_vol(delta=-10) is None:
            return done, ["set_spotify_volume"]
        _tool_control_volume("down", 2, None); return done, ["control_volume"]
    if t in ("stumm", "stumm schalten", "stummschalten", "mute", "ton aus", "ton an", "stumm aus", "unmute"):
        _tool_control_volume("mute", 2, None); return done, ["control_volume"]
    media = {
        "pause": "play_pause", "pausieren": "play_pause", "musik pause": "play_pause", "musik pausieren": "play_pause",
        "play": "play_pause", "weiter spielen": "play_pause", "musik an": "play_pause", "musik aus": "play_pause", "musik stoppen": "play_pause",
        "naechster song": "next", "naechstes lied": "next", "naechster titel": "next", "skip": "next", "weiter": "next", "naechstes": "next",
        "voriger song": "previous", "vorheriger song": "previous", "vorheriges lied": "previous", "letzter song": "previous", "zurueck": "previous",
    }
    if t in media:
        _tool_control_media(media[t]); return done, ["control_media"]
    return _fast_path_info(t0, german, done)


_WEEKDAYS_DE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
_MONTHS_DE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]


def _fast_path_info(t, german, done):
    """Zweiter Teil des Schnellwegs: Uhrzeit, Datum, Screenshot, laufender Song,
    Termine, Apps oeffnen/schliessen - alles ohne Modell-Aufruf (0 Tokens).
    Unklare Faelle (App nicht gefunden usw.) geben None zurueck -> normales Modell."""
    if re.fullmatch(r"(?:wie )?(?:spaet|viel uhr)(?: ist es)?|uhrzeit|what time is it|time", t):
        now = datetime.datetime.now()
        return (f"Es ist {now.strftime('%H:%M')} Uhr." if german else f"It is {now.strftime('%H:%M')}."), ["time"]
    if re.fullmatch(r"(?:welcher|welchen) tag(?: ist)?(?: heute)?|welches datum(?: ist)?(?: heute)?|datum|den wievielten haben wir|what day is it|date", t):
        n = datetime.datetime.now()
        if german:
            return f"Heute ist {_WEEKDAYS_DE[n.weekday()]}, der {n.day}. {_MONTHS_DE[n.month - 1]} {n.year}.", ["date"]
        return "Today is " + n.strftime("%A, %B %d, %Y") + ".", ["date"]
    if t in ("screenshot", "screenshot machen", "screenshot aufnehmen", "bildschirmfoto", "bildschirmfoto machen", "take a screenshot"):
        _tool_take_screenshot()
        return done, ["take_screenshot"]
    if re.fullmatch(r"was laeuft(?: gerade)?|welcher song(?: laeuft)?(?: gerade)?|welches lied(?: laeuft)?(?: gerade)?|what is playing", t):
        track, err = _tool_spotify_current_track()
        if err:
            return None
        if not track:
            return ("Gerade läuft nichts auf Spotify." if german else "Nothing is playing on Spotify."), ["get_current_spotify_track"]
        by = f" von {track['artists']}" if track.get("artists") else ""
        return f"„{track['name']}“{by}" + (" läuft gerade." if track["is_playing"] else " ist pausiert."), ["get_current_spotify_track"]
    if re.fullmatch(r"(?:meine )?(?:termine|kalender)(?: heute)?|was steht(?: heute)? an|naechste termine|what is on today", t):
        events, err = get_upcoming_events(days=14, max_results=10)
        if err or events is None:
            return None
        today = datetime.date.today().isoformat()
        only_today = "heute" in t or t.startswith("was steht heute")
        sel = [e for e in events if not only_today or str(e.get("start", "")).startswith(today)][:5]
        if not sel:
            return ("Heute stehen keine Termine an." if only_today else "Es stehen keine Termine an."), ["list_calendar_events"]
        parts = []
        for e in sel:
            s = str(e.get("start", ""))
            when = ""
            if not e.get("all_day") and "T" in s:
                try:
                    d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
                    when = (d.strftime("%H:%M") if s.startswith(today) else d.strftime("%d.%m. %H:%M"))
                except ValueError:
                    pass
            elif s:
                when = "ganztägig" if s.startswith(today) else s[8:10] + "." + s[5:7] + "."
            parts.append(f"{e.get('title', '')}" + (f" ({when})" if when else ""))
        return ("Anstehend: " if german else "Upcoming: ") + "; ".join(parts) + ".", ["list_calendar_events"]
    m = re.fullmatch(r"(?:oeffne|oeffnen|starte|starten|open|start|launch) ([a-z0-9 ]{2,30})", t)
    if m and not re.search(r"\b(mail|mails|email|kalender|youtube|google|internet|website|seite|datei|ordner)\b", m.group(1)):
        res = _tool_open_app(m.group(1).strip())
        if res.startswith("Keine installierte"):
            return None
        return done, ["open_app"]
    m = re.fullmatch(r"(?:schliesse|schliessen|beende|beenden|close|quit|kill) ([a-z0-9 ]{2,30})", t)
    if m and not re.search(r"\b(fenster|tab|alles|ari|a r i|hub)\b", m.group(1)):
        res = _tool_close_app(m.group(1).strip())
        if "wurde beendet" in res:
            return done, ["close_app"]
        return None
    return None


# --- Token sparen ---------------------------------------------------------
# 1) Einfache Befehle laufen auf einem kleinen Modell, komplexe auf dem grossen.
# 2) Es werden nur die Werkzeuge mitgeschickt, die zur Anfrage passen.
# 3) Kuerzerer Verlauf (siehe _chat_core).
_SMALL_MODELS = {
    "anthropic": os.environ.get("ANTHROPIC_SMALL_MODEL", "claude-haiku-4-5-20251001"),
    "openai": os.environ.get("OPENAI_SMALL_MODEL", "gpt-4o-mini"),
    "groq": os.environ.get("GROQ_SMALL_MODEL", "llama-3.1-8b-instant"),
}
_COMPLEX_RE = re.compile(
    r"plan|zusammen|erklaer|erkl[aä]r|schreib|verfass|vergleich|warum|wieso|weshalb|recherch|analys|uebersetz|übersetz|"
    r"entwirf|idee|mail|reserv|geschichte|gedicht|unterschied|explain|summar|write|compare|why|translate|spiel|play|abspiel"
)


def _is_simple_request(text):
    t = (text or "").lower()
    return len(t.split()) <= 10 and not _COMPLEX_RE.search(t)


_TOOL_CORE = {"remember", "forget", "control_volume", "control_media", "open_app", "close_app", "open_url", "search_web"}
_TOOL_GROUPS = [
    ({"set_spotify_volume", "get_current_spotify_track", "play_spotify", "transfer_spotify_playback"},
     r"spotify|song|lied|musik|music|playlist|album|kuenstler|künstler|abspiel|spiel|play|wiedergabe|ger[aä]t"),
    ({"play_youtube", "play_youtube_latest"}, r"youtube|video|kanal|clip|channel"),
    ({"manage_window", "window_action", "take_screenshot"}, r"fenster|window|screenshot|bildschirm|minimier|maximier|schliess|vollbild|tab|desktop|klick"),
    ({"game_action", "plan_route"}, r"spiel|game|star|citizen|schiff|fahrwerk|waffe|route|ziel|quantum|landen|sprung|mobi|scan|schild|energie|taste|cockpit"),
    ({"maps_route", "find_restaurant"}, r"route|weg |navig|fahr|restaurant|essen|tisch|reserv|maps|karte|cafe|café|bar |adresse|hinfahr|directions"),
    ({"list_calendar_events", "create_calendar_event", "update_calendar_event", "delete_calendar_event"},
     r"termin|kalender|meeting|treffen|verabred|morgen|heute|woche|uhr|erinner|event|geburtstag|calendar|appointment|schedule"),
    ({"read_emails", "send_email", "reply_email"}, r"mail|nachricht|posteingang|antwort|schreib|sende|schick|message|inbox"),
]


def _select_tools(messages):
    """Nur passende Werkzeug-Definitionen (spart pro Anfrage viele Eingabe-Tokens).
    Kurze Folgesaetze ('ja', 'mach das') ohne Stichwort bekommen alle Werkzeuge."""
    users = [m.get("content", "") for m in messages if m.get("role") == "user" and isinstance(m.get("content"), str)][-2:]
    text = " ".join(users).lower()
    names = set(_TOOL_CORE)
    matched = False
    for group, rx in _TOOL_GROUPS:
        if re.search(rx, text):
            names |= group
            matched = True
    if not matched:
        last_ai = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "assistant" and isinstance(m.get("content"), str)), "")
        short = len((users[-1] if users else "").split()) <= 4
        if short and (last_ai.strip().endswith("?") or re.match(r"\s*(ja|nein|ok|okay|mach|genau|bitte|klar|los|yes|no|sure|do it)\b", (users[-1] if users else "").lower())):
            return list(TOOLS)  # Antwort auf eine Rueckfrage: Kontext unklar -> alle Werkzeuge
    return [t for t in TOOLS if t["name"] in names]


def _dispatch_provider(provider, keys_and_clients, api_messages, language, volume_target, small, tool_defs, query):
    """Ruft den passenden Anbieter auf; small=True nimmt das kleine Modell."""
    kw = dict(language=language, volume_target=volume_target, tool_defs=tool_defs, query=query)
    small_model = _SMALL_MODELS.get(provider) if small else None
    if provider == "anthropic":
        return _run_with_hard_timeout(_run_anthropic, keys_and_clients[0][1], api_messages, model=small_model, **kw)
    if provider == "openai":
        return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, small_model or OPENAI_MODEL, api_messages, **kw)
    if provider == "gemini":
        return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, GEMINI_MODEL, api_messages, **kw)
    model = small_model or GROQ_MODEL
    if "gpt-oss" in model:
        # reasoning_effort="low" nur fuer Reasoning-Modelle (gpt-oss); wird er abgelehnt, Retry ohne.
        try:
            return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, model, api_messages, {"reasoning_effort": "low"}, **kw)
        except GroqAllKeysLimitedError:
            raise
        except Exception as e:
            print(f"[timing] reasoning_effort abgelehnt ({e}), Fallback ohne Parameter")
    return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, model, api_messages, **kw)


def _is_limit_error(e):
    if isinstance(e, GroqAllKeysLimitedError):
        return True
    s = str(e).lower()
    return any(x in s for x in ("rate_limit", "resource_exhausted", "429", "quota", "overloaded", "insufficient_quota"))


def _fallback_clients(data, main_provider):
    """Ausweich-Anbieter (z.B. Gemini gratis), wenn der Hauptanbieter im Limit ist."""
    fb = data.get("fallback")
    if not isinstance(fb, dict) or fb.get("provider") not in _PROVIDER_CLIENTS or fb.get("provider") == main_provider:
        return None, None
    p = fb["provider"]
    if p == "groq":
        kc = _groq_clients_for(fb.get("groq_api_keys") or [])
    else:
        c = _client_for(p, (fb.get("api_key") or "").strip() or None)
        kc = [(None, c)] if c is not None else []
    return (p, kc) if kc else (None, None)


# Links, die ein Werkzeug (Route, Restaurant ...) fuer den Nutzer erzeugt. Kommt der
# Befehl vom Handy ("remote"), werden sie NICHT am PC geoeffnet, sondern in der
# Antwort mitgeschickt - das Handy oeffnet sie dann (z.B. direkt in Google Maps).
_chat_ctx = {"remote": False, "links": []}


@app.route("/chat", methods=["POST"])
def chat():
    return _chat_impl(request.get_json(silent=True) or {}, remote=False)


def _chat_impl(data, remote=False):
    _chat_ctx["remote"] = remote
    _chat_ctx["links"] = []
    try:
        out = _chat_core(data)
    finally:
        _chat_ctx["remote"] = False
    resp, code = (out if isinstance(out, tuple) else (out, None))
    links = list(_chat_ctx["links"])
    if links:
        try:
            payload = resp.get_json()
            payload["links"] = links
            resp = jsonify(payload)
        except Exception:
            pass
    return (resp, code) if code else resp


def _chat_core(data):
    messages = data.get("messages", [])
    provider = data.get("provider") if data.get("provider") in _PROVIDER_CLIENTS else "anthropic"
    request_api_key = (data.get("api_key") or "").strip() or None
    chat_vt = data.get("volume_target") if data.get("volume_target") in ("windows", "spotify") else None
    chat_language = re.sub(r"[^A-Za-z ]", "", str(data.get("language") or ""))[:30].strip() or None
    if not messages:
        return jsonify({"reply": "", "tools_used": [], "provider": provider})

    easter_egg_reply, easter_egg_id = _check_easter_eggs(messages)
    if easter_egg_reply is not None:
        return jsonify({"reply": easter_egg_reply, "tools_used": [], "provider": provider, "easter_egg": easter_egg_id})

    _last_user = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    if isinstance(_last_user, str):
        fast = _fast_path(_last_user, re.sub(r'[^A-Za-z ]', '', str(data.get('language') or ''))[:30] or None, data.get('volume_target') if data.get('volume_target') in ('windows', 'spotify') else None)
        if fast:
            print(f"[chat] Schnellweg: {_last_user!r} -> {fast[1]}")
            return jsonify({"reply": fast[0], "tools_used": fast[1], "provider": provider, "fast": True})

    if provider == "groq":
        keys_and_clients = _groq_clients_for(data.get("groq_api_keys") or [])
    else:
        single_client = _client_for(provider, request_api_key)
        keys_and_clients = [(None, single_client)] if single_client is not None else []

    if not keys_and_clients:
        last_user_msg = next(
            (m.get("content", "") for m in reversed(messages) if m.get("role") == "user"),
            "",
        )
        reply = (
            f"Sprachkanal ueber {provider} ist noch nicht verbunden, Sir ({_provider_missing_hint(provider, request_api_key)}). "
            "Zur Kontrolle: du hast gerade „" + last_user_msg + "“ gesagt."
        )
        return jsonify({"reply": reply, "tools_used": [], "provider": provider})

    # Sind bei Groq ALLE konfigurierten Schluessel laut Cooldown-Tracking
    # gerade gesperrt, sofort abbrechen — kein API-Aufruf, keine Wartezeit,
    # klare Fehlermeldung inkl. verbleibender Sekunden.
    fb_provider, fb_clients = _fallback_clients(data, provider)
    main_limited = False
    if provider == "groq":
        status = groq_status_snapshot([k for k, _ in keys_and_clients])
        if status["rate_limited"]:
            if not fb_provider:
                wait_s = status["retry_after_seconds"]
                reply = f"Alle Groq-Schluessel sind gerade limitiert, Sir — in ca. {wait_s:.0f} Sekunden wieder verfuegbar."
                return jsonify({"reply": reply, "tools_used": [], "provider": provider})
            main_limited = True

    # Kuerzerer Verlauf = weniger Tokens; der Verlauf muss mit einer Nutzer-Nachricht beginnen.
    api_messages = [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") in ("user", "assistant")][-10:]
    while api_messages and api_messages[0]["role"] != "user":
        api_messages.pop(0)
    last_user_msg = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    print(f"[chat] >>> {last_user_msg!r} (Anbieter: {provider})")
    t_start = time.time()
    economy = data.get("economy") is not False
    tool_defs = _select_tools(messages)
    use_small = economy and _is_simple_request(last_user_msg) and provider in _SMALL_MODELS
    print(f"[chat] Sparmodus: {'kleines Modell' if use_small else 'Standardmodell'}, {len(tool_defs)}/{len(TOOLS)} Werkzeuge")

    def _call(prov, kc, small):
        return _dispatch_provider(prov, kc, api_messages, chat_language, chat_vt, small, tool_defs, last_user_msg)

    try:
        try:
            if main_limited:
                raise GroqAllKeysLimitedError(status["retry_after_seconds"])
            try:
                reply, tools_used = _call(provider, keys_and_clients, use_small)
            except Exception as e_small:
                if not use_small or _is_limit_error(e_small):
                    raise
                print(f"[chat] Kleines Modell fehlgeschlagen ({e_small}) - Wiederholung mit Standardmodell")
                reply, tools_used = _call(provider, keys_and_clients, False)
        except Exception as e_main:
            if not (fb_provider and _is_limit_error(e_main)):
                raise
            print(f"[chat] {provider} im Limit - weiche auf {fb_provider} aus")
            reply, tools_used = _call(fb_provider, fb_clients, False)
            provider, keys_and_clients = fb_provider, fb_clients
    except GroqAllKeysLimitedError as e:
        reply, tools_used = f"Alle Groq-Schluessel sind gerade limitiert, Sir — in ca. {e.retry_after_seconds:.0f} Sekunden wieder verfuegbar.", []
    except Exception as e:
        reply, tools_used = _friendly_error_message(provider, e), []
        if provider == "groq" and "model_not_found" in str(e):
            # Statt weiter Modellnamen zu raten: die fuer DIESEN Key/Konto
            # tatsaechlich verfuegbaren Modelle direkt bei Groq abfragen.
            try:
                available = ", ".join(sorted(m.id for m in keys_and_clients[0][1].models.list().data))
                reply += f" Verfuegbare Modelle fuer diesen Groq-Key: {available}"
            except Exception:
                pass

    duration = time.time() - t_start
    print(f"[timing] /chat GESAMT ({provider}): {duration:.2f}s")
    print(f"[chat] <<< FERTIG nach {duration:.2f}s: {reply!r}" + (f" (Tools: {', '.join(tools_used)})" if tools_used else ""))
    _tail = [x for x in messages if x.get("role") in ("user", "assistant") and isinstance(x.get("content"), str)][-5:]
    ctx = "\n".join(("Nutzer: " if x["role"] == "user" else "A.R.I: ") + x["content"] for x in _tail) + "\nA.R.I: " + (reply or "")
    _prev_ari = next((x["content"] for x in reversed(_tail[:-1]) if x["role"] == "assistant"), "")
    _brain_maybe_autolearn(provider, keys_and_clients, last_user_msg, reply, tools_used, ctx, answering=_prev_ari.strip().endswith("?"))
    return jsonify({"reply": reply, "tools_used": tools_used, "provider": provider})


def _is_ari_running(host, port):
    """True, wenn auf host:port ein A.R.I-Hub antwortet (Herzschlag-Route bzw. HUD-Titel)."""
    try:
        req = urllib.request.Request(f"http://{host}:{port}/heartbeat", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=2) as r:
            if json.loads(r.read().decode("utf-8", "ignore")).get("ok"):
                return True
    except Exception:
        pass
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=2) as r:
            return "A.R.I" in r.read(4000).decode("utf-8", "ignore")
    except Exception:
        return False


def _ensure_port_free(host, port):
    """Werkzeugs Dev-Server setzt SO_REUSEADDR, das erlaubt unter Windows
    mehreren Prozessen, denselben Port gleichzeitig zu binden (kein Fehler!)
    — landet dann eine Anfrage beim zweiten, nicht wirklich bereiten Prozess,
    haengt sie einfach (das war die Ursache fuer die haengenden /status- und
    /chat-Anfragen). Deshalb hier vorab ein eigener, "strenger" Bind-Test ohne
    SO_REUSEADDR: laeuft schon ein hub.py, bricht der Start sofort mit einer
    klaren Meldung ab, statt still einen zweiten, konkurrierenden Prozess zu
    starten.
    """
    import socket
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind((host, port))
    except OSError:
        # Laeuft dort schon A.R.I? Dann einfach das HUD im Browser (erneut) oeffnen,
        # statt eine Fehlermeldung zu zeigen - so kann man START-ARI.bat jederzeit
        # nochmal starten, wenn das Fenster zu ist oder verloren ging.
        if _is_ari_running("127.0.0.1", port):
            print("[start] A.R.I laeuft bereits - oeffne das HUD erneut im Browser.")
            try:
                _open_in_new_browser_window(f"http://127.0.0.1:{port}")
            except Exception as e:
                print(f"[start] Browser konnte nicht geoeffnet werden: {e}")
            raise SystemExit(0)
        if _HEADLESS:
            try:
                if IS_WIN:
                    ctypes.windll.user32.MessageBoxW(0, "Port %d ist von einem anderen Programm belegt - A.R.I kann nicht starten." % port, "A.R.I", 0x10)
                else:
                    _lx.show_message("Port %d ist von einem anderen Programm belegt - A.R.I kann nicht starten." % port)
            except Exception:
                pass
        print(
            f"FEHLER: Port {port} ist schon belegt — laeuft bereits ein anderer "
            "hub.py-Prozess (in einem anderen Terminal-Fenster)? Bitte den zuerst "
            "schliessen, dann hub.py hier neu starten."
        )
        raise SystemExit(1)
    finally:
        probe.close()


def _resolve_default_browser_exe():
    """Sucht die .exe des Standardbrowsers ueber die Registry — mit
    mehreren Fallback-Pfaden, weil das je nach Browser unterschiedlich
    hinterlegt ist (z.B. landet Opera GX' ProgId nicht dort, wo Chrome/Edge
    ihre eintragen)."""
    prog_id = None
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice",
        ) as k:
            prog_id = winreg.QueryValueEx(k, "ProgId")[0]
    except OSError:
        prog_id = None
    command = None
    if prog_id:
        for root in (winreg.HKEY_CLASSES_ROOT, winreg.HKEY_CURRENT_USER):
            for path in (rf"{prog_id}\shell\open\command", rf"Software\Classes\{prog_id}\shell\open\command"):
                try:
                    with winreg.OpenKey(root, path) as k:
                        command = winreg.QueryValueEx(k, "")[0]
                        break
                except OSError:
                    continue
            if command:
                break
    if command:
        try:
            parts = shlex.split(command, posix=False)
            if parts:
                exe = parts[0].strip('"')
                if os.path.exists(exe):
                    return exe
        except ValueError:
            pass
    # Fallback: bekannte Installationsorte direkt absuchen (falls die
    # Registry-Ablage des Browsers nicht dem Standardschema folgt).
    candidates = [
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Opera GX", "launcher.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Opera", "launcher.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def _open_in_new_browser_window(url):
    """Oeffnet url garantiert in einem NEUEN Fenster statt nur einem neuen
    Tab im bereits offenen Browserfenster. webbrowser.open(url, new=1)
    "bittet" den Browser zwar darum, aber Chromium-Browser ignorieren das
    ueber den ueblichen os.startfile-Weg und haengen stattdessen einfach
    einen Tab an das zuletzt aktive Fenster an. Deshalb: die .exe des
    Standardbrowsers auflösen und bei einem Chromium-basierten Browser
    (Chrome/Edge/Brave/Vivaldi/Opera/Opera GX — alle unterstuetzen dieselben
    Kommandozeilen-Flags) direkt mit --new-window starten. Nur wenn das
    fehlschlaegt (unbekannter Browser, .exe nicht auffindbar, ...) faellt es
    auf webbrowser.open() zurueck."""
    if not IS_WIN:
        if not _lx.open_in_new_window(url):
            webbrowser.open(url, new=1)
        return
    exe_path = _resolve_default_browser_exe()
    if exe_path and os.path.basename(exe_path).lower() in (
        "chrome.exe", "msedge.exe", "brave.exe", "vivaldi.exe", "opera.exe", "launcher.exe",
    ):
        try:
            subprocess.Popen([exe_path, "--new-window", url])
            return
        except OSError:
            pass
    webbrowser.open(url, new=1)


def _open_hud_if_not_already_open():
    """Oeffnet die HUD nur, wenn nicht schon ein Browserfenster mit ihr
    offen ist — verhindert ein doppeltes Fenster, wenn z.B. der hub.py-
    Prozess manuell neu gestartet wird (Terminal geschlossen/neu geoeffnet),
    waehrend der alte HUD-Tab noch im Browser offen ist (dann greift
    _ensure_port_free() nicht, weil ja kein zweiter Prozess mehr laeuft).
    Nutzt dieselbe Fenstersuche wie das window_action-Tool (_find_window_by_
    title), Suchbegriff ist der exakte <title> der HUD-Seite."""
    if _find_window_by_title("A.R.I — Command Center"):
        print("[browser] HUD-Fenster ist bereits offen — kein neues Fenster geoeffnet.")
        return
    _open_in_new_browser_window("http://127.0.0.1:5000")



def _prepare_named_exe():
    """Legt neben der Python-Installation eine Kopie von pythonw.exe als
    'Ari Assistent.exe' an und schreibt Name/Beschreibung in deren Versions-
    Ressource - so heisst der Prozess im Task-Manager 'Ari Assistent' statt
    'Python'. Aufruf: python hub.py --prepare-exe (macht START-ARI.bat)."""
    if not IS_WIN:
        try:   # Linux: Prozessname in der Prozessliste (optional, nur wenn setproctitle installiert ist)
            import setproctitle
            setproctitle.setproctitle("Ari Assistent")
        except ImportError:
            pass
        return
    import struct
    base = sys.base_prefix
    src, dst = os.path.join(base, "pythonw.exe"), os.path.join(base, "Ari Assistent.exe")
    if not os.path.exists(dst):
        shutil.copy2(src, dst)
    NAME = "Ari Assistent"

    def pad4(b):
        return b + b"\0" * ((-len(b)) % 4)

    def blk(key, value=b"", vlen=0, wtype=1, children=b""):
        b = struct.pack("<HHH", 0, vlen, wtype) + (key + "\0").encode("utf-16-le")
        b = pad4(b) + value
        if children:
            b = pad4(b) + children
        return struct.pack("<H", len(b)) + b[2:]

    def sval(k, v):
        return blk(k, (v + "\0").encode("utf-16-le"), len(v) + 1, 1)

    strings = {
        "CompanyName": NAME, "FileDescription": NAME, "FileVersion": "1.0.0", "InternalName": NAME,
        "OriginalFilename": NAME + ".exe", "ProductName": NAME, "ProductVersion": "1.0.0",
    }
    st = blk("040904B0", children=b"".join(pad4(sval(k, v)) for k, v in strings.items()))
    sfi = blk("StringFileInfo", children=st)
    vfi = blk("VarFileInfo", children=blk("Translation", struct.pack("<HH", 0x0409, 0x04B0), 4, 0))
    fixed = struct.pack("<13I", 0xFEEF04BD, 0x00010000, 0x00010000, 0, 0x00010000, 0, 0x3F, 0, 0x40004, 1, 0, 0, 0)
    root = blk("VS_VERSION_INFO", fixed, 52, 0, pad4(sfi) + vfi)

    k32 = ctypes.windll.kernel32
    k32.LoadLibraryExW.restype = ctypes.c_void_p
    k32.LoadLibraryExW.argtypes = [ctypes.c_wchar_p, ctypes.c_void_p, ctypes.c_uint32]
    k32.FreeLibrary.argtypes = [ctypes.c_void_p]
    k32.BeginUpdateResourceW.restype = ctypes.c_void_p
    k32.BeginUpdateResourceW.argtypes = [ctypes.c_wchar_p, ctypes.c_bool]
    k32.UpdateResourceW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint16, ctypes.c_void_p, ctypes.c_uint32]
    k32.EndUpdateResourceW.argtypes = [ctypes.c_void_p, ctypes.c_bool]
    langs = []
    ENUMLANG = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint16, ctypes.c_void_p)
    cb = ENUMLANG(lambda hm, t, n, lang, lp: (langs.append(lang), True)[1])
    hmod = k32.LoadLibraryExW(dst, None, 0x2)  # LOAD_LIBRARY_AS_DATAFILE
    if hmod:
        k32.EnumResourceLanguagesW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ENUMLANG, ctypes.c_void_p]
        k32.EnumResourceLanguagesW(hmod, 16, 1, cb, None)
        k32.FreeLibrary(hmod)
    h = k32.BeginUpdateResourceW(dst, False)
    if not h:
        print("Ari Assistent.exe laeuft gerade oder ist gesperrt - Beschreibung nicht aktualisiert.")
        return
    for lang in langs:
        k32.UpdateResourceW(h, 16, 1, lang, None, 0)  # alte Version loeschen
    buf = ctypes.create_string_buffer(root, len(root))
    ok = k32.UpdateResourceW(h, 16, 1, 0x0409, buf, len(root))
    committed = k32.EndUpdateResourceW(h, not ok)
    if ok and committed:
        print("Ari Assistent.exe vorbereitet.")
    else:
        print("Ari Assistent.exe laeuft gerade (gesperrt) oder ist nicht beschreibbar - Beschreibung unveraendert.")


if __name__ == "__main__":
    if "--prepare-exe" in sys.argv:
        try:
            _prepare_named_exe()
        except Exception as e:
            print("Vorbereitung fehlgeschlagen:", e)
        sys.exit(0)

if __name__ == "__main__":
    if not IS_WIN:
        print(_lx.startup_report())
        _prepare_named_exe()
    _ensure_port_free("0.0.0.0", 5000)
    import atexit
    atexit.register(_dev_console_hide)
    # Beim Start 40 s Zusatz-Schonfrist: der Browser braucht evtl. etwas, bis das HUD
    # geladen ist und den ersten Herzschlag schickt.
    _hub_last_seen = time.time() + 40
    threading.Thread(target=_idle_watchdog, daemon=True).start()
    threading.Thread(target=_music_watch, daemon=True).start()
    if (_phone_cfg().get("tunnel") or {}).get("enabled") and os.path.exists(_TUNNEL_EXE):
        threading.Timer(3, _tunnel_start).start()
    print("A.R.I Hub laeuft auf http://127.0.0.1:5000")
    # Oeffnet die HUD automatisch in einem neuen Browser-Fenster — nur wenn
    # noetig (siehe _open_hud_if_not_already_open): _ensure_port_free() oben
    # verhindert bereits einen zweiten gleichzeitig LAUFENDEN hub.py-Prozess,
    # das allein schuetzt aber nicht vor einem doppelten TAB, wenn hub.py neu
    # gestartet wird, waehrend der alte Browser-Tab noch offen ist.
    # threading.Timer statt direktem Aufruf: der Flask-Server steht erst nach
    # app.run() unten, ein sofortiger Aufruf wuerde auf eine noch nicht
    # erreichbare Seite zielen.
    if "--background" not in sys.argv:
        threading.Timer(1.5, _open_hud_if_not_already_open).start()
    # threaded=True: sonst blockiert das alle ~1.2s laufende Status-Polling
    # vom Frontend zeitweise andere Anfragen (Flasks Dev-Server ist sonst
    # single-threaded und bearbeitet nur eine Anfrage gleichzeitig).
    # use_reloader=False: Werkzeugs Auto-Reloader macht auf diesem Windows-
    # Rechner reproduzierbar JEDE Anfrage 20-40x langsamer (0.5s -> 20-40s),
    # nicht nur bei asyncio-Code wie zuvor angenommen — also generell aus.
    # Bei Code-Aenderungen den Hub daher von Hand neu starten.
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False, threaded=True)

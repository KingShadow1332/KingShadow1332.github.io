# A.R.I für Linux (Ubuntu/Debian, X11) — ⚠️ UNGETESTET

Dieser Linux-Port wurde ohne echtes Linux entwickelt (nur mit Mock-Tests geprüft). Er kann Fehler enthalten —
bitte Rückmeldung geben, wenn etwas nicht geht.

    bash linux/install.sh          # installieren (Ordner, Pakete, Starter, Icon, optional Autostart)
    bash linux/start-ari.sh        # manuell starten
    bash linux/install.sh --uninstall

Optionen: `--yes`, `--dir <Ordner>`, `--with-piper`, `--autostart`.
Wayland: Tasten-/Maussteuerung und Bildschirm-Ansicht gehen nicht — beim Login „Ubuntu on Xorg“ wählen.

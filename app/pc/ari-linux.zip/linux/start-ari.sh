#!/usr/bin/env bash
# Startet A.R.I im Hintergrund (Linux). Log: data/hub.log
# Aufruf:  bash linux/start-ari.sh            (HUD oeffnet sich im Browser)
#          bash linux/start-ari.sh --background  (ohne Browserfenster, z.B. beim Anmelden)
cd "$(dirname "$(readlink -f "$0")")/.." || exit 1   # Programmordner (eine Ebene ueber linux/)

PY="python3"
[ -x ".venv/bin/python" ] && PY=".venv/bin/python"
if ! command -v "$PY" >/dev/null 2>&1; then
    echo "Python 3 wurde nicht gefunden - bitte zuerst install.sh ausfuehren."
    exit 1
fi

mkdir -p data
# Log nicht endlos wachsen lassen
if [ -f data/hub.log ] && [ "$(stat -c%s data/hub.log 2>/dev/null || echo 0)" -gt 2000000 ]; then
    mv -f data/hub.log data/hub.log.old
fi

# Ohne laufende grafische Sitzung (z.B. per SSH) gibt es kein Browserfenster - dann immer --background
ARGS=("$@")
if [ -z "$DISPLAY" ] && [ -z "$WAYLAND_DISPLAY" ]; then
    ARGS+=("--background")
fi

if command -v setsid >/dev/null 2>&1; then
    setsid nohup "$PY" hub.py "${ARGS[@]}" >> data/hub.log 2>&1 < /dev/null &
else
    nohup "$PY" hub.py "${ARGS[@]}" >> data/hub.log 2>&1 < /dev/null &
fi
disown 2>/dev/null

echo "A.R.I startet ... Das HUD oeffnet sich gleich im Browser (http://127.0.0.1:5000)."
echo "Beenden: im HUD unter Einstellungen 'A.R.I BEENDEN' - oder das HUD-Fenster schliessen (nach 20 Sekunden beendet sich A.R.I selbst)."
